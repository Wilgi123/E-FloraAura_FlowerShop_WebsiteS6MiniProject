-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2023 at 01:27 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flower_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_address`
--

CREATE TABLE `tbl_address` (
  `address_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_address`
--

INSERT INTO `tbl_address` (`address_id`, `user_id`, `name`, `address`, `phone`, `postcode`, `date_added`) VALUES
(1, 1, 'wsewewrw', 'sfdfsgfh', '9123456789', '353646', '2023-02-18 17:35:59'),
(2, 1, 'Tilji Thomas', 'Nayipurayidathil house\r\nArangu P.O Chappath\r\nNaduvil via Kannur, Kerala', '+917025169137', '670582', '2023-02-18 18:12:37'),
(4, 2, 'Wilgimol Thomas', 'Akjkdfhiewodfnkd\r\njdhfjdfskd\r\nnchcids', '+917025169137', '670582', '2023-02-20 10:35:47'),
(5, 2, 'Wilgimol Thomas', 'adSdsfdkherhjdcas\r\ndsajsdkas', '7025169137', '670582', '2023-02-20 10:49:10'),
(6, 2, 'Tilji', 'afdsgdfgdfh', '+919744169137', '670582', '2023-02-20 11:02:03'),
(7, 3, 'Thomas Thomas', 'Nayipurayidathil House\r\nArangu P.O Chappath\r\nNaduvil via Kannur ', '+919744169137', '670582', '2023-02-20 12:02:04'),
(8, 3, 'Thomas Thomas', 'Nayipurayidathil House\r\nArangu P.O Chappath\r\nNaduvil via Kannur\r\n  ', '+919744169137', '670582', '2023-02-20 12:08:55'),
(9, 3, 'Jijimol Thomas', 'Nayipurayidathil House \r\nArangu P.O Chappath \r\nNaduvil via Kannur', '+919744169137', '670 582', '2023-02-20 12:25:10'),
(10, 5, 'Jijimol', 'hdfdgghjfn', '+919744169137', '670582', '2023-02-20 12:42:56'),
(11, 6, 'Sreelakshmi', 'Parakadavil', '9876543210', '686509', '2023-02-20 12:54:25'),
(12, 7, 'Wilgimol Thomas', 'Nayipurayidathil House \r\nArangu P.O Chappath \r\nNaduvil via Kannur,Kerala', '+917025169137', '670582', '2023-02-20 18:19:33'),
(13, 8, 'Wilgimol Thomas', 'Nayipurayidathil House \r\nArangu P.O Chappath \r\nNaduvil via Kannur,Kerala', '+919744169137', '670582', '2023-02-20 18:29:52'),
(15, 9, 'Varsha Shaji', 'Veetupere Ariyilaa\r\nKottayam', '+919744169137', '670582', '2023-02-20 22:02:25'),
(16, 9, 'Ayushi ', 'Vttupere Arke\r\nAriyam Kottayam', '+917025169137', '670582', '2023-02-20 22:04:02'),
(17, 9, 'Anand S', 'Aishwarya ane enne thonnunnu\r\nKottayam', '+918733242197', '670582', '2023-02-20 22:04:53'),
(18, 10, 'Tansya Babu', 'Kizhakkemuthukulam\r\nKozha P.O\r\nKuravilangad\r\nKottayam', '+919744169137', '6886640', '2023-02-21 10:43:05'),
(20, 16, 'Wilgimol Thomas', 'nayipurayidathil house arangu p.o chappath naduvil via kannur ', '+917025169137', '670582', '2023-03-02 22:14:29'),
(21, 18, 'Tilji Thomas', 'Nayipurayidathil house\r\nArangu P.O Chappath\r\nNaduvil via Kannur\r\nKerala', '+917025169137', '670582', '2023-03-02 22:56:10'),
(22, 19, 'Augustin ', 'Kanjirappally, Kottayam,Kerala', '+919744169137', '686507', '2023-03-03 11:52:55'),
(23, 20, 'Anand', 'Kidangoor P.O ,Kottayam ', '+919933256438', '686572', '2023-03-03 12:30:29'),
(24, 21, 'Wilgimol Thomas', 'Kanjirapalli kerala', '+919744169137', '670582', '2023-03-03 16:18:15'),
(25, 40, 'Wilgimol ', 'Nayipurayidathil House\r\nArangu P.O Chappath\r\nNaduvil Via Kannur\r\nKerala', '+917025169137', '670582', '2023-03-18 11:53:21'),
(26, 8, 'Tilji Thomas', 'Nayipurayidathil House Arangu P.O Chappath\r\nNaduvil Via Kannur Kerala', '+919744169137', '670582', '2023-03-18 11:59:06'),
(28, 60, 'Wilson Thomas', 'Nayipurayidathil house,Arangu P.O Chappath \r\nKannur, Kerala', '+919744169137', '670582', '2023-03-18 16:49:45'),
(29, 60, 'Tilji Thomas', 'Nayipurayidathil house,Arangu P.O Chappath Kannur, Kerala', '+917025169137', '670582', '2023-03-18 16:50:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `Store_address` varchar(1000) NOT NULL,
  `store_phone` varchar(20) NOT NULL,
  `store_email` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `Store_address`, `store_phone`, `store_email`, `status`, `date_added`) VALUES
(1, 'WilgimolThomas', 'wilgimolthomas@gmail.com', '3fde24db0543b9d447b2f8abb6619a22', 'HQ4Q+WPC, Church Lane, Kokkappally, Kanjirappally, Kerala 686555', '04828202961', 'efloraaura@gmail.com', 'active', '2023-02-22 16:51:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog`
--

CREATE TABLE `tbl_blog` (
  `blog_id` int(11) NOT NULL,
  `blog_title` varchar(100) NOT NULL,
  `blog_description` varchar(400) NOT NULL,
  `blog_image` varchar(100) NOT NULL,
  `blog_statuses` varchar(30) NOT NULL,
  `blog_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_blog`
--

INSERT INTO `tbl_blog` (`blog_id`, `blog_title`, `blog_description`, `blog_image`, `blog_statuses`, `blog_date`) VALUES
(1, 'Bloom with Joy: Our Guide to the Perfect Bouquet', 'A comprehensive guide to choosing the right flowers for any occasion, from weddings to birthdays to sympathy arrangements.', 'blog1.jpg', 'available', '2023-04-15 17:32:21'),
(2, 'From Our Garden to Your Home: The Freshness Guarantee', 'Discover the difference of shopping at a local flower shop and the assurance of our guarantee of the freshest flowers.', 'blog2.jpg', 'available', '2023-04-15 17:32:21'),
(3, 'Flowers for Every Budget: Affordable and Elegant Options', 'A showcase of our affordable yet stunning flower arrangements and bouquets, perfect for any budget.', 'blog4.jpg', 'available', '2023-04-15 17:32:21'),
(4, 'Express Your Love: Our Romantic Floral Arrangements', ' Whether its for Valentines Day, an anniversary, or just to show someone special you care, our romantic arrangements are sure to impress.', 'blog3.jpg', 'available', '2023-04-15 17:32:21'),
(5, 'Springtime Blooms: Celebrate the Season with Our Fresh Florals', '  Welcome the arrival of spring with our gorgeous seasonal flower arrangements, featuring tulips, daffodils, and other springtime blooms.', 'blog5.jpg', 'available', '2023-04-15 17:32:21'),
(6, 'Celebrating Milestones: Our Graduation and Prom Flower Arrangements', ' Commemorate special milestones like graduations and proms with our beautiful flower arrangements, corsages, and boutonnieres.', 'blog6.jpg', 'available', '2023-04-15 17:32:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cart_id` int(11) NOT NULL,
  `flower_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cart_price` double NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cart_qnt` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cart_id`, `flower_id`, `user_id`, `cart_price`, `date_added`, `cart_qnt`, `status`) VALUES
(75, 88, 0, 590, '2023-04-16 05:44:04', 1, 'available');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_image` varchar(100) NOT NULL,
  `category_description` text NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `category_image`, `category_description`, `status`) VALUES
(11, 'Roses', 'rose.jpg', 'A wide variety of roses of different origin that blooms in different seasons. Roses are native primarily to the temperate regions of the Northern Hemisphere. Many roses are cultivated for their beautiful flowers, which range in colour from white through various tones of yellow and pink to dark crimson and maroon, and most have a delightful fragrance, which varies according to the variety and to climatic conditions.', 'available'),
(12, 'Gerberas', 'Gerbera.jpg', 'Gerbera daisies have long-lasting 3- to 4-inch flowers that come in numerous shades of yellow, white, pink, red, orange, lavender, salmon, and bicolored. The center floral disk can range from a yellowish to light-bronze to black in color.', 'available'),
(13, 'Orchids', 'Orchids.jpg', 'The flower of the orchid plant is colorful, fragrant and can vary in sizes from microscopic plants (Platystele) to long vines (Vanilla) to gigantic plants (Grammatophullum). There is an outer whorl of three similar segments called sepals. Within the sepals is another whorl of three segments called petals.', 'available'),
(14, 'Carnation', 'carnation.jpg', 'carnation, (Dianthus caryophyllus), also called grenadine or clove pink, herbaceous plant of the pink, or carnation, family (Caryophyllaceae), native to the Mediterranean area. It is widely cultivated for its fringe-petaled flowers, which often have a spicy fragrance, and is used extensively in the floral industry.', 'available'),
(20, 'Lily', 'lily.jpg', 'The true lilies are erect perennial plants with leafy stems, scaly bulbs, usually narrow leaves, and solitary or clustered flowers. The flowers consist of six petal-like segments, which may form the shape of a trumpet, with a more or less elongated tube, as in the Madonna lily (Lilium candidum) and Easter lily', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_flowers`
--

CREATE TABLE `tbl_flowers` (
  `flower_id` int(11) NOT NULL,
  `flower_name` varchar(50) NOT NULL,
  `flower_price` int(11) NOT NULL,
  `images` varchar(100) NOT NULL,
  `descriptions` mediumtext NOT NULL,
  `category_id` varchar(50) NOT NULL,
  `stock` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `statuses` varchar(50) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_flowers`
--

INSERT INTO `tbl_flowers` (`flower_id`, `flower_name`, `flower_price`, `images`, `descriptions`, `category_id`, `stock`, `date_added`, `statuses`, `rating`) VALUES
(70, 'Classic 10 Red Roses Bouquet', 530, 'rose1.jpg', 'This bouquet is an absolute sensation! Dozen stemmed roses enclosed in black wrapping paper and embellished with a red ribbon will surely bring a blooming joy on the face of the recipient. So, on the next occasion, delight your loved ones with this red-black beauty.', '11', 26, '2023-04-16 09:51:43', 'available', 4),
(71, 'Red N Black Beauty', 550, 'rose2.jpg', 'This bouquet is an absolute sensation! Dozen stemmed roses enclosed in black wrapping paper and embellished with a red ribbon will surely bring a blooming joy on the face of the recipient. So, on the next occasion, delight your loved ones with this red-black beauty.', '11', 0, '2023-04-10 10:02:25', 'available', 3),
(72, 'Explore Love', 100, 'rose3.jpg', 'This bouquet is an absolute sensation! Dozen stemmed roses enclosed in black wrapping paper and embellished with a red ribbon will surely bring a blooming joy on the face of the recipient. So, on the next occasion, delight your loved ones with this red-black beauty.', '11', 29, '2023-04-12 09:57:04', 'available', 5),
(73, 'Love Bonanza', 5000, 'rose4.jpg', 'This is a round basket of 100 Red Roses. The huge appearance of this basket is a perfect way to show your deep emotions or congratulate people on their anniversaries or achievements.', '11', 40, '2023-04-12 09:08:10', 'available', 0),
(74, 'Fresh Pink Roses With Vase', 600, 'rose5.jpg', 'Let every special moment with your loved one a gem. Melt his/her heart with the beautiful, fresh, and aromatic, pink roses in a vase. This lovely rose and vase arrangement works wonders to spruce up your relationship and adorn any space be it at the office or home.', '11', 93, '2023-04-16 09:51:43', 'available', 0),
(75, 'Luxurious Bouquet', 1000, 'rose6.jpg', 'This lovely bunch of 100 Pink Roses packed beautifully with a pink ribbon is a perfect stunner for every grand occasion.', '11', 20, '2023-03-25 05:30:20', 'available', 0),
(76, 'Mixed Gerberas Birthday Box', 500, 'gerberas1.jpg', 'Our signature box that quotes happy birthday ensures you to bring a beaming smile on your loved ones face. So, grab this exclusive box consisting of beautifully mixed daisies and make your loved ones feel special on their happy birthdays.', '12', 100, '2023-03-23 11:54:45', 'available', 0),
(77, 'Spectral bonanza', 550, 'gerberas2.jpg', 'The sophistication of this product gives an elite touch to the gift you are sending to your loved one on this special day. The vibrant colors of mixed gerberas will light up their day and revived all the beautiful memories once shared. A perfect way to reconnect when you are away.', '12', 92, '2023-04-10 10:08:59', 'available', 0),
(81, 'Vivid Memories', 520, 'gerberas3.jpg', 'This is an arrangement of 10 red and 10 yellow Gerberas. This concoction of bright Gerberas is a perfect way to lighten up any dull surrounding. It is a perfect present to cheer up a recovering patient, or make up for a fight or just to brighten up your office desk .', '12', 98, '2023-04-16 11:07:08', 'available', 0),
(82, 'Unbox Blissful Love', 500, 'gerberas4.jpg', 'Our signature box that quotes happy birthday ensures you to bring a beaming smile on your loved ones face. So, grab this exclusive box consisting of beautifully mixed daisies and make your loved ones feel special on their happy birthdays.', '12', 98, '2023-03-23 11:55:33', 'available', 0),
(83, 'Mesmerizing Mixed Flower Basket', 500, 'Gerberas5.jpg', 'Make the best and lasting impressions on your near and dear ones on upcoming special occasions with a mesmerising mixed flower basket. This flower basket comes in a heart-melting arrangement that has fresh and aromatic 9 Gerberas, 2 Ming Eng, 1 Gypso, 2 Taal Palm, 3 Zenando Leaves, and 4 Dracaenas.', '12', 100, '2023-03-23 11:55:47', 'available', 0),
(84, 'White Lily Rose Gerbera Bouquet', 500, 'gerberas6.jpg', 'This divine bunch of White exotic flowers is the onlookers paradise. These flowers represent pure feelings which are untouched by any worldly disdain. Special Note: All the flowers might not be available at each occasion, they will be replaced with the equivalent with flowers to give a similar look.', '12', 96, '2023-03-23 11:58:28', 'available', 0),
(85, 'Orchids In A Vase', 590, 'orchid1.jpg', 'Got respect and admiration for your dear ones? You should make that person feel special and bring a smile on his/her with your gifting gesture. And a graceful arrangement of purple Orchids in a decorative vase is all you need to make them the happiest.', '13', 10, '2023-03-30 02:32:06', 'available', 0),
(86, 'Blue Vanda orchid Jute Bouquet', 590, 'orchid2.jpg', 'Cherish your special relations on special occasions as you choose to opt for this scintillating jute bouquet full of blue orchids. These exotic blooms are sure to be delivered at your as well as your dear ones doorstep garden fresh and is sure to symbolize love, luxury, beauty and strength.', '13', 7, '2023-04-16 09:51:43', 'available', 5),
(87, 'Orchids N Roses Glass Vase', 590, 'orchid3.jpg', 'Flowers are the perfect way to instantly infuse any space with a fresh vibe, energy and life, so having an amazing glass vase on hand is an absolute must. Present this beautiful glass vase filled with fresh orchids and pink roses to your loved ones. It will add an elegant touch to the interiors of their as well as your home.', '13', 17, '2023-04-16 09:51:43', 'available', 0),
(88, 'Beauty Quotient', 590, 'orchid4.jpg', 'A colourful bouquet for the special person who made your life colourful. This exotic bunch of 13 pink and white carnations with orchids and lilies placed in a beautiful mug. Home delivery makes it an extra special gift.', '13', 20, '2023-03-23 11:59:45', 'available', 0),
(89, 'Orchid Bonanza', 590, 'orchid6.jpg', 'Embrace the beauty of your relationship with this beautiful bouquet of 6 long stemmed purple Orchids wrapped in jute and gracefully tied with pink threads. A special and memorable gift for any recipient.', '13', 19, '2023-03-23 12:00:01', 'available', 0),
(90, 'Heavenly Orchid Blooms', 590, 'orchid5.jpg', 'Let the love of your life know how much he or she means to you on Valentines Day with the heavenly orchid blooms. This heart-melting bouquet comes with garden-fresh orchid flowers in a mesmerising white wrapping paper. Place your order now and remember to choose the most convenient delivery time!', '13', 20, '2023-03-23 12:00:23', 'available', 0),
(91, 'Pink Lilies In A Vase', 590, 'lily1.jpg', 'Beautiful pink lilies placed gorgeously in a glass vase is the best present that you can get for anyone. Let your dear ones feel your love and care with this fabulous arrangement of pink lilies in a vase. Send it right away and make their day extra special.', '20', 20, '2023-04-16 06:05:11', 'available', 0),
(92, 'Pleasing Lily Rose Vase', 590, 'lily2.jpg', 'This summer, make your abode a refreshing, pleasing and beautiful paradise by adorning the living room, balcony or master bedroom with this floral creation. A pretty amalgamation of powder pink lilies and roses with baby breath fillers and emerald green foliage in a cylindrical glass vase.', '20', 20, '2023-04-16 06:05:50', 'available', 0),
(93, 'O Darling White Lily Vase', 590, 'lily3.jpg', 'Speak of your unexpressed feelings for your loved ones with this serene white bunch of white lilies which comes placed in a clear glass vase. As white lilies are known to symbolise rejuvenation of the soul, this mesmerising floral setting makes an incredible gift across various special occasions.', '20', 20, '2023-04-16 06:06:04', 'available', 0),
(94, 'Love Lilies', 590, 'lily4.jpg', 'Lilies are one of a kind of flowers that sets the perfect mood to impress your loved ones. This season of love, create an atmosphere of love and romance by sending your love this beautiful bunch of lilies and wish them love, wealth and prosperity. ', '20', 19, '2023-04-16 06:06:19', 'available', 0),
(95, 'Gorgeous Pink Lilies', 590, 'lily5.jpg', 'Gift this bouquet of pretty pink lilies artfully arranged by our florist to your special one and make their day a special one. These lilies will fill the recipients life with a sweet fragrance, and they shall treasure this gesture of yours for a lifetime.', '20', 20, '2023-04-16 06:06:36', 'available', 0),
(96, 'Pristine Pink Lilies', 590, 'lily6.jpg', 'Pink lilies represent love, emotions and compassion and femininity. If you wish to express your love and emotions consider gifting this beautifully curated pristine pink lilies bouquet. You can choose to send it on occasions like birthday, anniversary, valentine or just like that.', '20', 20, '2023-04-16 06:07:00', 'available', 0),
(97, 'Colorful Mixed Carnations Bunch', 590, 'carnation1.jpg', 'Carnations are also called pinks because of their spiky petals that look like they were cut with pinking shears. While all carnations symbolize love and affection, gift this beautiful bunch of 10 mixed carnations to your special ones. The bloom of carnations shall sprinkle a colourful smile all around.', '14', 20, '2023-03-23 12:02:45', 'available', 0),
(98, 'Red Carnation Bouquet', 590, 'carnation2.jpg', 'Do you know whats beautiful? A bunch of red carnations and it becomes even more beautiful when it is gifted to someone special across some special occasions. When words fall short this freshly stemmed bouquet of carnations helps! So, gift it to someone without any second thoughts.', '14', 18, '2023-03-23 12:03:50', 'available', 0),
(99, 'Blush Floral Vase', 590, 'carnation3.jpg', 'Carnations are also called pinks because of their spiky petals that look like they were cut with pinking shears. While all carnations symbolize love and affection, gift this beautiful bunch of 10 mixed carnations to your special ones. The bloom of carnations shall sprinkle a colourful smile all around.', '14', 20, '2023-03-23 12:03:36', 'available', 0),
(100, 'Carnation Jute Bouquet', 590, 'carnation4.jpg', 'The Anything For You Arrangement- Defeating every obstacle coming her way, Razia was a shining star in the era of the men. Full of colors and flamboyancy, she emerged as a powerful ruler and inspired by her courageous aura is this rainbow arrangement enveloped in the traditions of India. Bold and beautiful, it teleports your dearest one to her days and evokes the beauty in a wondrous way.', '14', 20, '2023-03-23 12:03:23', 'available', 0),
(101, 'Floral Enchantment Vase', 590, 'carnation5.jpg', 'Carnations are also called pinks because of their spiky petals that look like they were cut with pinking shears. While all carnations symbolize love and affection, gift this beautiful bunch of 10 mixed carnations to your special ones. The bloom of carnations shall sprinkle a colourful smile all around.', '14', 19, '2023-03-23 12:03:09', 'available', 0),
(102, 'Alluring Carnations With Vase', 590, 'carnation6.jpg', 'Make your partner feel special and loved this Valentines Day by gifting her/him this beautiful flower vase. It consists of four white and eight pink colour carnations in a transparent vase that gives an eye-pleasing feel. This will definitely make your beloved heart melt.', '14', 20, '2023-03-23 12:02:56', 'available', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_orderdt`
--

CREATE TABLE `tbl_orderdt` (
  `orderdetails_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `flower_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_qnt` int(11) NOT NULL,
  `order_price` double NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_orderdt`
--

INSERT INTO `tbl_orderdt` (`orderdetails_id`, `order_id`, `flower_id`, `user_id`, `order_qnt`, `order_price`, `date_added`) VALUES
(1, 2, 71, 8, 1, 550, '0000-00-00 00:00:00'),
(2, 3, 71, 8, 1, 550, '0000-00-00 00:00:00'),
(3, 3, 72, 8, 1, 100, '0000-00-00 00:00:00'),
(4, 4, 70, 40, 3, 1500, '0000-00-00 00:00:00'),
(5, 4, 71, 40, 3, 1650, '0000-00-00 00:00:00'),
(6, 4, 81, 40, 1, 520, '0000-00-00 00:00:00'),
(7, 4, 75, 40, 1, 1000, '0000-00-00 00:00:00'),
(8, 4, 84, 40, 1, 500, '0000-00-00 00:00:00'),
(9, 4, 74, 40, 1, 600, '0000-00-00 00:00:00'),
(10, 5, 71, 40, 2, 1100, '0000-00-00 00:00:00'),
(11, 6, 77, 40, 3, 1650, '0000-00-00 00:00:00'),
(12, 7, 70, 8, 1, 500, '0000-00-00 00:00:00'),
(18, 11, 71, 8, 1, 550, '0000-00-00 00:00:00'),
(26, 14, 72, 60, 2, 200, '0000-00-00 00:00:00'),
(27, 14, 84, 60, 3, 1500, '0000-00-00 00:00:00'),
(28, 14, 89, 60, 1, 590, '0000-00-00 00:00:00'),
(29, 15, 82, 60, 1, 500, '0000-00-00 00:00:00'),
(30, 16, 71, 40, 4, 2200, '0000-00-00 00:00:00'),
(31, 17, 70, 40, 1, 500, '0000-00-00 00:00:00'),
(32, 17, 71, 40, 1, 550, '0000-00-00 00:00:00'),
(33, 17, 86, 40, 1, 590, '0000-00-00 00:00:00'),
(36, 19, 70, 40, 7, 3500, '0000-00-00 00:00:00'),
(37, 20, 70, 8, 5, 2500, '0000-00-00 00:00:00'),
(38, 21, 71, 40, 2, 1100, '0000-00-00 00:00:00'),
(39, 22, 75, 40, 1, 1000, '0000-00-00 00:00:00'),
(40, 22, 70, 40, 5, 2650, '0000-00-00 00:00:00'),
(41, 23, 70, 40, 2, 1060, '0000-00-00 00:00:00'),
(42, 24, 70, 40, 3, 1590, '0000-00-00 00:00:00'),
(43, 25, 86, 40, 1, 590, '0000-00-00 00:00:00'),
(44, 26, 70, 40, 1, 530, '0000-00-00 00:00:00'),
(46, 28, 72, 40, 3, 300, '0000-00-00 00:00:00'),
(47, 31, 71, 40, 2, 1100, '0000-00-00 00:00:00'),
(48, 32, 72, 40, 1, 100, '0000-00-00 00:00:00'),
(49, 33, 77, 40, 1, 550, '0000-00-00 00:00:00'),
(50, 34, 74, 40, 1, 600, '0000-00-00 00:00:00'),
(51, 35, 70, 40, 1, 530, '0000-00-00 00:00:00'),
(52, 36, 72, 40, 1, 100, '0000-00-00 00:00:00'),
(53, 36, 70, 40, 2, 1060, '0000-00-00 00:00:00'),
(54, 37, 74, 40, 2, 1200, '0000-00-00 00:00:00'),
(55, 37, 87, 40, 2, 1180, '0000-00-00 00:00:00'),
(56, 37, 70, 40, 1, 530, '0000-00-00 00:00:00'),
(57, 37, 86, 40, 2, 1180, '0000-00-00 00:00:00'),
(58, 38, 81, 40, 1, 520, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_orders`
--

CREATE TABLE `tbl_orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pay_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `order_total` double NOT NULL,
  `package_type` varchar(100) NOT NULL,
  `order_status` varchar(30) NOT NULL,
  `shipping_status` varchar(30) NOT NULL,
  `address_id` int(11) NOT NULL,
  `otp` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_orders`
--

INSERT INTO `tbl_orders` (`order_id`, `user_id`, `pay_id`, `order_date`, `order_total`, `package_type`, `order_status`, `shipping_status`, `address_id`, `otp`) VALUES
(6, 40, 6, '2023-03-18 16:21:27', 1650, 'Wrapping Paper', 'delivered', 'dispatched', 25, ''),
(14, 60, 14, '2023-03-18 18:02:58', 2290, 'Wrapping Paper', 'confirmed', 'not dispatched', 28, ''),
(15, 60, 15, '2023-03-18 18:08:31', 570, 'Boxes', 'placed', 'not dispatched', 28, ''),
(16, 40, 16, '2023-03-18 18:11:03', 2200, 'Wrapping Paper', 'confirmed', 'dispatched', 25, '517637'),
(17, 40, 17, '2023-03-18 19:12:35', 1640, 'Vases', 'placed', 'not dispatched', 25, ''),
(19, 40, 19, '2023-03-19 15:31:07', 3500, 'Boxes', 'delivered', 'dispatched', 25, ''),
(22, 40, 22, '2023-03-25 11:00:20', 3650, 'Boxes', 'delivered', 'dispatched', 25, '154821'),
(23, 40, 23, '2023-03-25 11:28:39', 1060, 'Boxes', 'delivered', 'dispatched', 25, '530129'),
(24, 40, 24, '2023-03-25 11:29:17', 1590, 'Boxes', 'delivered', 'dispatched', 25, ''),
(25, 40, 25, '2023-03-25 15:59:52', 590, 'Vases', 'confirmed', 'not dispatched', 25, ''),
(26, 40, 26, '2023-03-28 09:52:43', 530, 'Wrapping Paper', 'delivered', 'dispatched', 25, ''),
(28, 40, 28, '2023-03-30 09:02:26', 370, 'Wrapping Paper', 'delivered', 'dispatched', 25, ''),
(29, 40, 29, '2023-04-10 15:25:15', 16630, '', 'placed', 'not dispatched', 0, ''),
(30, 40, 30, '2023-04-10 15:30:27', 16630, 'Boxes', 'placed', 'not dispatched', 25, ''),
(31, 40, 31, '2023-04-10 15:32:25', 16630, 'Boxes', 'placed', 'not dispatched', 25, ''),
(32, 40, 32, '2023-04-10 15:36:11', 170, 'Vases', 'confirmed', 'not dispatched', 25, ''),
(33, 40, 33, '2023-04-10 15:38:59', 550, 'Vases', 'placed', 'not dispatched', 25, ''),
(34, 40, 34, '2023-04-10 15:44:31', 600, 'Boxes', 'confirmed', 'not dispatched', 25, ''),
(35, 40, 35, '2023-04-12 14:42:56', 530, 'Boxes', 'delivered', 'dispatched', 25, ''),
(36, 40, 36, '2023-04-12 15:27:04', 1160, 'Vases', 'delivered', 'dispatched', 25, ''),
(37, 40, 37, '2023-04-16 15:21:43', 4090, 'Vases', 'delivered', 'dispatched', 25, '736900'),
(38, 40, 38, '2023-04-16 16:37:08', 520, 'Wrapping Paper', 'placed', 'not dispatched', 25, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `pay_id` int(11) NOT NULL,
  `pay_method` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pay_status` varchar(30) NOT NULL,
  `amount` double NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`pay_id`, `pay_method`, `user_id`, `pay_status`, `amount`, `date_time`) VALUES
(1, 'Netbanking', 8, 'completed', 650, '2023-03-18 15:34:58'),
(2, 'Netbanking', 8, 'completed', 650, '2023-03-18 15:35:54'),
(3, 'Netbanking', 8, 'completed', 650, '2023-03-18 15:36:19'),
(4, 'Netbanking', 40, 'completed', 5770, '2023-03-18 16:13:35'),
(5, 'UPI', 40, 'completed', 1100, '2023-03-18 16:17:49'),
(6, 'UPI', 40, 'completed', 1650, '2023-03-18 16:21:27'),
(7, 'Netbanking', 8, 'completed', 570, '2023-03-18 16:42:44'),
(8, 'Netbanking', 60, 'completed', 1600, '2023-03-18 16:50:57'),
(9, 'Netbanking', 60, 'completed', 1180, '2023-03-18 16:55:56'),
(10, 'Cards', 60, 'completed', 2180, '2023-03-18 16:56:54'),
(11, 'Netbanking', 8, 'completed', 550, '2023-03-18 17:36:03'),
(12, 'Netbanking', 60, 'completed', 2270, '2023-03-18 17:59:09'),
(13, 'Netbanking', 60, 'completed', 5690, '2023-03-18 18:00:55'),
(14, 'Netbanking', 60, 'completed', 2290, '2023-03-18 18:02:58'),
(15, 'Netbanking', 60, 'completed', 570, '2023-03-18 18:08:31'),
(16, 'Netbanking', 40, 'completed', 2200, '2023-03-18 18:11:03'),
(17, 'Netbanking', 40, 'completed', 1640, '2023-03-18 19:12:35'),
(18, 'Netbanking', 60, 'completed', 3400, '2023-03-18 19:47:30'),
(19, 'Netbanking', 40, 'completed', 3500, '2023-03-19 15:31:07'),
(20, 'Netbanking', 8, 'completed', 2500, '2023-03-19 16:39:11'),
(21, 'Netbanking', 40, 'completed', 1100, '2023-03-19 17:33:17'),
(22, 'Cards', 40, 'completed', 3650, '2023-03-25 11:00:20'),
(23, 'Netbanking', 40, 'completed', 1060, '2023-03-25 11:28:39'),
(24, 'Cards', 40, 'completed', 1590, '2023-03-25 11:29:17'),
(25, 'Netbanking', 40, 'completed', 590, '2023-03-25 15:59:52'),
(26, 'Netbanking', 40, 'completed', 530, '2023-03-28 09:52:43'),
(27, 'Cards', 40, 'completed', 170, '2023-03-29 15:21:22'),
(28, 'Cards', 40, 'completed', 370, '2023-03-30 09:02:26'),
(29, '', 40, 'completed', 16630, '2023-04-10 15:25:15'),
(30, 'Netbanking', 40, 'completed', 16630, '2023-04-10 15:30:27'),
(31, '', 40, 'completed', 16630, '2023-04-10 15:32:25'),
(32, '', 40, 'completed', 170, '2023-04-10 15:36:11'),
(33, '', 40, 'completed', 550, '2023-04-10 15:38:59'),
(34, '', 40, 'completed', 600, '2023-04-10 15:44:31'),
(35, '', 40, 'completed', 530, '2023-04-12 14:42:56'),
(36, '', 40, 'completed', 1160, '2023-04-12 15:27:04'),
(37, '', 40, 'completed', 4090, '2023-04-16 15:21:43'),
(38, '', 40, 'completed', 520, '2023-04-16 16:37:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reviews`
--

CREATE TABLE `tbl_reviews` (
  `review_id` int(11) NOT NULL,
  `flower_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `review_text` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_reviews`
--

INSERT INTO `tbl_reviews` (`review_id`, `flower_id`, `user_id`, `review_text`, `rating`) VALUES
(1, 70, 40, 'Its Really Good', 4),
(3, 70, 22, 'Amazing', 4),
(4, 70, 21, 'Great Site', 5),
(5, 70, 40, 'Good', 4),
(6, 70, 40, 'Great', 5),
(7, 70, 40, 'Great', 5),
(8, 70, 40, 'Great', 5),
(9, 70, 40, 'Good', 3),
(10, 70, 16, 'Nice', 1),
(11, 71, 16, 'Good', 3),
(12, 72, 16, 'Great', 5),
(13, 86, 40, 'Great', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE `tbl_store` (
  `store_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `store_name` varchar(40) NOT NULL,
  `store_address` text NOT NULL,
  `store_phone` varchar(15) NOT NULL,
  `store_email` varchar(80) NOT NULL,
  `store_location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`store_id`, `admin_id`, `store_name`, `store_address`, `store_phone`, `store_email`, `store_location`) VALUES
(1, 1, 'E-FloraAura Website', 'HQ4Q+WPC, Church Lane, Kokkappally, Kanjirappally, Kerala 686555', '04828202961', 'efloraaura@gmail.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d35921.56155239813!2d76.75119195232992!3d9.558502233540468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b06367870b4182d%3A0x50ef44ffbde342fd!2sParnasala%20Flower%20House!5e0!3m2!1sen!2sin!4v1677417828806!5m2!1sen!2sin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `user_status` varchar(20) NOT NULL,
  `last_login` text NOT NULL,
  `date_added` date NOT NULL DEFAULT current_timestamp(),
  `verify_token` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `name`, `phone`, `email`, `password`, `user_type`, `user_status`, `last_login`, `date_added`, `verify_token`) VALUES
(16, 'Wilgimol Thomas', '+917025169137', 'w@gmail.com', '3fde24db0543b9d447b2f8abb6619a22', 'Normal', 'Active', '03:31:pm 12/04/2023', '2023-02-23', ''),
(18, 'Tilji Thomas', '+919562169137', 'tilji@gmail.com', 'f21a5acb73c8db41aea7135ac0a417b2', 'Normal', 'active', '11:35:am 25/03/2023', '2023-03-02', ''),
(21, 'Jilti Thomas', '+919947532804', 'jilti@gmail.com', '44b13ee40533aab5ff9c6d1a74484001', 'Normal', 'active', '03:17:pm 27/03/2023', '2023-03-03', ''),
(22, 'Wilson Thomas', '+917025169137', 'wilson@gmail.com', '2fff84fcde2b9ad521b707657383a38e', 'Normal', 'Active', '03:14:pm 27/03/2023', '2023-03-05', ''),
(38, 'Rosamma Philip', '+919744169137', 'rosamma@gmail.com', '53e9d2b12a2fd6a7c1875a9c98583695', 'Normal', 'Active', '11:33:am 25/03/2023', '2023-03-05', ''),
(40, 'Wilgimol Thomas', '+917025169137', 'wilgimol@gmail.com', '3fde24db0543b9d447b2f8abb6619a22', 'Normal', 'Active', '03:16:pm 16/04/2023', '2023-03-11', '5b7b6643527e506bef1dcd8f905bb3c6'),
(41, 'Wilgimol Thomas', '+917025169137', 'chakki@gmail.com', '3fde24db0543b9d447b2f8abb6619a22', 'Normal', 'Active', '11:31:am 25/03/2023', '2023-03-14', ''),
(60, 'Wilson', '+917025169137', 'wilsonthomas@gmail.com', '2fff84fcde2b9ad521b707657383a38e', 'Normal', 'Active', '07:46:pm 18/03/2023', '2023-03-18', ''),
(61, 'Jijimol Thomas', '+919497169137', 'jijimolthomas@gmail.com', 'd86405b2a2d6bf9d83b65f5d6d88cf7b', 'Normal', 'Active', '11:40:am 25/03/2023', '2023-03-25', ''),
(62, 'Philip Joseph', '+919947532804', 'philip@gmail.com', '124bec4e4eb33aa0e45f4f7f33a47a46', 'Normal', 'Deactive', '11:42:am 25/03/2023', '2023-03-25', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wishlist`
--

CREATE TABLE `tbl_wishlist` (
  `wishlist_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `flower_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_wishlist`
--

INSERT INTO `tbl_wishlist` (`wishlist_id`, `user_id`, `flower_id`, `date_added`) VALUES
(15, 18, 3, '2023-03-02 22:54:44'),
(16, 16, 4, '2023-03-03 08:57:40'),
(17, 16, 5, '2023-03-03 09:03:24'),
(20, 39, 3, '2023-03-06 18:34:59'),
(40, 40, 73, '2023-03-25 15:53:11'),
(41, 40, 70, '2023-03-28 09:53:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_address`
--
ALTER TABLE `tbl_address`
  ADD PRIMARY KEY (`address_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_flowers`
--
ALTER TABLE `tbl_flowers`
  ADD PRIMARY KEY (`flower_id`);

--
-- Indexes for table `tbl_orderdt`
--
ALTER TABLE `tbl_orderdt`
  ADD PRIMARY KEY (`orderdetails_id`);

--
-- Indexes for table `tbl_orders`
--
ALTER TABLE `tbl_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `tbl_reviews`
--
ALTER TABLE `tbl_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `tbl_store`
--
ALTER TABLE `tbl_store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  ADD PRIMARY KEY (`wishlist_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_address`
--
ALTER TABLE `tbl_address`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_flowers`
--
ALTER TABLE `tbl_flowers`
  MODIFY `flower_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `tbl_orderdt`
--
ALTER TABLE `tbl_orderdt`
  MODIFY `orderdetails_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `tbl_orders`
--
ALTER TABLE `tbl_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_reviews`
--
ALTER TABLE `tbl_reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_store`
--
ALTER TABLE `tbl_store`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
