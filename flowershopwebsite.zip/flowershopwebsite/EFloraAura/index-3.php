<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_flowers order by rating desc";
$re = mysqli_query($con, $query);
$qu = "select * from tbl_user where user_id ='$id'";
$reu = mysqli_query($con, $qu);
$ud = mysqli_fetch_array($reu);
?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/index-3.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:14 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
    ============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
    <!--Header area starts here-->
    <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Slider/Intro Section Start -->
    <div class="intro11-slider-wrap section-2">
        <div class="intro11-slider swiper-container">
            <div class="swiper-wrapper">
                <div class="intro11-section swiper-slide slide-5 slide-bg-1 bg-position">
                    <!-- Intro Content Start -->
                    <div class="intro11-content-2 text-center">
                        <h1 class="different-title">Quality</h1>
                        <h2 class="title text-white">The Gift of Flowers</h2>
                        <a href="product-details.php"
                            class="btn E-FloraAura-button  secondary-btn theme-color rounded-0">Shop Collection</a>
                    </div>
                    <!-- Intro Content End -->
                </div>
                <div class="intro11-section swiper-slide slide-6 slide-bg-1 bg-position">
                    <!-- Intro Content Start -->
                    <div class="intro11-content-2 text-center">
                        <h1 class="different-title">Welcome</h1>
                        <h2 class="title">2022 Flower Trend</h2>
                        <a href="product-details.php"
                            class="btn E-FloraAura-button  secondary-btn theme-color rounded-0">Shop Collection</a>
                    </div>
                    <!-- Intro Content End -->
                </div>
            </div>
            <!-- Slider Navigation -->
            <div class="home1-slider-prev swiper-button-prev main-slider-nav"><i class="lnr lnr-arrow-left"></i></div>
            <div class="home1-slider-next swiper-button-next main-slider-nav"><i class="lnr lnr-arrow-right"></i></div>
            <!-- Slider pagination -->
            <div class="swiper-pagination"></div>
        </div>
    </div>
    <!-- Slider/Intro Section End -->
    <!-- Shop Collection Start Here -->
    <div class="shop-collection-area gray-bg pt-no-text pb-no-text">
        <div class="container custom-area">
            <div class="row mb-30">
                <div class="col-md-6 col-custom">
                    <div class="collection-content">
                        <div class="section-title text-left">
                            <span class="section-title-1">Flowers for the</span>
                            <h3 class="section-title-3 pb-0">Birthday & Gifts</h3>
                        </div>
                        <div class="desc-content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                        </div>
                        <a href="shop.php" class="btn E-FloraAura-button secondary-btn rounded-0">Shop Collection</a>
                    </div>
                </div>
                <div class="col-md-6 col-custom">
                    <!--Single Banner Area Start-->
                    <div class="single-banner hover-style">
                        <div class="banner-img">
                            <a href="#">
                                <img src="assets/images/collection/1-1.jpg" alt="">
                                <div class="overlay-1"></div>
                            </a>
                        </div>
                    </div>
                    <!--Single Banner Area End-->
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-custom order-2 order-md-1">
                    <!--Single Banner Area Start-->
                    <div class="single-banner hover-style">
                        <div class="banner-img">
                            <a href="#">
                                <img src="assets/images/collection/1-2.jpg" alt="">
                                <div class="overlay-1"></div>
                            </a>
                        </div>
                    </div>
                    <!--Single Banner Area End-->
                </div>
                <div class="col-md-6 col-custom order-1 order-md-2">
                    <div class="collection-content">
                        <div class="section-title text-left">
                            <span class="section-title-1">Flowers for the</span>
                            <h3 class="section-title-3 pb-0">Wedding day</h3>
                        </div>
                        <div class="desc-content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                        </div>
                        <a href="shop.php" class="btn E-FloraAura-button secondary-btn rounded-0">Shop Collection</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Collection End Here -->
    <!--Product Area Start-->
    
    <!-- Banner Area Start Here -->
    <div class="banner-area mt-text-3">
        <div class="container custom-area">
            <div class="row">
                <div class="col-md-6 col-custom">
                    <!--Single Banner Area Start-->
                    <div class="single-banner hover-style mb-30">
                        <div class="banner-img">
                            <a href="#">
                                <img src="assets/images/banner/1-1.jpg" alt="">
                                <div class="overlay-1"></div>
                            </a>
                        </div>
                    </div>
                    <!--Single Banner Area End-->
                </div>
                <div class="col-md-6 col-custom">
                    <!--Single Banner Area Start-->
                    <div class="single-banner hover-style mb-30">
                        <div class="banner-img">
                            <a href="#">
                                <img src="assets/images/banner/1-3.jpg" alt="">
                                <div class="overlay-1"></div>
                            </a>
                        </div>
                    </div>
                    <!--Single Banner Area End-->
                </div>
            </div>
        </div>
    </div>
    <!-- Banner Area End Here -->
    <!-- Testimonial Area Start Here -->
    <div class="testimonial-area-2 mt-text-2">
        <div class="container custom-area">
            <div class="row">
                <div class="col-lg-6 col-custom">
                    <!--Section Title Start-->
                    <div class="section-title text-center mb-30">
                        <span class="section-title-1">We love our clients</span>
                        <h3 class="section-title-3">What They’re Saying</h3>
                    </div>
                    <!--Section Title End-->
                    <div class="testimonial-carousel swiper-container intro11-carousel-wrap arrow-style-2">
                        <div class="swiper-wrapper">
                            <div class="single-item swiper-slide">
                                <!--Single Testimonial Start-->
                                <div class="single-testimonial text-center">
                                    <div class="testimonial-img">
                                        <img src="assets/images/testimonial/testimonial1.jpg" alt="">
                                    </div>
                                    <div class="testimonial-content">
                                        <p>These guys have been absolutely outstanding. Perfect Themes and the best of
                                            all that you have many options to choose! Best Support team ever! Very fast
                                            responding! Thank you very much! I highly recommend this theme and these
                                            people!</p>
                                        <div class="testimonial-author">
                                            <h6>Katherine Sullivan <span>Customer</span></h6>
                                        </div>
                                    </div>
                                </div>
                                <!--Single Testimonial End-->
                            </div>
                            <div class="single-item swiper-slide">
                                <!--Single Testimonial Start-->
                                <div class="single-testimonial text-center">
                                    <div class="testimonial-img">
                                        <img src="assets/images/testimonial/testimonial2.jpg" alt="">
                                    </div>
                                    <div class="testimonial-content">
                                        <p>These guys have been absolutely outstanding. Perfect Themes and the best of
                                            all that you have many options to choose! Best Support team ever! Very fast
                                            responding! Thank you very much! I highly recommend this theme and these
                                            people!</p>
                                        <div class="testimonial-author">
                                            <h6>Katherine Sullivan <span>Customer</span></h6>
                                        </div>
                                    </div>
                                </div>
                                <!--Single Testimonial End-->
                            </div>
                        </div>
                        <!-- Slider Navigation -->
                        <div class="home1-slider-prev swiper-button-prev main-slider-nav"><i
                                class="lnr lnr-arrow-left"></i></div>
                        <div class="home1-slider-next swiper-button-next main-slider-nav"><i
                                class="lnr lnr-arrow-right"></i></div>
                        <!-- Slider pagination -->
                        <div class="swiper-pagination default-pagination"></div>
                    </div>
                </div>
                <div class="col-lg-6 col-custom">
                    <!--Section Title Start-->
                    <div class="section-title text-center mb-30">
                        <span class="section-title-1">From The Blogs</span>
                        <h3 class="section-title-3">Our Latest Post</h3>
                    </div>
                    <!--Section Title End-->
                    <div class="latest-post-carousel swiper-container intro11-carousel-wrap">
                        <div class="swiper-wrapper">
                            <div class="single-item swiper-slide">
                                <!--Single Blog List Start-->
                                <div class="blog-list-vertical">
                                    <div class="post-date">07/09/2022</div>
                                    <h3 class="post-title"><a href="blog-details-fullwidth.php">Post with Gallery</a>
                                    </h3>
                                    <p class="post-author">
                                        <img src="assets/images/icon/author.png" alt=""> <span>Posted by </span>
                                        <a href="#">admin </a>
                                    </p>
                                </div>
                                <!--Single Blog list End-->
                            </div>
                            <div class="single-item swiper-slide">
                                <!--Single Blog List Start-->
                                <div class="blog-list-vertical">
                                    <div class="post-date">07/09/2022</div>
                                    <h3 class="post-title"><a href="blog-details-fullwidth.php">Post with Video</a></h3>
                                    <p class="post-author">
                                        <img src="assets/images/icon/author.png" alt=""> <span>Posted by </span>
                                        <a href="#">admin </a>
                                    </p>
                                </div>
                                <!--Single Blog list End-->
                            </div>
                            <div class="single-item swiper-slide">
                                <!--Single Blog List Start-->
                                <div class="blog-list-vertical">
                                    <div class="post-date">07/09/2022</div>
                                    <h3 class="post-title"><a href="blog-details-fullwidth.php">Post with Audio</a></h3>
                                    <p class="post-author">
                                        <img src="assets/images/icon/author.png" alt=""> <span>Posted by </span>
                                        <a href="#">admin </a>
                                    </p>
                                </div>
                                <!--Single Blog list End-->
                            </div>
                            <div class="single-item swiper-slide">
                                <!--Single Blog List Start-->
                                <div class="blog-list-vertical">
                                    <div class="post-date">07/09/2022</div>
                                    <h3 class="post-title"><a href="blog-details-fullwidth.php">Standard Blog Post</a>
                                    </h3>
                                    <p class="post-author">
                                        <img src="assets/images/icon/author.png" alt=""> <span>Posted by </span>
                                        <a href="#">admin </a>
                                    </p>
                                </div>
                                <!--Single Blog list End-->
                            </div>
                        </div>
                        <!-- Slider pagination -->
                        <div class="swiper-pagination default-pagination"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial Area End Here -->
    <!-- Newsletter Area Start Here -->
    <div class="news-letter-area gray-bg pt-no-text pb-no-text mt-text-3">
        <div class="container custom-area">
            <div class="row align-items-center">
                <!--Section Title Start-->
                <div class="col-md-6 col-custom">
                    <div class="section-title text-left mb-35">
                        <h3 class="section-title-3">Send Newsletter</h3>
                        <p class="desc-content mb-0">Enter Your Email Address For Our Mailing List To Keep Your Self
                            Update</p>
                    </div>
                </div>
                <!--Section Title End-->
                <div class="col-md-6 col-custom">
                    <div class="news-latter-box">
                        <div class="newsletter-form-wrap text-center">
                            <form id="mc-form" class="mc-form">
                                <input type="email" id="mc-email" class="form-control email-box"
                                    placeholder="email@example.com" name="EMAIL">
                                <button id="mc-submit" class="btn rounded-0" type="submit">Subscribe</button>
                            </form>
                            <!-- mailchimp-alerts Start -->
                            <div class="mailchimp-alerts text-centre">
                                <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                <div class="mailchimp-success text-success"></div><!-- mailchimp-success end -->
                                <div class="mailchimp-error text-danger"></div><!-- mailchimp-error end -->
                            </div>
                            <!-- mailchimp-alerts end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Newsletter Area End Here -->
 
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->
    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="lnr lnr-arrow-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/index-3.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:17 GMT -->

</html>