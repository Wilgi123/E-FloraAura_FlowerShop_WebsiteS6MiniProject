<?php
session_start();
if (!isset($_SESSION['id'])) {
	header('location:./');
}
$id=$_SESSION['id'];
$pid=$_GET['pid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query1="select count(wishlist_id)from tbl_wishlist where flower_id='$pid' and user_id='$id'";
$re1 = mysqli_query($con, $query1);
$row1=mysqli_fetch_array($re1);
if($row1['count(wishlist_id)']==0){
	$query = "insert into tbl_wishlist(user_id,flower_id) values('$id','$pid')";
	$re = mysqli_query($con, $query);
	if($re){
		$_SESSION['status']="Added to wishlistt successfully";
		header('location:wishlist.php');
		?>
			<!--<script>
				alert("Added to wishlistt successfully");
				window.location.href = "wishlist.php";
			</script>-->
		<?php
	}
	else{
		?>
			<script>
				alert("Operation failed");
				window.location.href = "shop.php";
			</script>
		<?php
	}

}

else{
	$_SESSION['status']="Added to wishlistt successfully";
		header('location:wishlist.php');
    ?>
		<!--<script>
			alert("Operation failed");
            window.location.href = "shop.php";
		</script>-->
	<?php
}
?>