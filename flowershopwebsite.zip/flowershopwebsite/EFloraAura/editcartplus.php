<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$pid = $_GET['pid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$qc = "select * from tbl_cart where flower_id='$pid' and user_id='$id'";
$re1 = mysqli_query($con, $qc);
$row1 = mysqli_fetch_array($re1);
$qp = "select stock from tbl_flowers where flower_id='$pid'";
$re2 = mysqli_query($con, $qp);
$row2 = mysqli_fetch_array($re2);
$ps = $row2['stock'];
if ($row1['cart_qnt'] >= 5 || $row1['cart_qnt'] >= $ps) {
    ?>
    <script>
        window.location.href = "cart.php";
    </script>
    <?php
} else {
    $query4 = "update tbl_cart set cart_qnt=cart_qnt+1 where flower_id='$pid' and user_id='$id'";
    $re4 = mysqli_query($con, $query4);
}
?>
<script>
    window.location.href = "cart.php";
</script>