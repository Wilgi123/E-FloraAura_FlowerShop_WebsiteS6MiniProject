<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$uid=$_GET['uid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q="update tbl_user set user_type='premium' where user_id = '$uid'";
$re=mysqli_query($con,$q);
if ($re) {
    ?>
    <script>
        window.location.href = 'viewuser.php';
        </script>
    <?php
}
else{
    ?>
    <script>
        alert("Operation failed");
        window.location.href = 'viewuser.php';
        </script>
    <?php
}
?>