<?php
session_start();

$eid=$_GET['eid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "update tbl_blog set blog_statuses='available'where blog_id='$eid';";
$re = mysqli_query($con, $query);
if($re){
    ?>
		<script>
			
            window.location.href = "view-blog.php";
		</script>
	<?php
}
else{
    ?>
		<script>
		
            window.location.href = "view-blog.php";
		</script>
	<?php
}
?>