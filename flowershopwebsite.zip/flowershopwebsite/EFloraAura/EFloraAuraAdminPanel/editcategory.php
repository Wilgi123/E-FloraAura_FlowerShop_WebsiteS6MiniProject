<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$cid=$_GET['cid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$qc = "select * from tbl_category where category_id='$cid'";
$rec = mysqli_query($con, $qc);
$cat=mysqli_fetch_array($rec);
if (isset($_POST['editproimg'])) {

    $filename = $_FILES['image']['name'];
    $prqim = "update tbl_category set  category_image='$filename' where category_id='$cid'";
    $presim = mysqli_query($con, $prqim);
    if ($presim) {
        $targetDir = "../assets/images/flower_category/";
        $targetfilepath = $targetDir . $filename;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetfilepath);
?>

        <script>
            window.location.href = "viewcategory.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("Image updation failed");
            window.location.href = "viewcategory.php";
        </script>
    <?php
    }
}
if (isset($_POST['catadd'])) {
    $cn = $_POST['cname'];
    $cd = $_POST['cdesc'];
    $catq = "update tbl_category set category_name='$cn',category_description='$cd' where category_id='$cid'";
    $cres = mysqli_query($con, $catq);
    if ($cres) {
        ?>
        <script>
            alert("updation successful");
            window.location.href = "viewcategory.php";
        </script>
        <?php
    } else {
        ?>
        <script>
            alert("updation failed");
        </script>
        <?php
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Admin Panel</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<style>
   @media (min-width: 1200px) {

#main,
#footer {
  margin-left: 300px;
}
}

@media (max-width: 1199px) {
.toggle-sidebar .sidebar {
  left: 0;
}
}

@media (min-width: 1200px) {

.toggle-sidebar #main,
.toggle-sidebar #footer {
  margin-left: 0;
}

.toggle-sidebar .sidebar {
  left: -300px;
}
}
  </style>
<body>

<?php
    require('header.php');
  ?>


    <main id="main" class="main">

        <main id="main" class="main">

            <div class="pagetitle">
                <h1></h1>

            </div><!-- End Page Title -->
            <section class="section">
                <div class="row">
                    <div class="col-lg-8">


                        <div class="card">
                            <div class="card-body">
                                <br>
                                <h2 align ="center"style="color:#F80367;">Edit Category</h2>
                                <br>
                                <!-- Vertical Form -->
                                <form class="row g-3" action="#" method="POST" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-6">

                                            <label for="image" class="form-label">
                                                Flower Image</label><br>
                                            <div id="image-container">
                                                <img id="upload-image" src="../assets/images/flower_category/<?php echo$cat['category_image']; ?>" width="150" alt="Click to upload">
                                            </div>

                                            <input type="file" id="file-input" style="display: none;" accept="image/png, image/avif, image/gif, image/jpeg" name="image" value="<?php echo $cat['category_image']; ?>" required>

                                            <script>
                                                const uploadImage = document.getElementById("upload-image");
                                                const fileInput = document.getElementById("file-input");

                                                uploadImage.addEventListener("click", function() {
                                                    fileInput.click();
                                                });
                                            </script>
                                        </div>
                                        <div class="col-6"><br><br><br><br>
                                            <div id="editproimg" class="text-left">
                                                <button type="submit" name="editproimg" style="background-color:#F80367;border-color:#F80367;color:white;">Update
                                                    Image</button>

                                            </div>
                                        </div>
                                    </div>
                                </form><br>
                                <form class="row g-3" action="#" method="POST" enctype="multipart/form-data">
                                    <div class="col-12">

                                        <label>Category name</label>
                                        <input id="c1" type="text" class="form-control" value="<?php echo $cat['category_name']; ?>" name="cname">
                                    </div>
                                    <div class="col-12">
                                        <label>Category Description</label>
                                        <textarea id="c2" class="form-control" name='cdesc'maxlength="2000"
                                            rows="5"><?php echo $cat['category_description']; ?></textarea>
                                        
                                    </div>

                            </div>
                            <div class="text-center">
                                <button type="submit" id="catadd" name="catadd" style="background-color:#F80367;border-color:#F80367;color:white;">Edit Category</button>

                            </div>
                            <br>
                            </form><!-- Vertical Form -->

                        </div>
                    </div>


                </div>
                </div>
            </section>

        </main><!-- End #main -->

        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
                class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/chart.js/chart.umd.js"></script>
        <script src="assets/vendor/echarts/echarts.min.js"></script>
        <script src="assets/vendor/quill/quill.min.js"></script>
        <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
        <script src="assets/vendor/tinymce/tinymce.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

</body>

</html>