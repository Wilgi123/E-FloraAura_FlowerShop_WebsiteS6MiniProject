<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$cid=$_GET['cid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q="update tbl_category set status='available' where category_id = '$cid'";
$re=mysqli_query($con,$q);
if ($re) {
    ?>
    <script>
        window.location.href = 'viewcategory.php';
        </script>
    <?php
}
else{
    ?>
    <script>
        alert("Operation failed");
        window.location.href = 'viewcategory.php';
        </script>
    <?php
}
?>