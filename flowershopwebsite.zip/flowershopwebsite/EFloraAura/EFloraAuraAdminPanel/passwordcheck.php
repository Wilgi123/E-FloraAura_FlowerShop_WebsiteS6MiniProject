<!----To Check Password----->
<?php
session_start();

 if(!isset($_SESSION['admin']))
 {
    header('location:./');
 }

$id = $_SESSION['admin'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_admin where admin_id='$id'";
$re = mysqli_query($con, $query);
$ps=$_POST['pass'];
$ps=md5($ps);
$row = mysqli_fetch_array($re);
 if(isset($ps) && $ps!="") {
     if ($re) {
         if (($ps) ==$row['admin_password']) {
            echo "<script> var ver9=0;</script>";
         }
         else{
            echo "<span class='error'> &nbsp;&nbsp;Password does not match</span>
            <script> var ver9=1;</script>";
         }
     }
 }
$con->close();
ob_end_flush();
?>
<html>

<head>
    <style>
        .error {

            color: #cc0033;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 13px;
            font-weight: bold;
            line-height: 20px;
            text-shadow: 1px 1px rgba(250, 250, 250, .3);
        }
</style>
</head>
</body>
</html>