<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q = "select * from tbl_orders order by order_date";
$re = mysqli_query($con, $q);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>E-FloraAura Admin Panel</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    

    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <link rel="stylesheet" href="/DataTables/datatables.css" />
    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
<!--Datatable CSS-->
<link rel="stylesheet" href=" https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<script src="/DataTables/datatables.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>


<style>
    .editbtn {
        background-color: green;
        color: white;
        padding: 5px;
        padding-left: 5px;
        padding-right: 5px;
        border-radius: 10px;
        border: 0;
    }

    .deletebtn {
        background-color: red;
        color: white;
        padding: 10px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
        border: 0;
    }
</style>
<Style>
    @media (min-width: 1100px) {

        #main,
        #footer {
            margin-left: 130px;
        }
    }

    @media (max-width: 1199px) {
        .toggle-sidebar .sidebar {
            left: 0;
        }
    }

    @media (min-width: 1100px) {

        .toggle-sidebar #main,
        .toggle-sidebar #footer {
            margin-left: 0;
        }

        .toggle-sidebar .sidebar {
            left: -300px;
        }
    }
</Style>
<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
    </script>
<body>

    <?php
    require('header.php');
    ?>

    <main id="main" class="main">

        <main id="main" class="main">

            <section class="section">
                <div class="row">
                    <div class="col-md-12">


                        <div class="card">
                            <div class="card-body">
                                <h2 class="card-title">View Orders</h2>

                                <!-- Default Table -->
                                <table id="example" class="display" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th scope="col">Si.No</th>
                                            <th scope="col">Order ID</th>

                                            <th scope="col">Email</th>
                                            <!--<th scope="col">Order Total</th>-->
                                            <th scope="col">Date</th>
                                            <!--<th scope="col">Package Type</th>-->
                                            <th scope="col">Status</th>
                                            <!--<th scope="col">Shipping</th>-->
                                            <th scope="col">View Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $c = 1;
                                        while ($row = mysqli_fetch_array($re)) {
                                            $pid = $row['user_id'];
                                            $qp = "select * from tbl_user where user_id='$pid'";
                                            $rep = mysqli_query($con, $qp);
                                            $prod = mysqli_fetch_array($rep);
                                            ?>
                                            <tr>
                                                <th scope="row">
                                                    <?php echo $c ?>
                                                </th>
                                                <td>
                                                    <?php echo $row['order_id'] ?>
                                                </td>

                                                <td>
                                                    <?php echo $prod['email'] ?>
                                                </td>
                                                <!--<td>
                                                    <?php echo $row['order_total'] ?>
                                                </td>--->
                                            <td>
                                                <?php echo $row['order_date'] ?>
                                            </td>
                                            <!--<td>
                                                    <?php echo $row['package_type'] ?>
                                                </td>-->
                                                <td>
                                                    <?php echo $row['order_status'] ?>
                                                </td>

                                                <td><a href="view-orderdetails.php?oid=<?php echo $row['order_id']; ?>"
                                                        class='editbtn'>View Details</a><br></td>

                                                <!--<td>
                                                    <?php echo $row['shipping_status'] ?>
                                                </td>-->
                                            </tr>
                                            <?php

                                            $c++;
                                        }
                                        ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th scope="col">Si.No</th>
                                            <th scope="col">Order ID</th>

                                            <th scope="col">Email</th>
                                            <!--<th scope="col">Order Total</th>-->
                                            <th scope="col">Date</th>
                                            <!--<th scope="col">Package Type</th>-->
                                            <th scope="col">Status</th>
                                            <!--<th scope="col">Shipping</th>-->
                                            <th scope="col">View Details</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                <!-- End Default Table Example -->
                            </div>
                        </div>


                    </div>
                </div>
            </section>

        </main><!-- End #main -->


        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
                class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/chart.js/chart.umd.js"></script>
        <script src="assets/vendor/echarts/echarts.min.js"></script>
        <script src="assets/vendor/quill/quill.min.js"></script>
        <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
        <script src="assets/vendor/tinymce/tinymce.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

</body>

</html>