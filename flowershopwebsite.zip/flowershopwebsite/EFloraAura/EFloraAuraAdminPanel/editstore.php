<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$admin=$_SESSION['admin'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q2a="select * from tbl_store where admin_id='$admin'";
$re2a=mysqli_query($con,$q2a);
$row2a=mysqli_fetch_array($re2a);
if (isset($_POST['editstore'])) {
    $sn = $_POST['sname'];
    $sa = $_POST['saddress'];
    $sp = $_POST['sphone'];
    $se = $_POST['semail'];
    $sloc = $_POST['sloc'];
    
    $storeq = "update tbl_store set store_name='$sn', store_address='$sa', store_phone='$sp',store_email='$se', store_location='$sloc' where admin_id='$admin'";
    $storeres = mysqli_query($con, $storeq);
    if ($storeres) {
    ?>
        <script>
             alert("updation Successfull");
            window.location.href = "editstore.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("updation failed");
            window.location.href = "editstore.php";
        </script>
<?php
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>E-FloraAura Admin Panel</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
   <link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<Style>
 @media (min-width: 1200px) {

#main,
#footer {
  margin-left: 300px;
}
}

@media (max-width: 1199px) {
.toggle-sidebar .sidebar {
  left: 0;
}
}

@media (min-width: 1200px) {

.toggle-sidebar #main,
.toggle-sidebar #footer {
  margin-left: 0;
}

.toggle-sidebar .sidebar {
  left: -300px;
}
}

</Style>
<style>
    #error1,
    #error2,
    #error3,
    #error4,
    #error5,
    #error6,
    #error7,
    #error8,
    #error9,
    #error10,
    #error1a,
    #error2a,
    #error3a,
    #error4a,
    #error5a {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

   </style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!--<script>
    var ver1 = 1;
    var ver2 = 1;
    var ver3 = 1;
    var ver4 = 1;
    var ver5 = 1;
    var ver6 = 1;
    var ver7 = 1;
    $(document).ready(function() {
        $("#error1").hide();
        $("#error2").hide();
        $("#error3").hide();
        $("#error4").hide();
        $("#error5").hide();
        $("#error6").hide();
        var name = /^[a-zA-Z ]{3,16}$/;
        $("#f1").keyup(function() {
            x = document.getElementById("f1").value;
            if (name.test(x) == false) {
                ver1 = 1
                $("#error1").show();
            } else if (name.test(x) == true) {
                ver1 = 0;
                $("#error1").hide();
            }
        });
        var price = /^\d{1,8}(?:\.\d{1,4})?$/;
        $("#f3").keyup(function() {
            x = document.getElementById("f3").value;
            if (price.test(x) == false) {
                ver3 = 1
                $("#error3").show();
            } else if (price.test(x) == true) {
                ver3 = 0;
                $("#error3").hide();
            }
        });

        var stock = /^\d{1,8}(?:\.\d{1,4})?$/;
        $("#f4").keyup(function() {
            x = document.getElementById("f4").value;
            if (stock.test(x) == false) {
                ver4 = 1
                $("#error4").show();
            } else if (stock.test(x) == true) {
                ver4 = 0;
                $("#error4").hide();
            }
        });


        $("#addpro").click(function() {
            if (ver1 == 0 && ver3 == 0 && ver4 == 0) {
                $("#error6").hide();
                return true;
            } else {
                $("#error6").show();
                return false;
            }
        });
    });
</script>-->
<body>

<?php
    require('header.php');
  ?>

    <main id="main" class="main">

        <main id="main" class="main">
            <section class="section">
                <div class="row">
                    <div class="col-lg-8">


                        <div class="card" >
                            <div class="card-body">
                                <br>
                                <h2 align ="center"style="color:#F80367;">Update Store Details</h2>
                                <br>
                                <!-- Vertical Form -->
                                <form class="row g-3" action="#" method="POST" enctype="multipart/form-data">
                                    <div class="col-12">
                                        <label for="name" class="form-label">
                                            Store Name</label>
                                        <input type="text" class="form-control" name='sname' id="f1"value="<?php echo $row2a['store_name']; ?>" />
                                    </div>
                                    <div class="col-12">
                                        <label for="address" class="form-label">Store Address</label>
                                        <textarea id="f6" class="form-control" name='saddress' maxlength="2000"
                                            rows="5"><?php echo $row2a['store_address']; ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <label for="text" class="form-label">Store Phone
                                           </label>
                                        <input type="number" class="form-control" name="sphone" id="f3" value="<?php echo $row2a['store_phone']; ?>"/>
                                    </div>
                                    
                                    
                                    <div class="col-12">
                                        <label for="stock" class="form-label">
                                            Store Email</label>
                                        <input type="text" class="form-control" value="<?php echo $row2a['store_email']; ?>" name='semail' id="f4" />
                                    </div>
                                    <div class="col-12">
                                        <label for="stock" class="form-label">
                                            Store Location Link</label>
                                        <input type="text" class="form-control" value="<?php echo $row2a['store_location']; ?>" name='sloc' id="f4" />
                                    </div>
                                   
                                    <div id="editstore" class="text-center">
                                        <button type="submit" name="editstore" style="background-color:#F80367;border-color:#F80367;color:white;">Update Store</button>

                                    </div>

                                </form><!-- Vertical Form -->

                            </div>

                        </div>


                    </div>
                </div>
            </section>
                                    
        </main><!-- End #main -->


        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
                class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/chart.js/chart.umd.js"></script>
        <script src="assets/vendor/echarts/echarts.min.js"></script>
        <script src="assets/vendor/quill/quill.min.js"></script>
        <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
        <script src="assets/vendor/tinymce/tinymce.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

</body>

</html>