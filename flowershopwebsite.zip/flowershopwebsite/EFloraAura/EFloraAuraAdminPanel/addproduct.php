<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$id = $_SESSION['admin'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q = "select * from tbl_category";
$re = mysqli_query($con, $q);
if (isset($_POST['addpro'])) {
    $fn = $_POST['fname'];
    $fnu=strtoupper($fn);
    $fc = $_POST['fcatid'];
    $fp = $_POST['fprice'];
    $fs = $_POST['fstock'];
    $fst = $_POST['fstatus'];
    $fde = $_POST['fdesc'];
    $filename = $_FILES['image']['name'];
    $qcp="select count(upper(flower_name)) from tbl_flowers where flower_name='$fnu'";
    $re1=mysqli_query($con, $qcp);
    $rowp=mysqli_fetch_array($re1);
    if($rowp['count(upper(flower_name))']>0){
        $_SESSION['status']="Product already exist";
        
        
         ?>
       <!--  <script>alert("Product already exist");
            </script>-->
            <?php
    }
else{
    $query = "INSERT INTO tbl_flowers(flower_name, flower_price,images, category_id,descriptions, stock, statuses, rating) VALUES ('$fn','$fp','$filename','$fc','$fde','$fs','$fst',0)";
    $res = mysqli_query($con, $query);
    if ($res) {
        $targetDir = "../assets/images/product/";
        $targetfilepath = $targetDir . $filename;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetfilepath);
        $_SESSION['astatus']="Product Added successfully";
        ?>
        <!--<script>
            alert("Added successfully");
                    //window.location.href = "index.php";
        </script>-->
        <?php
    } else {
        ?>
        <script>
            alert("Product insertionfailed");
        </script>
        <?php
    }
}
}

mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>E-FloraAura Admin Panel</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
   <link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<Style>
 @media (min-width: 1200px) {

#main,
#footer {
  margin-left: 300px;
}
}

@media (max-width: 1199px) {
.toggle-sidebar .sidebar {
  left: 0;
}
}

@media (min-width: 1200px) {

.toggle-sidebar #main,
.toggle-sidebar #footer {
  margin-left: 0;
}

.toggle-sidebar .sidebar {
  left: -300px;
}
}

</Style>
<style>
    #error1,
    #error2,
    #error3,
    #error4,
    #error5,
    #error6,
    #error7,
    #error8,
    #error9,
    #error10,
    #error1a,
    #error2a,
    #error3a,
    #error4a,
    #error5a {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

   </style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    var ver1 = 1;
    var ver2 = 1;
    var ver3 = 1;
    var ver4 = 1;
    var ver5 = 1;
    var ver6 = 1;
    var ver7 = 1;
    $(document).ready(function() {
        $("#error1").hide();
        $("#error2").hide();
        $("#error3").hide();
        $("#error4").hide();
        $("#error5").hide();
        $("#error6").hide();
        /*var name = /^[a-zA-Z ]{3,16}$/;
        $("#f1").keyup(function() {
            x = document.getElementById("f1").value;
            if (name.test(x) == false) {
                ver1 = 1
                $("#error1").show();
            } else if (name.test(x) == true) {
                ver1 = 0;
                $("#error1").hide();
            }
        });*/
        var price = /^\d{1,8}(?:\.\d{1,4})?$/;
        $("#f3").keyup(function() {
            x = document.getElementById("f3").value;
            if (price.test(x) == false) {
                ver3 = 1
                $("#error3").show();
            } else if (price.test(x) == true) {
                ver3 = 0;
                $("#error3").hide();
            }
        });

        var stock = /^\d{1,8}(?:\.\d{1,4})?$/;
        $("#f4").keyup(function() {
            x = document.getElementById("f4").value;
            if (stock.test(x) == false) {
                ver4 = 1
                $("#error4").show();
            } else if (stock.test(x) == true) {
                ver4 = 0;
                $("#error4").hide();
            }
        });


        $("#addpro").click(function() {
            if ( ver3 == 0 && ver4 == 0) {
                $("#error6").hide();
                return true;
            } else {
                $("#error6").show();
                return false;
            }
        });
    });
</script>
<body>

<?php
    require('header.php');
  ?>

    <main id="main" class="main">

        <main id="main" class="main">
            <section class="section">
                <div class="row">
                
                    <div class="col-lg-8">

                    <?php
                    if (isset($_SESSION['status'])) {
                        ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            
                            <?= $_SESSION['status']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php
                        unset($_SESSION['status']);
                    } 
                    if (isset($_SESSION['astatus'])) {
                        ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            
                            <?= $_SESSION['astatus']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php
                        unset($_SESSION['astatus']);
                    } 
                    ?>
                        <div class="card" >
                       
                            <div class="card-body">
                                <br>
                                <h2 align ="center"style="color:#F80367;">Add Product</h2>
                                <br>
                                <!-- Vertical Form -->
                                <form class="row g-3" action="#" method="POST" enctype="multipart/form-data">
                                    <div class="col-12">
                                        <label for="name" class="form-label">
                                            Flower Name</label>
                                        <input type="text" class="form-control" name='fname' id="f1" />
                                    </div>
                                   
                                    <div class="col-12">
                                        <label for="fcatid" class="form-label">
                                            Choose Category</label>
                                        <select name='fcatid' id="f2" class="form-control">
                                            <?php
                                            while ($cat = mysqli_fetch_array($re)) {
                                                ?>
                                                <option class="form-control" value="<?php echo $cat['category_id'] ?>"><?php
                                                   echo $cat['category_name'] ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label for="image" class="form-label">
                                            Flower Image</label>
                                        <input type="file" class="form-control"
                                            accept="image/png, image/avif, image/gif, image/jpeg" placeholder="Upload image"
                                            name="image" required>
                                    </div>
                                    <div class="col-12">
                                        <label for="price" class="form-label">
                                            Flower Price</label>
                                        <input type="number" class="form-control" name='fprice' id="f3" />
                                    </div>
                                    <p id="error3">&nbsp;Price Cant Be Negative Values</p>
                                    <div class="col-12">
                                        <label for="address" class="form-label">Product Description</label>
                                        <input id="f6" class="form-control" name='fdesc'/>
                                    </div>
                                    <div class="col-12">
                                        <label for="stock" class="form-label">
                                            Enter Stock</label>
                                        <input type="number" class="form-control" name='fstock' id="f4" />
                                    </div>
                                    <p id="error4">&nbsp;Stock Cant Be Negative Values</p>
                                    <div class="col-12">
                                        <label for="fstatus" class="form-label">
                                            Product Status</label>
                                        <select name='fstatus' id="f5" class="form-control">

                                            <option class="form-control" value="available">Available</option>

                                            <option class="form-control" value="unavailable">Not Available</option>
                                        </select>
                                    </div>
                                    <p id="error6">&nbsp;Fill The Form Correctly</p>
                                    <div id="addpro" class="text-center">
                                        <button type="submit" name="addpro" style="background-color:#F80367;border-color:#F80367;color:white;">Add Product</button>

                                    </div>

                                </form><!-- Vertical Form -->

                            </div>

                        </div>


                    </div>
                </div>
            </section>
                                    
        </main><!-- End #main -->


        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
                class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/chart.js/chart.umd.js"></script>
        <script src="assets/vendor/echarts/echarts.min.js"></script>
        <script src="assets/vendor/quill/quill.min.js"></script>
        <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
        <script src="assets/vendor/tinymce/tinymce.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

</body>

</html>