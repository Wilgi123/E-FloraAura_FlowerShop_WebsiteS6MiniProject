<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$pid = $_GET['pid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q2 = "select * from tbl_flowers where flower_id='$pid'";
$re2 = mysqli_query($con, $q2);
$row2 = mysqli_fetch_array($re2);
$qc = "select * from tbl_category";
$rec = mysqli_query($con, $qc);
if (isset($_POST['editproimg'])) {

    $filename = $_FILES['image']['name'];
    $prqim = "update tbl_flowers set  images='$filename' where flower_id='$pid'";
    $presim = mysqli_query($con, $prqim);
    if ($presim) {
        $targetDir = "../assets/images/product/";
        $targetfilepath = $targetDir . $filename;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetfilepath);
?>

        <script>
            window.location.href = "viewproduct.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("Image updation failed");
            window.location.href = "viewproduct.php";
        </script>
    <?php
    }
}
if (isset($_POST['editpro'])) {
    $fn = $_POST['fname'];
    $fc = $_POST['fcatid'];
    $fp = $_POST['fprice'];
    $fs = $_POST['fstock'];
    $fst = $_POST['fstatus'];
    $fde = $_POST['fdesc'];

    $prq = "update tbl_flowers set flower_name='$fn', flower_price='$fp',category_id='$fc',descriptions='$fde', stock='$fs', statuses='$fst' where flower_id='$pid'";
    $pres = mysqli_query($con, $prq);
    if ($pres) {

    ?>

        <script>
            window.location.href = "viewproduct.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("updation failed");
            window.location.href = "viewproduct.php";
        </script>
<?php
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>E-FloraAura Admin Panel</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<Style>
    @media (min-width: 1200px) {

        #main,
        #footer {
            margin-left: 300px;
        }
    }

    @media (max-width: 1199px) {
        .toggle-sidebar .sidebar {
            left: 0;
        }
    }

    @media (min-width: 1200px) {

        .toggle-sidebar #main,
        .toggle-sidebar #footer {
            margin-left: 0;
        }

        .toggle-sidebar .sidebar {
            left: -300px;
        }
    }
</Style>
<style>
    #file-input {
        position: absolute;
        top: 0;
        left: 0;
        opacity: 0;
        width: 100%;
        height: 100%;
        cursor: pointer;
    }
</style>
<style>
    #error1,
    #error2,
    #error3,
    #error4,
    #error5,
    #error6,
    #error7,
    #error8,
    #error9,
    #error10,
    #error1a,
    #error2a,
    #error3a,
    #error4a,
    #error5a {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
    var ver1 = 1;
    var ver2 = 1;
    var ver3 = 1;
    var ver4 = 1;
    var ver5 = 1;
    var ver6 = 1;
    var ver7 = 1;
    $(document).ready(function() {
        $("#error1").hide();
        $("#error2").hide();
        $("#error3").hide();
        $("#error4").hide();
        $("#error5").hide();
        $("#error6").hide();


        var price = /^\d{1,8}(?:\.\d{1,4})?$/;
        $("#f3").keyup(function() {
            x = document.getElementById("f3").value;
            if (price.test(x) == false) {
                ver3 = 1
                $("#error3").show();
            } else if (price.test(x) == true) {
                ver3 = 0;
                $("#error3").hide();
            }
        });

        var stock = /^\d{1,8}(?:\.\d{1,4})?$/;
        $("#f4").keyup(function() {
            x = document.getElementById("f4").value;
            if (stock.test(x) == false) {
                ver4 = 1
                $("#error4").show();
            } else if (stock.test(x) == true) {
                ver4 = 0;
                $("#error4").hide();
            }
        });


        $("#addpro").click(function() {
            if (ver3 == 0 && ver4 == 0) {
                $("#error6").hide();
                return true;
            } else {
                $("#error6").show();
                return false;
            }
        });
    });
</script>

<body>

    <?php
    require('header.php');
    ?>

    <main id="main" class="main">

        <main id="main" class="main">
            <section class="section">
                <div class="row">
                    <div class="col-lg-8">


                        <div class="card">
                            <div class="card-body">
                                <br>
                                <h2 align="center" style="color:#F80367;">Update Product</h2>
                                <br>
                                <!-- Vertical Form -->
                                <form class="row g-3" action="#" method="POST" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-6">

                                            <label for="image" class="form-label">
                                                Flower Image</label><br>
                                            <div id="image-container">
                                                <img id="upload-image" src="../assets/images/product/<?php echo $row2['images']; ?>" width="150" alt="Click to upload">
                                            </div>

                                            <input type="file" id="file-input" style="display: none;" accept="image/png, image/avif, image/gif, image/jpeg" name="image" value="<?php echo $row2['images']; ?>" required>

                                            <script>
                                                const uploadImage = document.getElementById("upload-image");
                                                const fileInput = document.getElementById("file-input");

                                                uploadImage.addEventListener("click", function() {
                                                    fileInput.click();
                                                });
                                            </script>
                                        </div>
                                        <div class="col-6"><br><br><br><br>
                                            <div id="editproimg" class="text-left">
                                                <button type="submit" name="editproimg" style="background-color:#F80367;border-color:#F80367;color:white;">Update
                                                    Image</button>

                                            </div>
                                        </div>
                                    </div>
                                </form><br>
                                <form class="row g-3" action="#" method="POST" enctype="multipart/form-data">
                                    <div class="col-12">
                                        <label for="name" class="form-label">
                                            Flower Name</label>
                                        <input type="text" class="form-control" name='fname' id="f1" value="<?php echo $row2['flower_name']; ?>" />
                                    </div>

                                    <div class="col-12">
                                        <label for="fcatid" class="form-label">
                                            Choose Category</label>
                                        <select name='fcatid' id="f2" class="form-control">
                                            <?php
                                            while ($cat = mysqli_fetch_array($rec)) {
                                            ?>
                                                <option class="form-control" value="<?php echo $cat['category_id']; ?>" <?php if ($cat['category_id'] == $row2['category_id']) { ?>selected<?php } ?>>
                                                    <?php echo "$cat[category_name]"; ?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label for="price" class="form-label">
                                            Flower Price</label>
                                        <input type="number" class="form-control" name='fprice' id="f3" value="<?php echo $row2['flower_price']; ?>" />
                                    </div>
                                    <p id="error3">&nbsp;Price Cant Be Negative Values</p>
                                    <div class="col-12">
                                        <label for="address" class="form-label">Product Description</label>
                                        <textarea id="f6" class="form-control" name='fdesc' maxlength="2000" rows="5"><?php echo $row2['descriptions']; ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <label for="stock" class="form-label">
                                            Enter Stock</label>
                                        <input type="number" class="form-control" value="<?php echo $row2['stock']; ?>" name='fstock' id="f4" />
                                    </div>
                                    <p id="error4">&nbsp;Stock Cant Be Negative Values</p>
                                    <div class="col-12">
                                        <label for="fstatus" class="form-label">
                                            Product Status</label>
                                        <select name='fstatus' id="f5" class="form-control">

                                            <option class="form-control" value="available" <?php if ($row2['statuses'] == 'available') { ?>selected<?php } ?>>Available
                                            </option>

                                            <option class="form-control" value="unavailable" <?php if ($row2['statuses'] == 'unavailable') { ?>selected<?php } ?>>Not Available
                                            </option>
                                        </select>
                                    </div>
                                    <p id="error6">&nbsp;Fill The Form Correctly</p>
                                    <div id="editpro" class="text-center">
                                        <button type="submit" name="editpro" style="background-color:#F80367;border-color:#F80367;color:white;">Update
                                            Product</button>

                                    </div>

                                </form><!-- Vertical Form -->

                            </div>

                        </div>


                    </div>
                </div>
            </section>

        </main><!-- End #main -->


        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/chart.js/chart.umd.js"></script>
        <script src="assets/vendor/echarts/echarts.min.js"></script>
        <script src="assets/vendor/quill/quill.min.js"></script>
        <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
        <script src="assets/vendor/tinymce/tinymce.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

</body>

</html>