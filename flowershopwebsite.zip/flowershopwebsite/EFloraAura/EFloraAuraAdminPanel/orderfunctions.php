<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:../');
}
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function send_confirm_mail($total, $date, $otp, $email)
{ 
    require ("PHPMailer/PHPMailer.php");
    require ("PHPMailer/SMTP.php");
    require ("PHPMailer/Exception.php");
    $mail = new PHPMailer(true);
    try {
      //Server settings
      //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                   //Enable verbose debug output
      $mail->isSMTP();                                           //Send using SMTP
      $mail->Host       = 'smtp.gmail.com';                      //Set the SMTP server to send through
      $mail->SMTPAuth   = true;                                  //Enable SMTP authentication
      $mail->Username   = 'efloraaura@gmail.com';                 //SMTP username
      $mail->Password   = 'ahpargsqcokqjhpo';                    //SMTP password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;           //Enable implicit TLS encryption
      $mail->Port       = 465;                                   //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
  
      $mail->setFrom('efloraaura@gmail.com', 'E-FloraAura');
      $mail->addAddress($email);    
  
      //Content
      $mail->isHTML(true);                                  //Set email format to HTML
      $mail->Subject = 'Order has been confirmed';
      $mail->Body    = "<h3>Thanks for shopping with E-FloraAura</h2><br><p style='font-size:20px;'>Your order has been confirmed on $date<br>Order total : $total<br></p><br><h3>OTP for verification at time of delivery<br>$otp</h3>";
      $mail->send();
      return true;
  } catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
      return false;
  }
}
function send_delivery_mail($total, $date, $email)
{
    require ("PHPMailer/PHPMailer.php");
    require ("PHPMailer/SMTP.php");
    require ("PHPMailer/Exception.php");
    $mail = new PHPMailer(true);
    try {
      //Server settings
      //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                   //Enable verbose debug output
      $mail->isSMTP();                                           //Send using SMTP
      $mail->Host       = 'smtp.gmail.com';                      //Set the SMTP server to send through
      $mail->SMTPAuth   = true;                                  //Enable SMTP authentication
      $mail->Username   = 'efloraaura@gmail.com';                 //SMTP username
      $mail->Password   = 'ahpargsqcokqjhpo';                    //SMTP password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;           //Enable implicit TLS encryption
      $mail->Port       = 465;                                   //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
  
      $mail->setFrom('efloraaura@gmail.com', 'E-FloraAura');
      $mail->addAddress($email);    
  
      //Content
      $mail->isHTML(true);                                  //Set email format to HTML
      $mail->Subject = 'Order has been delivered';
      $mail->Body    = "<h2>Thanks for shopping with E-FloraAura</h2><br><p style='font-size:20px;'>Your order has been delivered on $date<br>Order total : $total<br></p>";
      $mail->send();
      return true;
  } catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
      return false;
  }
}
$oid = $_GET['oid'];
$fn = $_GET['fn'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$qt = "select * from tbl_orders where order_id='$oid'";
$ret = mysqli_query($con, $qt);
$ord = mysqli_fetch_array($ret);
$uid = $ord['user_id'];
$qu = "select * from tbl_user where user_id='$uid'";
$reu = mysqli_query($con, $qu);
$user = mysqli_fetch_array($reu);
$email = $user['email'];
$total = $ord['order_total'];
if ($fn == 'confirm') {
    $otp = random_int(100000, 999999);
    date_default_timezone_set("Asia/Kolkata");
    $odate=date("h:i:a d/m/Y");
    send_confirm_mail($total,$odate,$otp,$email);
    $q1 = "update tbl_orders set order_status='confirmed',otp='$otp' where order_id = '$oid'";
    $re1 = mysqli_query($con, $q1);
} else if ($fn == 'deliver') {
    $otp2=$_GET['otp'];
    if($otp2==$ord['otp']){
    date_default_timezone_set("Asia/Kolkata");
    $odate=date("h:i:a d/m/Y");
    send_delivery_mail($total,$odate,$email);
    $q2 = "update tbl_orders set order_status='delivered' where order_id = '$oid'";
    $re2 = mysqli_query($con, $q2);
    }
    else{
        ?>
        <script>
                alert("Wrong OTP");
        </script>
        <?php
    }
} else if ($fn == 'dispatch') {
    $q3 = "update tbl_orders set shipping_status='dispatched' where order_id = '$oid'";
    $re3 = mysqli_query($con, $q3);
} else {
/*if ($fn == 'confirm') {
    $q1 = "update tbl_orders set order_status='confirmed' where order_id = '$oid'";
    $re1 = mysqli_query($con, $q1);
} else if ($fn == 'deliver') {
    $q2 = "update tbl_orders set order_status='delivered' where order_id = '$oid'";
    $re2 = mysqli_query($con, $q2);
} else if ($fn == 'dispatch') {
    $q3 = "update tbl_orders set shipping_status='dispatched' where order_id = '$oid'";
    $re3 = mysqli_query($con, $q3);
} else {*/
?>
    <script>
        window.location.href = "view-orderdetails.php?oid=<?php echo $oid; ?>";
    </script>
<?php
}
?>
<script>
    window.location.href = "view-orderdetails.php?oid=<?php echo $oid; ?>";
</script>