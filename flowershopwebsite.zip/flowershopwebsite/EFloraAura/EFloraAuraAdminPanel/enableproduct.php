<?php
session_start();

$eid=$_GET['eid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "update tbl_flowers set statuses='available'where flower_id='$eid';";
$re = mysqli_query($con, $query);
if($re){
    ?>
		<script>
			
            window.location.href = "viewproduct.php";
		</script>
	<?php
}
else{
    ?>
		<script>
		
            window.location.href = "viewproduct.php";
		</script>
	<?php
}
?>