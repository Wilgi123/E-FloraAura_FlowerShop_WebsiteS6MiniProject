<?php
session_start();

$did = $_GET['did'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "update tbl_flowers set statuses='unavailable'where flower_id='$did';";
$re = mysqli_query($con, $query);
if ($re) {
	?>
	<script>

		window.location.href = "viewproduct.php";
	</script>
	<?php
} else {
	?>
	<script>

		window.location.href = "viewproduct.php";
	</script>
	<?php
}
?>