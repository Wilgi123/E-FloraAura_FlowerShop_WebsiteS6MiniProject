<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
$oid = $_GET['oid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q = "select * from tbl_orders where order_id='$oid'";
$re = mysqli_query($con, $q);
$q2 = "select * from tbl_orderdt where order_id='$oid'";
$re2 = mysqli_query($con, $q2);
$row = mysqli_fetch_array($re);
$uid = $row['user_id'];
$q3 = "select * from tbl_user where user_id='$uid'";
$re3 = mysqli_query($con, $q3);
$user = mysqli_fetch_array($re3);
$aid = $row['address_id'];
$q5 = "select * from tbl_address where address_id='$aid'";
$re5 = mysqli_query($con, $q5);
$add = mysqli_fetch_array($re5);
if (isset($_POST['delorder'])) {
    $otp = $_POST['otp'];
    ?>
    <script>
      window.location.href = "orderfunctions.php?oid=<?php echo $oid ?>&fn=deliver&otp=<?php echo $otp ?>";
    </script>
    <?php
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>E-FloraAura Admin Panel</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.ico" rel="icon" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<style>
    .editbtn {
        background-color: green;
        color: white;
        height: 50px;
      left: 74%;
     
      top: 100px;
      width: 150px;
        border-radius: 10px;
        border: 0;
    }

    .deletebtn {
        background-color: red;
        color: white;
        padding: 10px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
        border: 0;
    }
</style>
<Style>
    @media (min-width: 1100px) {

        #main,
        #footer {
            margin-left: 130px;
        }
    }

    @media (max-width: 1199px) {
        .toggle-sidebar .sidebar {
            left: 0;
        }
    }

    @media (min-width: 1100px) {

        .toggle-sidebar #main,
        .toggle-sidebar #footer {
            margin-left: 0;
        }

        .toggle-sidebar .sidebar {
            left: -300px;
        }
    }
</Style>
<style>
    table {

        width: 100%;
        max-width: 800px;
        margin: 0 auto;
        background-color: #fff;
        border: 2px solid #ddd;
        border-radius: 20px;
    }

    th,
    td {
        padding: 15px;
        text-align: left;
        font-size: 16px;
        color: #333;
        border-bottom: 1px solid #ddd;
        height: 50px;
      align-items: center;
      width: 100px;
    }

    th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
</style>

<body>

    <?php
    require('header.php');
    ?>

    <main id="main" class="main">

        <main id="main" class="main">

            <section class="section">
                <div class="row">
                    <div class="col-md-12">


                        <div class="card">
                            <div class="card-body">


                                <!-- Default Table -->
                                <h2 class="card-title">Customer Details</h2>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Customer Name </th>
                                            <th scope="col">Email address </th>
                                            <th scope="col">Shipping Address </th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>

                                            <td class="acol">
                                                <?php echo $user['name'] ?>
                                            </td>
                                            <td>
                                                <?php echo $user['email'] ?>
                                            </td>
                                            <td class="acol">
                                                <?php echo $add['name'] ?><br>
                                                <?php echo $add['address'] ?><br>
                                                <?php echo $add['postcode'] ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table><br>
                                <!-- End Default Table Example -->
                                <!-- Default Table -->
                                <h2 class="card-title">Order Status</h2>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Order Total </th>
                                            <th scope="col" colspan="2">Order Status </th>
                                            <th scope="col" colspan="2">Shipping Status </th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>

                                            <td class="acol">
                                                <?php echo $row['order_total'] ?>
                                            </td>
                                            <td class="acol">
                                                <?php echo $row['order_status'] ?>
                                            </td>

                                            <?php
                                            if ($row['order_status'] == 'placed') {
                                                ?>
                                                <td class="acol"><a
                                                        href="orderfunctions.php?oid=<?php echo $row['order_id'] ?>&fn=confirm"><button
                                                            name="confirmorder" class='editbtn'>Confirm Order</button></a>
                                                </td>
                                                <?php
                                            } else if ($row['order_status'] == 'confirmed' && $row['shipping_status'] == 'dispatched') {
                                                ?>

                                                    <td class="acol">
                                                        <form method='POST' action='#'>
                                                            <!--<a
                                                                href="orderfunctions.php?oid=<?php echo $row['order_id'] ?>&fn=deliver"></a>-->
                                                                Enter OTP : <input type='text' name='otp' /><br><br>
                                                                <button name="delorder" class='editbtn'>Confirm Delivery</button>
                                                        </form>
                                                    </td>
                                                <?php
                                            } else if ($row['order_status'] == 'confirmed' && $row['shipping_status'] == 'not dispatched') {
                                                ?>
                                                    <td class="acol">Order not dispatched</td>
                                                <?php
                                              } else {
                                                ?>
                                                    <br>
                                                    <td class="acol">Order closed</td>
                                                <?php
                                            }
                                            ?>

                                            <td class="acol">
                                                <?php echo $row['shipping_status'] ?>
                                            </td>
                                            <?php
                                            if ($row['shipping_status'] == 'not dispatched') {
                                                ?>
                                                <td class="acol"><a
                                                        href="orderfunctions.php?oid=<?php echo $row['order_id'] ?>&fn=dispatch"><button
                                                            name="dispatch" class='editbtn'>Dispatch</button></a></td>
                                                <?php
                                            } else {
                                                ?>
                                                <td class="acol">Shipping closed</td>

                                                <?php
                                            }
                                            ?>
                                        </tr>
                                    </tbody>
                                </table><br>
                                <!-- End Default Table Example -->


                                <!-- Default Table -->
                                <h2 class="card-title">Ordered Items</h2>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">SI No.</th>
                                            <th scope="col">Id</th>
                                            <th scope="col">Product Image</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $c = 1;
                                        while ($row2 = mysqli_fetch_array($re2)) {
                                            $pid = $row2['flower_id'];
                                            $q4 = "select * from tbl_flowers where flower_id='$pid'";
                                            $re4 = mysqli_query($con, $q4);
                                            $prod = mysqli_fetch_array($re4);
                                            ?>
                                            <tr>
                                                <th scope="row">
                                                    <?php echo $c ?>
                                                </th>
                                                <td>
                                                    <?php echo $row2['orderdetails_id'] ?>
                                                </td>

                                                <td>
                                                    <img src="../assets/images/product/<?php echo $prod['images'] ?>"
                                                        height="100px">
                                                </td>
                                                <td>
                                                    <?php echo $prod['flower_name'] ?>
                                                </td>
                                                <td>
                                                    <?php echo $row2['order_qnt'] ?>
                                                </td>
                                                <td>
                                                    <?php echo $row2['order_price'] ?>
                                                </td>
                                            </tr>
                                            <?php

                                            $c++;
                                        }
                                        ?>
                                    </tbody>
                                </table><br>
                                <!-- End Default Table Example -->

                                <!-- Default Table -->
                                <!--<h2 class="card-title">Order Status</h2>
                                <table style="font-size:large;width:90%;">
                                    <tr>
                                        <td class="acol">Order Total </td>
                                        <td class="acol">
                                            <?php echo $row['order_total'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="acol">Order Status </td>
                                        <td class="acol">
                                            <?php echo $row['order_status'] ?>
                                        </td>
                                        <?php
                                        if ($row['order_status'] == 'placed') {
                                            ?>
                                            <td class="acol"><a
                                                    href="orderfunctions.php?oid=<?php echo $row['order_id'] ?>&fn=confirm"><button
                                                        name="confirmorder" class='editbtn'>Confirm
                                                        Order</button></a></td>
                                            <?php
                                        } else if ($row['order_status'] == 'confirmed') {
                                            ?>
                                                <td class="acol"><a
                                                        href="orderfunctions.php?oid=<?php echo $row['order_id'] ?>&fn=deliver"><button
                                                            name="delorder" class='editbtn'>Confirm Delivery</button></a>
                                                </td>
                                            <?php
                                        } else {
                                            ?>
                                                <td class="acol">Order closed</td>
                                            <?php
                                        }
                                        ?>
                                    </tr>
                                    <tr>
                                        <td class="acol">Shipping Status </td>
                                        <td class="acol">
                                            <?php echo $row['shipping_status'] ?>
                                        </td>
                                        <?php
                                        if ($row['shipping_status'] == 'not dispatched') {
                                            ?>
                                            <td class="acol"><a
                                                    href="orderfunctions.php?oid=<?php echo $row['order_id'] ?>&fn=dispatch"><button
                                                        name="dispatch" class='editbtn'>Dispatch</button></a></td>
                                            <?php
                                        } else {
                                            ?>
                                            <td class="acol">Shipping closed</td>
                                        </tr>
                                        <?php
                                        }


                                        ?>
                                    </tbody>
                                </table>-->
                                <!-- End Default Table Example -->
                            </div>
                        </div>


                    </div>
                </div>
            </section>

        </main><!-- End #main -->


        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
                class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/chart.js/chart.umd.js"></script>
        <script src="assets/vendor/echarts/echarts.min.js"></script>
        <script src="assets/vendor/quill/quill.min.js"></script>
        <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
        <script src="assets/vendor/tinymce/tinymce.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>

</body>

</html>