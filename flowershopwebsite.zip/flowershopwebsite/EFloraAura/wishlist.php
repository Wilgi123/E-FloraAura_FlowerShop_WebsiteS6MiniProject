<?php
session_start();
if (!isset($_SESSION['id'])) {
	header('location:./');
}
$id=$_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$queryw = "select * from tbl_wishlist where user_id='$id'";
$rew = mysqli_query($con, $queryw);
$count = mysqli_num_rows($rew);
?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/wishlist.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
    * {
        box-sizing: border-box
    }

    

    /* Float cancel and delete buttons and add an equal width */
    .cancelbtn,
    .deletebtn {
        display:inline-block;
        width: 40%;
    }

    /* Add a color to the cancel button */
    .cancelbtn {
        background-color: #ccc;
        color:ivory;
        padding: 10px;
        padding-left: 20px;
        padding-right: 20px;
        border-radius: 10px;
        border: 0;
    }

    /* Add a color to the delete button */
    .deletebtn {
        background-color:#E72463;
        color:ivory;
        padding: 10px;
        padding-left: 20px;
        padding-right: 20px;
        border-radius: 10px;
        border: 0;
    }

    /* Add padding and center-align text to the container */
    .container {
        padding: 16px;
        text-align: center;
    }

    /* The Modal (background) */
    .modal {
        display: none;
        position: fixed;

        transform: translate(50px, 50px, 20px, 20px);
        width: 400px;
        max-width: 50%;
        border-radius: 50px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        padding: 50px;
        background-color: #FFFFFF;
        margin-left: 25%;
        margin-right: 25%;
    }

    /* Modal Content/Box */
    .modal-content {
        background-color: #FFFFFF;
        border-color: white;


        margin: 5% auto 15% auto;
        /* 5% from the top, 15% from the bottom and centered */

        width: 50px;
        /* Could be more or less, depending on screen size */
    }



    /* The Modal Close Button (x) */
    .close {
        position: absolute;
        right: 35px;
        top: 15px;
        font-size: 40px;
        font-weight: bold;
        color: #000003;
    }

    .close:hover,
    .close:focus {
        color: #f44336;
        cursor: pointer;
    }

    /* Clear floats */
    .clearfix::after {
        content: "";
        clear: both;
        display: table;
    }

    /* Change styles for cancel button and delete button on extra small screens */
    @media screen and (max-width: 50px) {

        .cancelbtn,
        .deletebtn {
            width: 50%;
        }
    }
</style>
<script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
<body>

 

 <!--Header area starts here-->
 <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Wishlist</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>Wishlist</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <?php
	if ($count > 0) {
	?>
    <!-- Wishlist main wrapper start -->
    <div class="wishlist-main-wrapper mt-no-text">
        <div class="container container-default-2 custom-area">
        <?php
                    if (isset($_SESSION['status'])) {
                        ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            
                            <?= $_SESSION['status']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php
                        unset($_SESSION['status']);
                    } 
                   /*if (isset($_SESSION['dstatus'])) {
                        ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            
                            <?= $_SESSION['dstatus']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php
                        unset($_SESSION['dstatus']);
                    } */
                    ?>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Wishlist Table Area -->
                    <div class="wishlist-table table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="pro-thumbnail">Image</th>
                                    <th class="pro-title">Product</th>
                                    <th class="pro-price">Price</th>
                                    <th class="pro-remove">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                while($wish=mysqli_fetch_array($rew))
                                {
                                    $pid=$wish['flower_id'];
                                    $pq="select * from tbl_flowers where flower_id='$pid'";
                                    $pre=mysqli_query($con,$pq);
                                    $prod=mysqli_fetch_array($pre);
                                ?>
                                <tr>
                                    <td class="pro-thumbnail"><a href="product-details.php?pid=<?php echo $prod['flower_id']; ?>"><img class="img-fluid" style="height:100px;" src="assets/images/product/<?php echo $prod['images']; ?>" alt="Product" /></a></td>
                                    <td class="pro-title"><?php echo $prod['flower_name']; ?></td>
                                    <td class="pro-price"><span>₹<?php echo $prod['flower_price']; ?></span></td>
                                    <td class="pro-remove"><button
                                                    onclick="document.getElementById('id01').style.display='block'"
                                                    name="btn"><i class="lnr lnr-trash"></i></button></td>
                                    
                                </tr>
                                <div id="id01" class="modal" style="height:fit-content;top:25%;">
                                            <span onclick="document.getElementById('id01').style.display='none'" class="close"
                                                title="Close Modal">&times;</span>
                                            <form method="POST">

                                                <h2>Remove Product From Wishlist</h2>
                                                <p>Are you sure you want to remove product from your wishlist ?</p>

                                                <div class="clearfix">
                                                    <button type="button" class="cancelbtn" name="cancelbtn"><a
                                                            href="wishlist.php">Cancel</a></button>&nbsp;
                                                    <button type="button" class="deletebtn" name="delconfirm"><a href="deletewish.php?wishid=<?php echo $wish['wishlist_id']; ?>">Remove</a></button>
                                                </div>

                                            </form>
                                        </div>
                                <?php
                                }
                                ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Wishlist main wrapper end -->
    <?php
	} else {
	?>
   <!-- Error 404 Area Start Here -->
   
   <div class="container">
            <div class="row">
                  <div class="col-12">
                    <div class="error_form">
                    <img align="center"src="assets/images/icon/emptywishlist.png" style =" height:300px;width:300px; " /><br>
                        
                        
                        <a href="shop.php" class="boxed-btn">Back To Product Page</a>
                        
                    </div>
                </div>
            </div>
        </div>
    
    <!-- Error 404 Area End Here -->
	<?php
	}
	?>
    <br><br>
    <!--Footer Area Start-->
    <?php
       require('footer.php');
    ?>
    <!--Footer Area End-->
    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/wishlist.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->
</html>