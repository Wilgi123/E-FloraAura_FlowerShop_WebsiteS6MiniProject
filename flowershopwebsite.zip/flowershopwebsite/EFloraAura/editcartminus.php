<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$pid = $_GET['pid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query4 = "update tbl_cart set cart_qnt=cart_qnt-1 where flower_id='$pid' and user_id='$id'";
$re4 = mysqli_query($con, $query4);
$q1="select * from tbl_cart where flower_id='$pid' and user_id='$id'";
$re1=mysqli_query($con,$q1);
$rowc=mysqli_fetch_array($re1);
if($rowc['cart_qnt']<1){
    $qd="delete from tbl_cart where flower_id='$pid' and user_id='$id'";
    $re1=mysqli_query($con,$qd);
}
?>
<script>
    window.location.href = "cart.php";
</script>
