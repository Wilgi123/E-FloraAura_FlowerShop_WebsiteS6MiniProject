<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$oid = $_GET['oid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");

$query = "delete from tbl_orderdt where order_id='$oid';";
$re = mysqli_query($con, $query);
if ($re) {
    $query1 = "delete from tbl_orders where order_id='$oid';";
    $re1 = mysqli_query($con, $query1);
    if ($re1) {
?>
        <script>
            alert("Order has been cancelled");
            window.location.href = "my-orders.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("Operation failed");
            window.location.href = "my-orders.php";
        </script>
    <?php
    }
} else {
    ?>
    <script>
        alert("Operation failed");
        window.location.href = "my-orders.php";
    </script>
<?php
}
?>