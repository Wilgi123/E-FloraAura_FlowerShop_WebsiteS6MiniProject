<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q = "select * from tbl_user where user_id='$id'";
$re = mysqli_query($con, $q);
$row = mysqli_fetch_array($re);
if (isset($_POST['editad'])) {
    $na = $_POST['aname'];
    $ad = $_POST['address'];
    $po = $_POST['apostcode'];
    $ph = $_POST['aphone'];
    $query = "insert into tbl_address(user_id,name,address,phone,postcode)values('$id','$na','$ad','$ph','$po')";
    $res = mysqli_query($con, $query);
    if ($res) {

    ?>
        <script>
            alert("Added successfully");
            window.location.href = "checkout.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("updation failed");
        </script>
<?php
    }
    mysqli_close($con);
}

?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
    ============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<style>
    /* Change styles for cancel button and delete button on extra small screens */
    @media screen and (max-width: 50px) {

        .cancelbtn,
        .deletebtn {
            width: 50%;
        }
    }
</style>
<style>
    #error1,
    #error2,
    #error3,
    #error4,
    #error5,
    #error6,
    #error7,
    #error8,
    #error9,
    #error10,
    #error1a,
    #error2a,
    #error3a,
    #error4a,
    #error5a {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

    .password-container {
        width: 100%;
        position: relative;
    }

    input,
    input[type=password] {
        width: 150px;
        height: 20px;
    }

    .fa-eye {
        position: absolute;
        top: 29%;
        right: 4%;
        cursor: pointer;
        color: lightgray;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    var ver1a = 1;
    var ver2a = 1;
    var ver3a = 1;
    var ver4a = 1;
    var ver5a = 1;
    var ver6a = 1;
    var ver7a = 1;
    $(document).ready(function() {
        $("#error1a").hide();
        $("#error2a").hide();
        $("#error3a").hide();
        $("#error4a").hide();
        $("#error5a").hide();
        var name = /^[a-zA-Z ]{3,16}$/;
        $("#a1").keyup(function() {
            x = document.getElementById("a1").value;
            if (name.test(x) == false) {
                ver1a = 1
                $("#error1a").show();
            } else if (name.test(x) == true) {
                ver1a = 0;
                $("#error1a").hide();
            }
        });

        var ad = /^[#.0-9a-zA-Z\s,-]+$/;
        $("#a2").keyup(function() {
            x = document.getElementById("a2").value;
            if (ad.test(x) == false) {
                ver1a = 1
                $("#error2a").show();
            } else if (ad.test(x) == true) {
                ver1a = 0;
                $("#error2a").hide();
            }
        });

        var post = /^[1-9]{1}[0-9]{2}\s{0,1}[0-9]{3}$/;
        $("#a3").keyup(function() {
            x = document.getElementById("a3").value;
            if (post.test(x) == false) {
                ver1a = 1
                $("#error3a").show();
            } else if (post.test(x) == true) {
                ver1a = 0;
                $("#error3a").hide();
            }
        });
        var ph = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
        $("#a4").keyup(function() {
            x = document.getElementById("a4").value;
            if (ph.test(x) == false) {
                ver2a = 1
                $("#error4a").show();
            } else if (ph.test(x) == true) {
                ver2a = 0;
                $("#error4a").hide();
            }
        });

        $("#addaddress").click(function() {
            if (ver1a == 0 && ver2a == 0) {
                $("#error5a").hide();
                return true;
            } else {
                $("#error5a").show();
                return false;
            }
        });
    });
</script>
<!--<script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>-->

<body>

    <!--Header area starts here-->
    <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Shopping Cart</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>Shopping Cart</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <div class="login-register-area mt-no-text">
        <div class="container custom-area">
            <div class="row">
                <div class="myaccount-content">
                    <h3>Add Address</h3>
                    <div class="account-details-form">
                        <form action="#" method="POST">

                            <div class="single-input-item mb-3">
                                <label for="name" class="required mb-1">
                                    Name</label>
                                <input type="text" name='aname' id="a1" placeholder="Name" />
                            </div>
                            <p id="error1a">&nbsp;Only alphabets are allowed</p>
                            <br>
                            <div class="single-input-item mb-3">
                                <label for="address" class="required mb-1">Address</label>
                                <textarea id="a2" class="address-area" name='address' placeholder="Address"
                                    rows="5"></textarea>
                            </div>
                            <p id="error2a">&nbsp;Enter a valid Address</p>
                            <br>
                            <div class="single-input-item mb-3">
                                <label for="postcode" class="required mb-1">Postcode</label>
                                <input type="text" id="a3" name='apostcode' placeholder="Postcode" />
                            </div>
                            <p id="error3a">&nbsp;Enter a valid Postcode</p>
                            <br>
                            <div class="single-input-item mb-3">
                                <label for="phone" class="required mb-1">Phone Number</label>
                                <input type="text" id="a4" name='aphone' placeholder="Phone" />
                            </div>
                            <p id="error4a">&nbsp;Enter a valid number</p>
                            <br>

                            <p id="error5a">&nbsp;Please fill the form correctly.</p><br>
                            <br>
                            <div id="addaddress" class="single-input-item mb-3">
                                <button class="btn flosun-button secondary-btn theme-color rounded-0" name="editad">Add
                                    Address</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!-- Login Area End Here -->
    <br>
    <br>
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->

</html>