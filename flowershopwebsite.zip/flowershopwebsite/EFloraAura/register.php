<?php
session_start();
if (isset($_POST['submit'])) {
    $na = $_POST['name'];
    $ph = $_POST['phone'];
    $ma = $_POST['mail'];
    $ps = $_POST['password'];
    $ps = md5($ps);
    //$hash=password_hash($ps, PASSWORD_DEFAULT);
    $con = mysqli_connect("localhost", "root", "", "flower_shop");
    $query = "insert into tbl_user(name,phone,email,password,user_type,user_status) values('$na','$ph','$ma','$ps','Normal','Active')";
    $re = mysqli_query($con, $query);
    if ($re) {
        $_SESSION['status']="Registration Successful";
        header('location:login.php');
        ?>
        <!--<script>
            alert("registration successful");
            window.location.href = "login.php";
        </script>-->
        <?php
    } else {
        ?>
        <script>
            alert("registration failed");
        </script>
        <?php
    }
    mysqli_close($con);
}
?>

<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/flosun/flosun/register.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
    ============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
    #error1,
    #error3,
    #error4,
    #error5,
    #error6,
    #error2,
    #error7 {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

    .password-container {
        width: 100%;
        position: relative;
    }

    input,
    input[type=password] {
        width: 150px;
        height: 20px;
    }

    .fa-eye {
        position: absolute;
        top: 29%;
        right: 4%;
        cursor: pointer;
        color: lightgray;
    }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    var ver1 = 1;
    var ver2 = 1;
    var ver3 = 1;
    var ver4 = 1;
    var ver5 = 1;
    var ver6 = 1;
    var ver7 = 1;
    $(document).ready(function () {
        $("#error1").hide();
        $("#error2").hide();
        $("#error3").hide();
        $("#error4").hide();
        $("#error5").hide();
        $("#error7").hide();
        $("#error6").hide();
        var fname = /^[a-zA-Z ]{3,16}$/;
        $("#p1").keyup(function () {
            x = document.getElementById("p1").value;
            if (fname.test(x) == false) {
                ver1 = 1
                $("#error1").show();
            } else if (fname.test(x) == true) {
                ver1 = 0;
                $("#error1").hide();
            }
        });
        var ph = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
        $("#p2").keyup(function () {
            x = document.getElementById("p2").value;
            if (ph.test(x) == false) {
                ver2 = 1
                $("#error2").show();
            } else if (ph.test(x) == true) {
                ver2 = 0;
                $("#error2").hide();
            }
        });
        var mail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{3,4})+$/;
        $("#p3").keyup(function () {
            x = document.getElementById("p3").value;
            if (mail.test(x) == false) {
                ver4 = 1;
                $("#error3").show();
            } else if (mail.test(x) == true) {
                ver4 = 0;
                $("#error3").hide();
            }
        });
        var pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        $("#p4").keyup(function () {
            x = document.getElementById("p4").value;
            if (pass.test(x) == false) {
                ver5 = 1;
                $("#error4").show();
            } else if (pass.test(x) == true) {
                ver5 = 0;
                $("#error4").hide();
            }
        });
        $("#p5").keyup(function () {
            pass1 = document.getElementById("p4").value;
            pass2 = document.getElementById("p5").value;
            if (pass1 != pass2) {
                ver6 = 1;
                $("#error5").show();
            } else if (pass1 == pass2) {
                ver6 = 0;
                $("#error5").hide();
            }
        });
        $("#submit").click(function () {
            if (ver1 == 0 && ver2 == 0 && ver3 == 0 && ver4 == 0 && ver5 == 0 && ver6 == 0 && ver7 == 0) {
                $("#error6").hide();
                return true;
            } else {
                $("#error6").show();
                return false;
            }
        });
    });


    function checkmailAvailability() {
        $("#loaderIcon").show();
        jQuery.ajax({
            url: "mailavailable.php",
            data: 'email=' + $("#p3").val(),
            type: "POST",
            success: function (data) {
                $("#mail-availability-status").html(data);
            },
            error: function () { }
        });
    }
</script>

<body>



    <!-- Header Area Start Here -->
    <header class="main-header-area">
        <!-- Main Header Area Start -->
        <div class="main-header header-sticky">
            <div class="container custom-area">
                <div class="row align-items-center">
                    <div class="col-lg-2 col-xl-2 col-md-6 col-6 col-custom">
                        <div class="header-logo d-flex align-items-center">
                            <a href="index.php">
                                <img class="img-full" src="assets/images/logo/logo.png" alt="Header Logo">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 d-none d-lg-flex justify-content-center col-custom">
                        <nav class="main-nav d-none d-lg-flex">
                            <ul class="nav">
                                <li>
                                    <a href="index-3.php">
                                        <span class="menu-text"> Home</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="index-shop.php">
                                        <span class="menu-text">Shop</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="index-blog-details-fullwidth.php">
                                        <span class="menu-text"> Blog</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="about.php">
                                        <span class="menu-text"> About Us</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="contact.php">
                                        <span class="menu-text">Contact Us</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="login.php">
                                        <span class="menu-text">Login</span>
                                    </a>
                                </li>
                                
                            </ul>
                        </nav>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- Main Header Area End -->
           </header>
    <!-- Header Area End Here -->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Login-Register</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>Login-Register</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <!-- Register Area Start Here -->
    <div class="login-register-area mt-no-text">
        <div class="container container-default-2 custom-area">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-custom">
                    <div class="login-register-wrapper">
                        <div class="section-content text-center mb-5">
                            <h2 class="title-4 mb-2">Create Account</h2>
                            <p class="desc-content">Please Register using account detail bellow.</p>
                        </div>
                        <form action="#" method="post">
                            <div class="single-input-item mb-3">
                                <input type="text" placeholder="Enter Your Name" id="p1" name="name" required>
                            </div>
                            <p id="error1">&nbsp;Only alphabets are allowed</p>
                            <div class="single-input-item mb-3">
                                <input type="text" placeholder="Enter Phone Number" id="p2" name="phone" required>
                            </div>
                            <p id="error2">&nbsp;Enter a valid number</p>
                            <div class="single-input-item mb-3">
                                <input type="email" id="p3" placeholder="Enter Your Email" name="mail"
                                    onKeyup="checkmailAvailability()" required>
                            </div>
                            <p id="mail-availability-status"></p>
                            <p id="error3">&nbsp;Use a valid email address</p>
                            <div class="single-input-item mb-3">
                                <input type="password"  placeholder="Enter your Password" id="p4" name="password"
                                    required>
                            </div>
                            <p id="error4">&nbsp;Password should include at-least eight characters,uppercase
                                letter,lowercase
                                letter,number and special character.</p>
                            <div class="single-input-item mb-3">
                                <input type="password" id="p5" placeholder="Confirm Password" name="cpassword" required>

                            </div>
                            <p id="error5">&nbsp;Both passwords should match.</p><br>
                            <p id="error6">&nbsp;Please fill the form correctly.</p><br>
                            <div class="single-input-item mb-3">
                                <div class="login-reg-form-meta d-flex align-items-center justify-content-between">
                                    <div class="remember-meta mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="rememberMe">
                                            <label class="custom-control-label" for="rememberMe">Subscribe Our
                                                Newsletter</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="single-input-item mb-3">
                                <center>
                                    <button class="btn flosun-button secondary-btn theme-color rounded-0"
                                        name="submit">Register</button>
                                </center>

                            </div>
                            <div class="single-input-item">
                                <center>
                                    <p class="login-register-text">Have an account ? <a href="login.php"><b>Sign In
                                                Here</b></a>.</p>
                                </center>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Register Area End Here -->
     <!--Footer Area Start-->
     <?php
       require('footer.php');
    ?>
    <!--Footer Area End-->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/flosun/flosun/register.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

</html>