<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_cart where user_id='$id';";
$recart = mysqli_query($con, $query);
$query1 = "select * from tbl_user where user_id='$id';";
$re1 = mysqli_query($con, $query1);
$querya = "select * from tbl_address where user_id='$id';";
$rea = mysqli_query($con, $querya);
if(isset($_POST['order']))
{
    $total = $_SESSION['ordertotal'];
    $_SESSION['address']=$_POST['address'];
    $_SESSION['paymethod']=$_POST['paymethod'];
    $_SESSION['pack']=$_POST['pack'];
    header("Location:payment.php");
}
?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/checkout.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <!--Header area starts here-->
    <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Checkout</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>Checkout</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <!-- Checkout Area Start Here -->
    <div class="checkout-area mt-no-text">
        <form action="#" method="POST">
            <div class="container custom-container">

                <div class="row">
                    <div class="col-lg-6 col-12 col-custom">
                        <div class="coupon-accordion">
                            <h3><span id="showdelivery"> Choose Delivery Address</span></h3>
                            <div id="delivery" class="coupon-content">



                                <?php
                                while ($add = mysqli_fetch_array($rea)) {
                                ?>
                                    <br>
                                    <div><label>
                                            <input type="radio" name="address" value="<?php echo $add['address_id'] ?>" /> <?php echo $add['name'] ?><br>
                                            &nbsp;&nbsp;&nbsp;<?php echo $add['phone'] ?><br>
                                            &nbsp;&nbsp;&nbsp;
                                            <?php echo $add['address'] ?><br>&nbsp;&nbsp;&nbsp; <?php echo $add['postcode'] ?></label>
                                        <br>

                                    </div>
                                    <br>
                                <?php
                                }
                                ?>
                                <br>
                                <div id="addaddress" class="single-input-item mb-3">
                                <button class="btn flosun-button secondary-btn theme-color rounded-0" name="editad"><a style="color:white;" href="addaddress.php">Add new
                                                        address</a></button>
                            </div>


                            </div>
                            
                            <h3><span id="showpackage">Choose Packaging</span></h3>
                            <div id="package" class="coupon-checkout-content">
                                <div class="coupon-info">
                                    <label>&nbsp;&nbsp;<input type="radio" name="pack" value="Wrapping Paper" required />&nbsp;&nbsp;&nbsp;Wrapping Paper</label><br>
                                    <label>&nbsp;&nbsp;<input type="radio" name="pack" value="Boxes" />&nbsp;&nbsp;&nbsp;Boxes</label><br>
                                    <label>&nbsp;&nbsp;<input type="radio" name="pack" value="Vases" required />&nbsp;&nbsp;&nbsp;Vases</label><br>
                                    <label>&nbsp;&nbsp;<input type="radio" name="pack" value="Cellophane" />&nbsp;&nbsp;&nbsp;Cellophane</label><br>
                                </div>
                            </div>
                            <!--<h3>Have a coupon? <span id="showcoupon">Click here to enter your code</span></h3>
                            <div id="checkout_coupon" class="coupon-checkout-content">
                                <div class="coupon-info">

                                    <p class="checkout-coupon">
                                        <input placeholder="Coupon code" type="text">
                                        <input class="coupon-inner_btn" value="Apply Coupon" type="submit">
                                    </p>

                                </div>
                            </div>--->
                        </div>
                    </div>
                    <div class="col-lg-6 col-12 col-custom">
                        <div class="your-order">
                            <h3>Your order</h3>
                            <div class="your-order-table table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="cart-product-name">Product</th>
                                            <th class="cart-product-total">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $subtotal = 0;
                                        $ship = 70;
                                        $total = 0;
                                        while ($cart = mysqli_fetch_array($recart)) {
                                            $pid = $cart['flower_id'];
                                            $queryp = "select * from tbl_flowers where flower_id='$pid';";
                                            $rep = mysqli_query($con, $queryp);
                                            $rowp = mysqli_fetch_array($rep);
                                        ?>
                                            <tr class="cart_item">
                                                <td class="cart-product-name"><?php echo $rowp['flower_name']; ?><strong class="product-quantity">
                                                        × <?php echo $cart['cart_qnt']; ?></strong></td>
                                                <td class="cart-product-total text-center"><span class="amount">₹<?php echo $cart['cart_qnt'] * $cart['cart_price']; ?></span></td>
                                            </tr>
                                        <?php
                                            $subtotal = $subtotal + ($cart['cart_qnt'] * $cart['cart_price']);
                                        }
                                        if ($subtotal > 500) {
                                            $ship = 0;
                                        }
                                        $total = $subtotal + $ship;
                                        $_SESSION['ordertotal']=$total;
                                        ?>

                                    </tbody>

                                    <tfoot>
                                        <tr class="cart-subtotal">
                                            <th>Cart Subtotal</th>
                                            <td class="text-center"><span class="amount">₹<?php echo $subtotal; ?></span></td>
                                        </tr>
                                        <tr class="cart-subtotal">
                                            <th>Shipping</th>
                                            <td class="text-center"><span class="amount">₹<?php echo $ship; ?></span></td>
                                        </tr>
                                        <tr class="order-total">
                                            <th>Order Total</th>
                                            <td class="text-center"><strong><span class="amount">₹<?php echo $total; ?></span></strong></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <div class="payment-method">
                                <div class="payment-accordion">
                                    
                                    <div class="order-button-payment">
                                        <button  name="order" class="btn E-FloraAura-button secondary-btn black-color rounded-0 w-100">Place Order</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- Checkout Area End Here -->
    <br>
    <br>
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/checkout.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

</html>