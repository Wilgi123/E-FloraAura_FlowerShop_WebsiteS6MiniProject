<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_orders where user_id='$id' and order_status != 'delivered' order by order_date desc";
$re1 = mysqli_query($con, $query);
$query1 = "select * from tbl_orders where user_id='$id' and order_status = 'delivered' and shipping_status='dispatched' order by order_date desc";
$re2 = mysqli_query($con, $query1);
$count = mysqli_num_rows($re2);
$qu = "select * from tbl_user where user_id ='$id'";
$reu = mysqli_query($con, $qu);
$ud = mysqli_fetch_array($reu);
?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<body>

    <!--Header area starts here-->
    <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">My Orders</h3>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <?php
    if ($count > 0) {
    ?>
        <!-- my account wrapper start -->
        <div class="my-account-wrapper mt-no-text">
            <div class="container container-default-2 custom-area">

                <?php
                if (isset($_SESSION['orderstatus'])) {
                ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">

                        <?= $_SESSION['orderstatus']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php
                    unset($_SESSION['orderstatus']);
                }
                ?>
                <div class="row">
                    <div class="myaccount-content">
                        <h3>Orders</h3>
                        <div class="myaccount-table table-responsive text-center">
                            <table class="table table-bordered">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Order</th>
                                        <th>Date</th>
                                        <th>Order Status</th>
                                        <th>Total</th>
                                        <th>Shipping Status</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $c = 1;
                                    while ($order = mysqli_fetch_array($re1)) {
                                    ?>
                                        <tr>
                                            <td><?php echo $c ?></td>
                                            <td><?php echo $order['order_date']; ?></td>
                                            <td><?php echo $order['order_status']; ?></td>
                                            <td>₹<?php echo $order['order_total']; ?></td>
                                            <td><?php echo $order['shipping_status']; ?></td>
                                            <td><a href="my-orderdetails.php?oid=<?php echo $order['order_id']; ?>" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0">View Details</a></td>
                                            <td><a href="order-delete.php?oid=<?php echo $order['order_id']; ?>" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0"><i class="lnr lnr-trash">Cancel Order</a></td>
                                        </tr>
                                    <?php
                                        $c++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Single Tab Content End -->
            </div>
        </div>
        <div class="my-account-wrapper mt-no-text">
            <div class="container container-default-2 custom-area">

                <?php
                if (isset($_SESSION['orderstatus'])) {
                ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">

                        <?= $_SESSION['orderstatus']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php
                    unset($_SESSION['orderstatus']);
                }
                ?>
                <div class="row">
                    <div class="myaccount-content">
                        <h3>Order History</h3>
                        <div class="myaccount-table table-responsive text-center">
                            <table class="table table-bordered">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Order</th>
                                        <th>Date</th>
                                        <th>Order Status</th>
                                        <th>Total</th>
                                        <th>Shipping Status</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $c = 1;
                                    while ($order1 = mysqli_fetch_array($re2)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $c ?></td>
                                            <td><?php echo $order1['order_date']; ?></td>
                                            <td><?php echo $order1['order_status']; ?></td>
                                            <td>₹<?php echo $order1['order_total']; ?></td>
                                            <td><?php echo $order1['shipping_status']; ?></td>
                                            <td><a href="my-orderdetails.php?oid=<?php echo $order1['order_id']; ?>" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0">View Details</a></td>
                                        </tr>
                                    <?php
                                        $c++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Single Tab Content End -->
            </div>
        </div>
    <?php
    } else {
    ?>
        <!-- Error 404 Area Start Here -->

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="error_form">
                        <img align="center" src="assets/images/icon/cartempty.gif" style=" height:200px;width:200px; " />
                        <h2>Your Order history is emptyy</h2>
                        <h3>Buy some products first</h3>

                        <a href="shop.php" class="boxed-btn">Back To Product Page</a>

                    </div>
                </div>
            </div>
        </div>

        <!-- Error 404 Area End Here -->
    <?php
    }
    ?>
    <!-- My Account Page End -->

    <br>
    <br>
    <br>
    <!-- my account wrapper end -->
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->

</html>