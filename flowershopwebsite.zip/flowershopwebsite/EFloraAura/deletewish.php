<?php
session_start();
if (!isset($_SESSION['id'])) {
	header('location:./');
}
$id=$_SESSION['id'];
$wishid=$_GET['wishid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "delete from tbl_wishlist where wishlist_id='$wishid';";
$re = mysqli_query($con, $query);
if($re){
    ?>
		<script>
			
            window.location.href = "wishlist.php";
		</script>
	<?php
}
else{
    ?>
		<script>
			alert("Operation failed");
            window.location.href = "wishlist.php";
		</script>
	<?php
}
?>