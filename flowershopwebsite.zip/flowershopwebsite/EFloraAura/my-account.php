<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q = "select * from tbl_user where user_id='$id'";
$re = mysqli_query($con, $q);
$row = mysqli_fetch_array($re);
if (isset($_POST['update'])) {
    $na = $_POST['name'];
    $ph = $_POST['phone'];
    $query = "update tbl_user set name='$na',phone='$ph' where user_id='$id'";
    $res = mysqli_query($con, $query);
    if ($res) {

?>
        <script>
            alert("updation successful");
            window.location.href = "my-account.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("updation failed");
        </script>
    <?php
    }
}
if (isset($_POST['confirm'])) {
    $op = $_POST['password'];
    $op = md5($op);
    $ps = $_POST['npassword'];
    $ps = md5($ps);
    $hash = password_hash($ps, PASSWORD_DEFAULT);
    $query1 = "update tbl_user set password='$ps' where user_id='$id' and password='$op'";
    $re1 = mysqli_query($con, $query1);
    if ($re1) {
    ?>
        <script>
            alert("password changed successfully");
        </script>
    <?php
        header('Location: login.php');
    } else {
    ?>
        <script>
            alert("password change failed");
        </script>
    <?php
    }
}
if (isset($_POST['editad'])) {
    $na = $_POST['aname'];
    $ad = $_POST['address'];
    $po = $_POST['apostcode'];
    $ph = $_POST['aphone'];
    $query = "insert into tbl_address(user_id,name,address,phone,postcode)values('$id','$na','$ad','$ph','$po')";
    $res = mysqli_query($con, $query);
    if ($res) {

    ?>
        <script>
            alert("Added successfully");
            window.location.href = "my-account.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("updation failed");
        </script>
<?php
    }
    mysqli_close($con);
}

?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/my-account.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
    ============================================ -->
    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css'>

    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
    #error1,
    #error2,
    #error3,
    #error4,
    #error5,
    #error6,
    #error7,
    #error8,
    #error9,
    #error10,
    #error1a,
    #error2a,
    #error3a,
    #error4a,
    #error5a {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

    .password-container {
        width: 100%;
        position: relative;
    }

    input,
    input[type=password] {
        width: 150px;
        height: 20px;
    }

    .fa-eye {
        position: absolute;
        top: 29%;
        right: 4%;
        cursor: pointer;
        color: lightgray;
    }
</style>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    var ver1 = 1;
    var ver2 = 1;
    $(document).ready(function() {
        $("#error1").hide();
        $("#error2").hide();
        $("#error3").hide();
        $("#error4").hide();
        var name = /^[a-zA-Z ]{3,16}$/;
        $("#p1").keyup(function() {
            x = document.getElementById("p1").value;
            if (name.test(x) == false) {
                ver1 = 1
                $("#error1").show();
            } else if (name.test(x) == true) {
                ver1 = 0;
                $("#error1").hide();
            }
        });
        var ph = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
        $("#p2").keyup(function() {
            x = document.getElementById("p2").value;
            if (ph.test(x) == false) {
                ver2 = 1
                $("#error2").show();
            } else if (ph.test(x) == true) {
                ver2 = 0;
                $("#error2").hide();
            }
        });

        $("#update").click(function() {
            if (ver1 != 0 && ver2 != 0) {
                $("#error4").show();
                return false;
            } else {
                $("#error4").hide();
                return true;
            }
        });
    });
</script>
<script>
    var ver1a = 1;
    var ver2a = 1;
    var ver3a = 1;
    var ver4a = 1;
    var ver5a = 1;
    var ver6a = 1;
    var ver7a = 1;
    $(document).ready(function() {
        $("#error1a").hide();
        $("#error2a").hide();
        $("#error3a").hide();
        $("#error4a").hide();
        $("#error5a").hide();
        var name = /^[a-zA-Z ]{3,16}$/;
        $("#a1").keyup(function() {
            x = document.getElementById("a1").value;
            if (name.test(x) == false) {
                ver1a = 1
                $("#error1a").show();
            } else if (name.test(x) == true) {
                ver1a = 0;
                $("#error1a").hide();
            }
        });

        var ad = /^[#.0-9a-zA-Z\s,-]+$/;
        $("#a2").keyup(function() {
            x = document.getElementById("a2").value;
            if (ad.test(x) == false) {
                ver1a = 1
                $("#error2a").show();
            } else if (ad.test(x) == true) {
                ver1a = 0;
                $("#error2a").hide();
            }
        });

        var post = /^[1-9]{1}[0-9]{2}\s{0,1}[0-9]{3}$/;
        $("#a3").keyup(function() {
            x = document.getElementById("a3").value;
            if (post.test(x) == false) {
                ver1a = 1
                $("#error3a").show();
            } else if (post.test(x) == true) {
                ver1a = 0;
                $("#error3a").hide();
            }
        });
        var ph = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
        $("#a4").keyup(function() {
            x = document.getElementById("a4").value;
            if (ph.test(x) == false) {
                ver2a = 1
                $("#error4a").show();
            } else if (ph.test(x) == true) {
                ver2a = 0;
                $("#error4a").hide();
            }
        });

        $("#addaddress").click(function() {
            if (ver1a == 0 && ver2a == 0) {
                $("#error5a").hide();
                return true;
            } else {
                $("#error5a").show();
                return false;
            }
        });
    });
</script>
<script>
    var ver7 = 1;
    var ver8 = 1;
    var ver9 = 1;
    var ver11 = 1;
    $(document).ready(function() {
        $("#error8").hide();
        /* $("#error3").hide();*/
        $("#error9").hide();
        $("#error10").hide();

        var pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        $("#p8").keyup(function() {
            x = document.getElementById("p8").value;
            if (pass.test(x) == false) {
                ver7 = 1;
                $("#error8").show();
            } else if (pass.test(x) == true) {
                ver7 = 0;
                $("#error8").hide();
            }
        });
        var pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        $("#p9").keyup(function() {
            pass = document.getElementById("p8").value;
            pass2 = document.getElementById("p9").value;
            if (pass != pass2) {
                ver8 = 1;
                $("#error9").show();
            } else {
                ver8 = 0;
                $("#error9").hide();
            }
        });
        $("#confirm").click(function() {
            if (ver7 == 0 && ver8 == 0 && ver9 == 0) {
                $("#error10").hide();
                return true;
            } else {
                $("#error10").show();
                return false;
            }
        });
    });

    function checkpass() {
        $("#loaderIcon").show();
        jQuery.ajax({
            url: "passwordcheck.php",
            data: 'pass=' + $("#p7").val(),
            type: "POST",
            success: function(data) {
                $("#password-availability-status").html(data);
            },
            error: function() {}
        });
    }
</script>
<style>
    .address-area {
        background: #ffffff;
        border: 1px solid #dddddd;
    }

    .address-area:focus {
        border: 1px solid #E72463;
    }
</style>

<body>

    <!--Header area starts here-->
    <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">My Account</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>My Account</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <!-- my account wrapper start -->
    <div class="my-account-wrapper mt-no-text">
        <div class="container container-default-2 custom-area">
            <div class="row">
                <div class="col-lg-12 col-custom">
                    <!-- My Account Page Start -->
                    <div class="myaccount-page-wrapper">
                        <!-- My Account Tab Menu Start -->
                        <div class="row">
                            <div class="col-lg-3 col-md-4 col-custom">
                                <div class="myaccount-tab-menu nav" role="tablist">
                                    <a href="#dashboad" class="active" data-bs-toggle="tab"><i class="fa fa-dashboard"></i>
                                        Account Details</a>
                                   <!-- <a href="#orders" data-bs-toggle="tab"><i class="fa fa-cart-arrow-down"></i>
                                        Orders</a>-->
                                   <!-- <a href="#download" data-bs-toggle="tab"><i class="fa fa-cloud-download"></i>
                                        Download</a>
                                    <a href="#payment-method" data-bs-toggle="tab"><i class="fa fa-credit-card"></i>
                                        Payment Method</a>-->

                                    <a href="#address-edit" data-bs-toggle="tab"><i class="fa fa-map-marker"></i>
                                        Add Address</a>

                                    <a href="#account-info" data-bs-toggle="tab"><i class="fa fa-user"></i> View
                                        Address</a>
                                    <a href="#password-change" data-bs-toggle="tab"><i class="fa fa-lock"></i> Change
                                        Password</a>
                                    <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                </div>
                            </div>
                            <!-- My Account Tab Menu End -->

                            <!-- My Account Tab Content Start -->
                            <div class="col-lg-9 col-md-8 col-custom">
                                <div class="tab-content" id="myaccountContent">
                                    <!-- Single Tab Content Start -->
                                    <div class="tab-pane fade show active" id="dashboad" role="tabpanel">
                                        <div class="myaccount-content">
                                            <?php
                                            $q1 = "select * from tbl_address where user_id='$id';";
                                            $r1 = mysqli_query($con, $q1);
                                            ?>
                                            <h3>Dashboard</h3>
                                            <div class="welcome">
                                                <?php
                                                echo " <p>Hello, <strong>", $row['name'], "</strong></p>"
                                                ?>
                                            </div>
                                            <p>From your account dashboard. you can easily check & view
                                                your recent orders, manage your shipping and billing addresses and edit
                                                your password and account details.</p>
                                            <br><br>
                                            <h3>Account Details</h3>
                                            <div class="account-details-form">
                                                <form action="#" method="POST">

                                                    <div class="single-input-item mb-3">
                                                        <label for="name" class="required mb-1">
                                                            Name</label>
                                                        <input type="text" name='name' id="p1" placeholder="Name" value="<?php echo $row['name']; ?>" />
                                                    </div>
                                                    <p id="error1">&nbsp;Only alphabets are allowed</p>
                                                    <br>
                                                    <div class="single-input-item mb-3">
                                                        <label for="phone" class="required mb-1">Phone Number</label>
                                                        <input type="text" id="p2" name='phone' placeholder="Phone" value="<?php echo $row['phone']; ?>" />
                                                    </div>
                                                    <p id="error2">&nbsp;Enter a valid number</p>
                                                    <br>
                                                    <p id="error4">&nbsp;Please fill the form correctly.</p><br>
                                                    <div class="single-input-item mb-3">
                                                        <button id="update" class="btn flosun-button secondary-btn theme-color rounded-0" name="update">Update</button>
                                                    </div>
                                                    <br>
                                                </form>
                                            </div>


                                        </div>


                                    </div>
                                    <!-- Single Tab Content End -->

                                    <!-- Single Tab Content Start -->
                                    <!--<div class="tab-pane fade" id="orders" role="tabpanel">
                                        <div class="myaccount-content">
                                            <h3>Orders</h3>
                                            <div class="myaccount-table table-responsive text-center">
                                                <table class="table table-bordered">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>Order</th>
                                                            <th>Date</th>
                                                            <th>Status</th>
                                                            <th>Total</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>Aug 22, 2022</td>
                                                            <td>Pending</td>
                                                            <td>$3000</td>
                                                            <td><a href="cart.php" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0">View</a>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>2</td>
                                                            <td>July 22, 2022</td>
                                                            <td>Approved</td>
                                                            <td>$200</td>
                                                            <td><a href="cart.php" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0">View</a>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>3</td>
                                                            <td>June 12, 2022</td>
                                                            <td>On Hold</td>
                                                            <td>$990</td>
                                                            <td><a href="cart.php" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0">View</a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>--->
                                    <!-- Single Tab Content End -->

                                    <!-- Single Tab Content Start -->
                                   <!-- <div class="tab-pane fade" id="download" role="tabpanel">
                                        <div class="myaccount-content">
                                            <h3>Downloads</h3>
                                            <div class="myaccount-table table-responsive text-center">
                                                <table class="table table-bordered">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>Product</th>
                                                            <th>Date</th>
                                                            <th>Expire</th>
                                                            <th>Download</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>Haven - Free Real Estate PSD Template</td>
                                                            <td>Aug 22, 2022</td>
                                                            <td>Yes</td>
                                                            <td><a href="#" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0"><i class="fa fa-cloud-download mr-2"></i>Download
                                                                    File</a></td>
                                                        </tr>
                                                        <tr>
                                                            <td>HasTech - Profolio Business Template</td>
                                                            <td>Sep 12, 2022</td>
                                                            <td>Never</td>
                                                            <td><a href="#" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0"><i class="fa fa-cloud-download mr-2"></i>Download
                                                                    File</a></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>--->
                                    <!-- Single Tab Content End -->

                                    <!-- Single Tab Content Start -->
                                   <!-- <div class="tab-pane fade" id="payment-method" role="tabpanel">
                                        <div class="myaccount-content">
                                            <h3>Payment Method</h3>
                                            <p class="saved-message">You Can't Saved Your Payment Method yet.</p>
                                        </div>
                                    </div>-->
                                    <!-- Single Tab Content End -->

                                    <!-- Single Tab Content Start -->
                                    <div class="tab-pane fade" id="address-edit" role="tabpanel">
                                        <div class="myaccount-content">
                                            <h3>Add Address</h3>
                                            <div class="account-details-form">
                                                <form action="#" method="POST">

                                                    <div class="single-input-item mb-3">
                                                        <label for="name" class="required mb-1">
                                                            Name</label>
                                                        <input type="text" name='aname' id="a1" placeholder="Name" />
                                                    </div>
                                                    <p id="error1a">&nbsp;Only alphabets are allowed</p>
                                                    <br>
                                                    <div class="single-input-item mb-3">
                                                        <label for="address" class="required mb-1">Address</label>
                                                        <textarea id="a2" class="address-area" name='address' placeholder="Address" rows="5"></textarea>
                                                    </div>
                                                    <p id="error2a">&nbsp;Enter a valid Address</p>
                                                    <br>
                                                    <div class="single-input-item mb-3">
                                                        <label for="postcode" class="required mb-1">Postcode</label>
                                                        <input type="text" id="a3" name='apostcode' placeholder="Postcode" />
                                                    </div>
                                                    <p id="error3a">&nbsp;Enter a valid Postcode</p>
                                                    <br>
                                                    <div class="single-input-item mb-3">
                                                        <label for="phone" class="required mb-1">Phone Number</label>
                                                        <input type="text" id="a4" name='aphone' placeholder="Phone" />
                                                    </div>
                                                    <p id="error4a">&nbsp;Enter a valid number</p>
                                                    <br>

                                                    <p id="error5a">&nbsp;Please fill the form correctly.</p><br>
                                                    <br>
                                                    <div id="addaddress" class="single-input-item mb-3">
                                                        <button class="btn flosun-button secondary-btn theme-color rounded-0" name="editad">Add Address</button>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                    <!-- Single Tab Content End -->

                                    <!-- Single Tab Content Start -->
                                    <div class="tab-pane fade" id="account-info" role="tabpanel">
                                        <div class="myaccount-content">
                                            <?php
                                            $q1 = "select * from tbl_address where user_id='$id';";
                                            $r1 = mysqli_query($con, $q1);
                                            ?>

                                            <div class="account-details-form">
                                                <h3>Your Address</h3>
                                                <br><br>

                                                <?php
                                                while ($add = mysqli_fetch_array($r1)) {
                                                    echo "<p><strong>", $add['name'], "</strong></p>
                                                          <p>", $add['address'], ",", $add['postcode'], "</p>
                                                          <p>Mobile:", $add['phone'], "</p>";
                                                    echo " <a href='edit-address.php?id=", $add['address_id'], "' class='btn E-FloraAura-button secondary-btn theme-color  rounded-0'><i class='fa fa-edit mr-2'></i>Edit Address</a>", "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp",
                                                    "<a href='address-delete.php?id=", $add['address_id'], "' class='btn E-FloraAura-button secondary-btn theme-color  rounded-0'><i class='bi bi-trash mr-2'></i>Delete Address</a><br>";
                                                    echo "<br>";
                                                }

                                                ?>
                                            </div>
                                        </div>
                                    </div> <!-- Single Tab Content End -->
                                    <!-- Single Tab Content Start -->
                                    <div class="tab-pane fade" id="password-change" role="tabpanel">
                                        <div class="myaccount-content">
                                            <div class="account-details-form">
                                                <form action="#" method="POST">

                                                    <fieldset>
                                                        <legend>Password change</legend>
                                                        <div class="single-input-item mb-3">
                                                            <label for="current-pwd" class="required mb-1">Current
                                                                Password</label>
                                                            <input type="password" name='password' id="p7" onkeyup="checkpass()" placeholder="Current Password" />
                                                        </div>
                                                        <div id="password-availability-status" class="error"></div>
                                                        <div class="single-input-item mb-3">
                                                            <label for="new-pwd" class="required mb-1">New
                                                                Password</label>
                                                            <input type="password" name='npassword' id="p8" placeholder="New Password" />
                                                        </div>
                                                        <p id="error8">&nbsp;Password should include at-least eight
                                                            characters,uppercase letter,lowercase
                                                            letter,number and special character.</p>

                                                        <div class="single-input-item mb-3">
                                                            <label for="confirm-pwd" class="required mb-1">Confirm
                                                                Password</label>
                                                            <input type="password" id="p9" name='cppassword' placeholder="Confirm Password" />
                                                        </div>
                                                        <p id="error9">&nbsp; Passwords should match.</p><br>
                                                        <p id="error10">&nbsp;Please fill the form correctly.</p><br>

                                                    </fieldset>
                                                    <div class="single-input-item mb-3">
                                                        <button id="confirm" class="btn flosun-button secondary-btn theme-color rounded-0" name="confirm">Save Change</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div> <!-- Single Tab Content End -->
                                </div>
                            </div> <!-- My Account Tab Content End -->
                        </div>
                    </div> <!-- My Account Page End -->
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <!-- my account wrapper end -->
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->
    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/my-account.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

</html>