<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_category where status = 'available'";
$re = mysqli_query($con, $query);
$qu = "select * from tbl_user where user_id ='$id'";
$reu = mysqli_query($con, $qu);
$ud =  mysqli_fetch_array($reu);
?>
<!doctype html>
<html class="no-js" lang="zxx">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/shop-fullwidth.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:18 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

     <!-- Header Area Start Here -->
     <header class="main-header-area">
        <!-- Main Header Area Start -->
        <div class="main-header header-transparent header-sticky">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-2 col-xl-2 col-md-6 col-6 col-custom">
                        <div class="header-logo d-flex align-items-center">
                            <a href="index.php">
                                <img class="img-full" src="assets/images/logo/logo.png" alt="Header Logo">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 d-none d-lg-flex justify-content-center col-custom">
                        <nav class="main-nav d-none d-lg-flex">
                            <ul class="nav">
                                <li>
                                    <a class="active" href="index-3.php">
                                        <span class="menu-text"> Home</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="shop.php">
                                        <span class="menu-text">Shop</span>
                                        <!--<i class="fa fa-angle-down"></i>-->
                                    </a>
                                    <ul class="dropdown-submenu dropdown-hover">
                                    <li><b><a href="shop.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Categories</a></b></li>
										<?php
										$qc="select * from tbl_category where status = 'available'";
										$rec=mysqli_query($con,$qc);
										while($cat=mysqli_fetch_array($rec)){
										?>
										<li><a href="shopcategory.php?caid=<?php echo $cat['category_id'] ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $cat['category_name'] ?></a></li>
										<?php
										}
										?>
                                    </ul>
                                </li>
                                <li>
                                    <a href="blog-grid-fullwidth.php">
                                        <span class="menu-text"> Blog</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="about-us.php">
                                        <span class="menu-text"> About Us</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="contact-us.php">
                                        <span class="menu-text">Contact Us</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-lg-2 col-md-6 col-6 col-custom">
                        <div class="header-right-area main-nav">
                            <ul class="nav">
                                <li class="minicart-wrap">
                                    <a href="cart.php" class="minicart-btn toolbar-btn">
                                        <i class="fa fa-shopping-cart"></i>
                                        <!--<span class="cart-item_count">3</span>-->
                                    </a>
                                </li>
                                <li class="user-wrap">
                                    <a href="#" class="miniuser-btn toolbar-btn"> <i class="fa fa-user"></i></a>
                                    <ul class="dropdown-submenu dropdown-hover">
                                        <li><a href="#"><?php echo $ud['name'] ?></a></li>
                                        <li><a href="my-account.php">My Account</a></li>
                                        <li><a href="my-orders.php">My Orders</a></li>
                                        <li><a href="wishlist.php">My Wishlist</a></li>
                                        <li><a href="logout.php">Logout</a></li>

                                    </ul>
                                </li>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Header Area End -->
    </header>
    <!-- Header Area End Here -->


    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Product Category</h3>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <!-- categories section -->
    <div style="margin:50px 40px 50px 40px;">
    <?php
    while($cat=mysqli_fetch_array($re)){
    ?>
    <div class="single-product position-relative mr-0 ml-0" style="width: 18rem;max-height:50rem;margin:2rem;display:inline-block;">
        <img src="assets/images/flower_category/<?php echo $cat['category_image'] ?>" class="card-img-top" style="height:24em;width:20rem;"  alt="...">
        <div class="card-body"><br>
            <h3 class="card-title"><?php echo $cat['category_name'] ?></h3>
            <p class="card-text" style="height:18rem"><?php echo $cat['category_description'] ?></p>
            <a href="shopcategory.php?caid=<?php echo $cat['category_id'] ?>" class="btn flosun-button secondary-btn theme-color rounded-0"
                                        name="submit">Show Products</a>
        </div>
    </div>
    <?php
    }
    ?>
    </div>
    <!-- end categories section -->
    <br>
    <br>
    <br>
    <br>
   
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->



    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="lnr lnr-arrow-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/shop-fullwidth.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:18 GMT -->

</html>