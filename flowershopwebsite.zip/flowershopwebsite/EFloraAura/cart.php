<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_cart where user_id='$id'  and cart_qnt>0";
$recart = mysqli_query($con, $query);
$count = mysqli_num_rows($recart);
?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
    ============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<style>
    * {
        box-sizing: border-box
    }

    

    /* Float cancel and delete buttons and add an equal width */
    .cancelbtn,
    .deletebtn {
        display:inline-block;
        width: 40%;
    }

    /* Add a color to the cancel button */
    .cancelbtn {
        background-color: #ccc;
        color:ivory;
        padding: 10px;
        padding-left: 20px;
        padding-right: 20px;
        border-radius: 10px;
        border: 0;
    }

    /* Add a color to the delete button */
    .deletebtn {
        background-color:#E72463;
        color:ivory;
        padding: 10px;
        padding-left: 20px;
        padding-right: 20px;
        border-radius: 10px;
        border: 0;
    }

    /* Add padding and center-align text to the container */
    .container {
        padding: 16px;
        text-align: center;
    }

    /* The Modal (background) */
    .modal {
        display: none;
        position: fixed;

        transform: translate(50px, 50px, 20px, 20px);
        width: 400px;
        max-width: 50%;
        border-radius: 50px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        padding: 50px;
        background-color: #FFFFFF;
        margin-left: 25%;
        margin-right: 25%;
    }

    /* Modal Content/Box */
    .modal-content {
        background-color: #FFFFFF;
        border-color: white;


        margin: 5% auto 15% auto;
        /* 5% from the top, 15% from the bottom and centered */

        width: 50px;
        /* Could be more or less, depending on screen size */
    }



    /* The Modal Close Button (x) */
    .close {
        position: absolute;
        right: 35px;
        top: 15px;
        font-size: 40px;
        font-weight: bold;
        color: #000003;
    }

    .close:hover,
    .close:focus {
        color: #f44336;
        cursor: pointer;
    }

    /* Clear floats */
    .clearfix::after {
        content: "";
        clear: both;
        display: table;
    }

    /* Change styles for cancel button and delete button on extra small screens */
    @media screen and (max-width: 50px) {

        .cancelbtn,
        .deletebtn {
            width: 50%;
        }
    }
</style>
<!--<script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>-->

<body>

    <!--Header area starts here-->
    <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Shopping Cart</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>Shopping Cart</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <?php
    if ($count > 0) {
        ?>
        <!-- cart main wrapper start -->
        <div class="cart-main-wrapper mt-no-text">
            <div class="container custom-area">
                <?php
                if (isset($_SESSION['status'])) {
                    ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">

                        <?= $_SESSION['status']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php
                    unset($_SESSION['status']);
                }
                ?>
                <div class="row">
                    <div class="col-lg-12 col-custom">
                        <!-- Cart Table Area -->
                        <div class="cart-table table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="pro-thumbnail">Image</th>
                                        <th class="pro-title">Product</th>
                                        <th class="pro-price">Price</th>
                                        <th class="pro-quantity">Quantity</th>
                                        <th class="pro-subtotal">Total</th>
                                        <th class="pro-remove">Remove</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $total = 0;
                                    $ship = 70;
                                    $subtotal = 0;
                                    while ($cart = mysqli_fetch_array($recart)) {
										$pid = $cart['flower_id'];
										$cid=$cart['cart_id'];
										$query3 = "select stock from tbl_flowers where flower_id='$pid'";
										$re3 = mysqli_query($con, $query3);
										$row3 = mysqli_fetch_array($re3);
										$ps = $row3['stock'];
										if ($cart['cart_qnt'] > $ps) {
											$query4 = "update tbl_cart set status='unavailable' where cart_id='$cid'";
											$re4 = mysqli_query($con, $query4);
										} else {
											$query5 = "update tbl_cart set status='available' where cart_id='$cid'";
											$re5 = mysqli_query($con, $query5);
											$subtotal = $subtotal + ($cart['cart_price'] * $cart['cart_qnt']);
											if ($subtotal > 500) {
												$ship = 0;
											}
											$pid = $cart['flower_id'];
											$pq = "select * from tbl_flowers where flower_id='$pid'";
											$pre = mysqli_query($con, $pq);
											$prod = mysqli_fetch_array($pre);
									?>
                                        <tr>
                                            <td class="pro-thumbnail"><a
                                                    href="product-details.php?pid=<?php echo $cart['flower_id']; ?>"><img
                                                        class="img-fluid"
                                                        src="assets/images/product/<?php echo $prod['images']; ?>"
                                                        alt="Product" /></a></td>
                                            <td class="pro-title"><a href="#">
                                                    <?php echo $prod['flower_name']; ?>
                                                </a></td>
                                            <td class="pro-price"><span>₹
                                                    <?php echo $cart['cart_price']; ?>
                                                </span></td>
                                            <td class="pro-quantity1">
                                                <a href="editcartminus.php?pid=<?php echo $cart['flower_id']; ?>"><i
                                                        class="fa fa-minus"></i></a>
                                                &nbsp;&nbsp;
                                                <?php echo $cart['cart_qnt']; ?>&nbsp;&nbsp;
                                                <a href="editcartplus.php?pid=<?php echo $cart['flower_id']; ?>"><i
                                                        class="fa fa-plus"></i></a>
                                            </td>
                                            <td class="pro-subtotal"><span>₹
                                                    <?php echo ($cart['cart_price'] * $cart['cart_qnt']); ?>
                                                </span></td>
                                            <td class="pro-remove"><button
                                                    onclick="document.getElementById('id01').style.display='block'"
                                                    name="btn"><i class="lnr lnr-trash"></i></button></td>
                                        </tr>
                                        <div id="id01" class="modal" style="height:fit-content;top:25%;">
                                            <span onclick="document.getElementById('id01').style.display='none'" class="close"
                                                title="Close Modal">&times;</span>
                                            <form method="POST">

                                                <h2>Remove Product From Cart</h2>
                                                <p>Are you sure you want to remove product from your cart ?</p>

                                                <div class="clearfix">
                                                    <button type="button" class="cancelbtn" name="cancelbtn"><a
                                                            href="cart.php">Cancel</a></button>&nbsp;
                                                    <button type="button" class="deletebtn" name="delconfirm"><a
                                                            href="deletefromcart.php?cid=<?php echo $cart['cart_id']; ?>">Delete</a></button>
                                                </div>

                                            </form>
                                        </div>

                                        <?php
										}
									
                                    if ($subtotal > 500) {
                                        $ship = 0;
                                    }
                                    $total = $subtotal + $ship;
                                }
                                    ?>
                                    
                                </tbody>
                            </table>

                        </div>

                        <!-- Cart Update Option -->
                        <div class="cart-update-option d-block d-md-flex justify-content-between">
                            <div class="apply-coupon-wrapper">
                                <form action="#" method="post" class=" d-block d-md-flex">
                                    <input type="text" placeholder="Enter Your Coupon Code" required />
                                    <button class="btn E-FloraAura-button primary-btn rounded-0 black-btn">Apply
                                        Coupon</button>
                                </form>
                            </div>
                            <div class="cart-update mt-sm-16">
                                <a href="#" class="btn E-FloraAura-button primary-btn rounded-0 black-btn">Update Cart</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 ml-auto col-custom">
                        <!-- Cart Calculation Area -->
                        <div class="cart-calculator-wrapper">
                            <div class="cart-calculate-items">
                                <h3>Cart Totals</h3>
                                <div class="table-responsive">
                                    <table class="table">
                                        <tr>
                                            <td>Sub Total</td>
                                            <td>₹
                                                <?php echo $subtotal; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Shipping</td>
                                            <td>₹
                                                <?php echo $ship; ?>
                                            </td>
                                        </tr>
                                        <tr class="total">
                                            <td>Total</td>
                                            <td class="total-amount">₹
                                                <?php echo $total; ?>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <br><button class="btn flosun-button secondary-btn theme-color rounded-0" > <a href="checkout.php"
                                class="btn E-FloraAura-button primary-btn rounded-0 black-btn w-100">Proceed To Checkout</a><button><br><br><br>
                        </div>
                    </div>
                </div>
                <br><br>
                <?php
						$q5 = "select count(cart_id) from tbl_cart where user_id='$id' and status='unavailable'";
						$re5 = mysqli_query($con, $q5);
						$csave= mysqli_fetch_array($re5);
						$ccsave=$csave['count(cart_id)'];
						if($ccsave>0){
						?>
                <div class="row">
                    <div class="col-lg-12 col-custom">
                        <!-- Cart Table Area -->
                        <div class="cart-table table-responsive">
                        <h3>Out of stock</h3>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="pro-thumbnail">Image</th>
                                        <th class="pro-title">Product</th>
                                        <th class="pro-price">Price</th>
                                        
                                        <th class="pro-subtotal">Total</th>
                                        <th class="pro-remove">Remove</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
									$qsave="select * from tbl_cart where status='unavailable' and user_id='$id'";
									$resave=mysqli_query($con,$qsave);
									while ($cart1 = mysqli_fetch_array($resave)) {
											$pid = $cart1['flower_id'];
											$pq = "select * from tbl_flowers where flower_id='$pid'";
											$pre = mysqli_query($con, $pq);
											$prod = mysqli_fetch_array($pre);
									?>
                                        <tr>
                                            <td class="pro-thumbnail"><a
                                                    href="product-details.php?pid=<?php echo $cart1['flower_id']; ?>"><img
                                                        class="img-fluid"
                                                        src="assets/images/product/<?php echo $prod['images']; ?>"
                                                        alt="Product" /></a></td>
                                            <td class="pro-title"><a href="#">
                                                    <?php echo $prod['flower_name']; ?>
                                                </a></td>
                                            <td class="pro-price"><span>₹
                                                    <?php echo $cart1['cart_price']; ?>
                                                </span></td>
                                            
                                            <td class="pro-subtotal"><span>₹
                                                    <?php echo ($cart1['cart_price'] * $cart1['cart_qnt']); ?>
                                                </span></td>
                                             <td class="pro-remove"><a href="deletefromcart.php?cid=<?php echo $cart['cart_id']; ?>"><i class="lnr lnr-trash"></i></a></td>
                                        </tr>
                                       <!-- <div id="id01" class="modal" style="height:fit-content;top:25%;">
                                            <span onclick="document.getElementById('id01').style.display='none'" class="close"
                                                title="Close Modal">&times;</span>
                                            <form method="POST">

                                                <h2>Remove Product From Cart</h2>
                                                <p>Are you sure you want to remove product from your cart ?</p>

                                                <div class="clearfix">
                                                    <button type="button" class="cancelbtn" name="cancelbtn"><a
                                                            href="cart.php">Cancel</a></button>&nbsp;
                                                    <button type="button" class="deletebtn" name="delconfirm"><a
                                                            href="deletefromcart.php?cid=<?php echo $cart1['cart_id']; ?>">Delete</a></button>
                                                </div>

                                            </form>
                                        </div>-->

                                        <?php

                                    }
                                    
                                    ?>
                                </tbody>
                            </table>

                        </div>

                        
                    </div>
                </div>
                <?php
						}
						?>
            </div>
        </div>
        <br>
        <br>
        <?php
    } else {
        ?>
        <!-- Error 404 Area Start Here -->

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="error_form">
                        <img align="center" src="assets/images/icon/cartempty.gif" style=" height:200px;width:200px; " />
                        <h2>Your Cart is empty</h2>
                        <h3>Add some products first</h3>

                        <a href="shop.php" class="boxed-btn">Back To Product Page</a>

                    </div>
                </div>
            </div>
        </div>

        <!-- Error 404 Area End Here -->
        <?php
    }
    ?>
    <br><br>
    <!-- cart main wrapper end -->
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->

</html>