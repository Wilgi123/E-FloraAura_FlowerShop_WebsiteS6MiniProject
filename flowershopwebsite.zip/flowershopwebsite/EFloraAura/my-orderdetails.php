<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$oid=$_GET['oid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_orderdt where user_id='$id' and order_id='$oid'";
$re1 = mysqli_query($con, $query);
$count = mysqli_num_rows($re1);
$qu = "select * from tbl_user where user_id ='$id'";
$reu = mysqli_query($con, $qu);
$ud = mysqli_fetch_array($reu);
?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<body>

 <!--Header area starts here-->
 <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">View Ordered Product Details</h3>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <?php
	if ($count > 0) {
	?>
    <!-- cart main wrapper start -->
    <div class="cart-main-wrapper mt-no-text">
        <div class="container custom-area">
        
            <div class="row">
                <div class="col-lg-12 col-custom">
                    <!-- Cart Table Area -->
                    <div class="cart-table table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                  <th class="pro-sino">Si.No</th>
                                  <th class="pro-thumbnail">Image</th>
                                    <th class="pro-title">Product</th>
                                   
                                    
                                    <th class="pro-quantity">Quantity</th>
                                    <th class="pro-subtotal">Total</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                    $c = 1;
                                    while ($orderd = mysqli_fetch_array($re1)) {
                                        $pid = $orderd['flower_id'];
										$pq = "select * from tbl_flowers where flower_id='$pid'";
										$pre = mysqli_query($con, $pq);
										$prod = mysqli_fetch_array($pre);
                                    ?>
                                <tr>
                                    <td class="pro-sino"><a href="#"><?php echo $c ?></a></td>
                                    <td class="pro-thumbnail"><a href="product-details.php?pid=<?php echo $prod['flower_id']; ?>"><img class="img-fluid" src="assets/images/product/<?php echo $prod['images']; ?>" alt="Product" /></a></td>

                                    <td class="pro-title"><a href="#"><?php echo $prod['flower_name']; ?></a></td>
                                    <td class="pro-quantity"><span><?php echo $orderd['order_qnt'];?></span></td>
                                    <td class="pro-price"><span>₹<?php echo $orderd['order_price'];?></span></td>
                                    
                                </tr>
                                <?php
                                        $c++;
                                    }
                                    $qtotal = "select order_total from tbl_orders where order_id='$oid'";
                                    $totre=mysqli_query($con,$qtotal);
                                    $to=mysqli_fetch_array($totre);
                                    $ototal=$to['order_total'];
                                    if($ototal<550){
                                        $ship=70;
                                    }
                                    else{
                                        $ship=0;
                                    }
                                    ?>
                                     <tr>
                                        <td colspan="5"  height="30px"class="product-thumbanil">Shipping : ₹ <?php echo $ship ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="5"  height="30px"class="product-thumbanil">Total : ₹ <?php echo $ototal ?></td>
                                    </tr>
                                   
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
           
        </div>
    </div>
   <br>
   <br>
   <?php
	} else {
	?>
   <!-- Error 404 Area Start Here -->
   
   <div class="container">
            <div class="row">
                  <div class="col-12">
                    <div class="error_form">
                    <img align="center"src="assets/images/icon/cartempty.gif" style =" height:200px;width:200px; " />
                        <h2>Orders Are Not Placed</h2>
                        <h3>Make Orders</h3>
                        
                        <a href="shop.php" class="boxed-btn">Back To Product Page</a>
                        
                    </div>
                </div>
            </div>
        </div>
    
    <!-- Error 404 Area End Here -->
	<?php
	}
	?>
    <br><br>
    <!-- cart main wrapper end -->
     <!--Footer Area Start-->
     <?php
       require('footer.php');
    ?>
    <!--Footer Area End-->
 
    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:26 GMT -->
</html>