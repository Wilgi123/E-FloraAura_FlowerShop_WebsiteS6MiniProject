<?php
session_start();
if (!isset($_SESSION['admin'])) {
	header('location:./');
}
$id = $_SESSION['admin'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$q = "select * from tbl_category";
$re = mysqli_query($con, $q);
if (isset($_POST['addpro'])) {
	$fn = $_POST['fname'];
	$fc = $_POST['fcatid'];
	$fp = $_POST['fprice'];
	$fs = $_POST['fstock'];
	$fst = $_POST['fstatus'];
	$fde = $_POST['fdesc'];
	$filename = $_FILES['image']['name'];
	
	$query = "INSERT INTO tbl_flowers(flower_name, flower_price,images, category_id,descriptions, stock, statuses, rating) VALUES ('$fn','$fp','$filename','$fc','$fde','$fs','$fst',0)";
	$res = mysqli_query($con, $query);
	if ($res) {
		$targetDir = "assets\images\product/";
	$targetfilepath = $targetDir . $filename;
	move_uploaded_file($_FILES["image"]["tmp_name"], $targetfilepath);

		?>
				<script>
					alert("Added successfully");
					window.location.href = "admin-dashboard.php";
				</script>
			<?php
	} else {
		?>
				<script>
					alert("Product insertionfailed");
				</script>
		<?php
	}
}
if (isset($_POST['addcat'])) {
		$cn = $_POST['cname'];
		$cde = $_POST['cdesc'];
		$query = "INSERT INTO tbl_category(category_name,category_description) VALUES ('$cn','$cde')";
		$res = mysqli_query($con, $query);
		if ($res) {
			?>
					<script>
						alert("Added successfully");
						window.location.href = "admin-dashboard.php";
					</script>
				<?php
		} else {
			?>
					<script>
						alert("Operation failed");
					</script>
			<?php
		}
}
mysqli_close($con);
?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/my-account.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>E-FloraAura - Flower Shop HTML5 Template</title>
	<meta name="robots" content="noindex, follow" />
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

	<!-- CSS
	============================================ -->
	<!-- Bootstrap CSS -->
	<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css'>

	<link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
	<!-- Font Awesome CSS -->
	<link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
	<!-- Linear Icons CSS -->
	<link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
	<!-- Swiper CSS -->
	<link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
	<!-- Animation CSS -->
	<link rel="stylesheet" href="assets/css/plugins/animate.min.css">
	<!-- Jquery ui CSS -->
	<link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
	<!-- Nice Select CSS -->
	<link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

	<!-- Main Style CSS -->
	<link rel="stylesheet" href="assets/css/style.css">

</head>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<style>
.address-area{
	background: #ffffff;
  border: 1px solid #dddddd;
  border-radius: 0;
  width: 100%;
  padding: 0 10px 0 10px;
}
.address-area:focus{
  border: 1px solid #E72463;
}
.select-area{
	background: #ffffff;
  border: 1px solid #dddddd;
  border-radius: 0;
  height:42px;
  width: 100%;
  padding: 0 10px 0 10px;
}
.select-area:focus{
  border: 1px solid #E72463;
}
</style>
<body>

	<!-- Header Area Start Here -->
	<header class="main-header-area">
		<!-- Main Header Area Start -->
		<div class="main-header header-transparent header-sticky">
			<div class="container-fluid">
				<div class="row align-items-center">
					<div class="col-lg-2 col-xl-2 col-md-6 col-6 col-custom">
						<div class="header-logo d-flex align-items-center">
							<a href="index.php">
								<img class="img-full" src="assets/images/logo/logo.png" alt="Header Logo">
							</a>
						</div>
					</div>
					<div class="col-lg-8 d-none d-lg-flex justify-content-center col-custom">
						<nav class="main-nav d-none d-lg-flex">
							<ul class="nav">
								<li>
									<a class="active" href="index-3.php">
										<span class="menu-text"> Home</span>
									</a>
								</li>
								<li>
									<a href="shop.php">
										<span class="menu-text">Shop</span>
										<i class="fa fa-angle-down"></i>
									</a>
									<ul class="dropdown-submenu dropdown-hover">
										<li><a href="cart.php">Cart Page</a></li>
										<li><a href="checkout.php">Checkout Page</a></li>
										<li><a href="wishlist.php">Wishlist Page</a></li>
									</ul>
								</li>
								<li>
									<a href="blog-grid-fullwidth.php">
										<span class="menu-text"> Blog</span>
									</a>
								</li>
								<li>
									<a href="about-us.php">
										<span class="menu-text"> About Us</span>
									</a>
								</li>
								<li>
									<a href="contact-us.php">
										<span class="menu-text">Contact Us</span>
									</a>
								</li>
							</ul>
						</nav>
					</div>
					<div class="col-lg-2 col-md-6 col-6 col-custom">
						<div class="header-right-area main-nav">
							<ul class="nav">
								<li class="minicart-wrap">
									<a href="#" class="minicart-btn toolbar-btn">
										<i class="fa fa-shopping-cart"></i>
										<span class="cart-item_count">3</span>
									</a>
								</li>
								<li class="user-wrap">
									<a href="#" class="miniuser-btn toolbar-btn"> <i class="fa fa-user"></i></a>
									<ul class="dropdown-submenu dropdown-hover">
										<li><a href="#">My Account</a></li>
										<li><a href="logout.php">Logout</a></li>

									</ul>
								</li>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Main Header Area End -->
	</header>
	<!-- Header Area End Here -->

	<!-- Breadcrumb Area Start Here -->
	<div class="breadcrumbs-area position-relative">
		<div class="container">
			<div class="row">
				<div class="col-12 text-center">
					<div class="breadcrumb-content position-relative section-content">
						<h2 class="title-3">Admin Panel</h2>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcrumb Area End Here -->
	<!-- my account wrapper start -->
	<div class="my-account-wrapper mt-no-text">
		<div class="container container-default-2 custom-area">
			<div class="row">
				<div class="col-lg-12 col-custom">
					<!-- My Account Page Start -->
					<div class="myaccount-page-wrapper">
						<!-- My Account Tab Menu Start -->
						<div class="row">
							<div class="col-lg-3 col-md-4 col-custom">
								<div class="myaccount-tab-menu nav" role="tablist">
									<a href="#addproduct" class="active" data-bs-toggle="tab">
										Add Products</a>
									<a href="#addcategories" data-bs-toggle="tab">
										Add Category</a>
									<a href="#address-edit" data-bs-toggle="tab">
										Add News</a>
									<a href="#download" data-bs-toggle="tab">
									   Edit User</a>
									<a href="#payment-method" data-bs-toggle="tab">
									   Edit Product</a>
									<a href="logout.php"> Logout</a>
								</div>
							</div>
							<!-- My Account Tab Menu End -->

							<!-- My Account Tab Content Start -->
							<div class="col-lg-9 col-md-8 col-custom">
								<div class="tab-content" id="myaccountContent">
									<!-- Single Tab Content Start -->
									<div class="tab-pane fade show active" id="addproduct" role="tabpanel">
									  <div class="myaccount-content">
											<h3>Add Products</h3>
											<div class="account-details-form">
												<form action="#" method="POST" enctype="multipart/form-data">

													<div class="single-input-item mb-3">
														<label for="name" class="required mb-1">
															Flower Name</label>
														<input type="text" name='fname' id="f1"  />
													</div>
													
													<div class="single-input-item mb-3">
														<label for="fcatid" class="required mb-1">
															Choose Category</label>
														<select name='fcatid'  id="f2"class="select-area" >
															<?php
															while($cat=mysqli_fetch_array($re))
															{
															?>
															<option class="required mb-1"value="<?php echo $cat['category_id'] ?>"><?php echo $cat['category_name']?></option>
															<?php
															}
															?>
              											</select>
													</div>
													<div class="single-input-item mb-3">
														<label for="price" class="required mb-1">
															Flower Price</label>
														<input type="number" name='fprice' id="f3"  />
													</div>
													<div class="single-input-item mb-3">
														<label for="stock" class="required mb-1">
															Enter Stock</label>
														<input type="number" name='fstock' id="f4"  />
													</div>
													<div class="single-input-item mb-3">
														<label for="fstatus" class="required mb-1">
															Product Status</label>
														<select name='fstatus'  id="f5"class="select-area" >
															
															<option class="required mb-1" value="available">Available</option>
								
															<option class="required mb-1" value="unavailable">Not Available</option>
              											</select>
													</div>
													<div class="single-input-item mb-3">
														<label for="image" class="required mb-1">
															Flower Image</label>
															<input type="file" accept="image/png, image/gif, image/jpeg" placeholder="Upload image" name="image" required>
													</div>
													<br>
													<div class="single-input-item mb-3">
														<label for="address" class="required mb-1">Product Description</label>
														<textarea id="f6" class="address-area" name='fdesc' maxlength="2000"
														 rows="5"></textarea>
													</div>
													<br>
													<div id="addpro" class="single-input-item mb-3">
														<button class="btn flosun-button secondary-btn theme-color rounded-0" name="addpro">Add Product</button>
													</div>
												</form>
											</div>



									    </div>
									</div>
									<!-- Single Tab Content End -->

									<!-- Single Tab Content Start -->
									<div class="tab-pane fade" id="addcategories" role="tabpanel">
										<div class="myaccount-content">
										<h3>Add Categories</h3>
											<div class="account-details-form">
												<form action="#" method="POST" enctype="multipart/form-data">

													<div class="single-input-item mb-3">
														<label for="name" class="required mb-1">
															Category Name</label>
														<input type="text" name='cname' id="c1"  />
													</div>
													<div class="single-input-item mb-3">
														<label for="address" class="required mb-1">Category Description</label>
														<textarea id="c2" class="address-area"name='cdesc'  rows="5"></textarea>
													</div>

													<div  class="single-input-item mb-3">
														<button class="btn flosun-button secondary-btn theme-color rounded-0" name="addcat">Add Category</button>
													</div>
												</form>
											</div>
										</div>
									</div>
									<!-- Single Tab Content End -->

									<!-- Single Tab Content Start -->
									<div class="tab-pane fade" id="download" role="tabpanel">
										<div class="myaccount-content">
											<h3>Downloads</h3>
											<div class="myaccount-table table-responsive text-center">
												<table class="table table-bordered">
													<thead class="thead-light">
														<tr>
															<th>Product</th>
															<th>Date</th>
															<th>Expire</th>
															<th>Download</th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td>Haven - Free Real Estate PSD Template</td>
															<td>Aug 22, 2022</td>
															<td>Yes</td>
															<td><a href="#" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0"><i class="fa fa-cloud-download mr-2"></i>Download
																	File</a></td>
														</tr>
														<tr>
															<td>HasTech - Profolio Business Template</td>
															<td>Sep 12, 2022</td>
															<td>Never</td>
															<td><a href="#" class="btn E-FloraAura-button secondary-btn theme-color  rounded-0"><i class="fa fa-cloud-download mr-2"></i>Download
																	File</a></td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
									<!-- Single Tab Content End -->

									<!-- Single Tab Content Start -->
									<div class="tab-pane fade" id="payment-method" role="tabpanel">
										<div class="myaccount-content">
											<h3>Payment Method</h3>
											<p class="saved-message">You Can't Saved Your Payment Method yet.</p>
										</div>
									</div>
									<!-- Single Tab Content End -->

									<!-- Single Tab Content Start -->
									<div class="tab-pane fade" id="address-edit" role="tabpanel">
										<div class="myaccount-content">
											<h3>Billing Address</h3>
											<div class="account-details-form">
												<form action="#" method="POST">

													<div class="single-input-item mb-3">
														<label for="name" class="required mb-1">
															Name</label>
														<input type="text" name='aname' id="a1" placeholder="Name" />
													</div>
													<p id="error1a">&nbsp;Only alphabets are allowed</p>
													<br>
													<div class="single-input-item mb-3">
														<label for="address" class="required mb-1">Address</label>
														<textarea id="a2" class="address-area"name='address' placeholder="Address" rows="5"></textarea>
													</div>

													<br>
													<div class="single-input-item mb-3">
														<label for="postcode" class="required mb-1">Postcode</label>
														<input type="text" id="apostcode" name='apostcode' placeholder="Postcode" />
													</div>
													<p id="error3a">&nbsp;Enter a valid Postcode</p>
													<br>
													<div class="single-input-item mb-3">
														<label for="phone" class="required mb-1">Phone Number</label>
														<input type="text" id="a4" name='aphone' placeholder="Phone" />
													</div>
													<p id="error4a">&nbsp;Enter a valid number</p>
													<br>

													<p id="error5a">&nbsp;Please fill the form correctly.</p><br>
													<br>
													<div id="addaddress" class="single-input-item mb-3">
														<button class="btn flosun-button secondary-btn theme-color rounded-0" name="editad">Add Address</button>
													</div>
												</form>
											</div>

										</div>
									</div>
									<!-- Single Tab Content End -->

									<!-- Single Tab Content Start -->
									<div class="tab-pane fade" id="account-info" role="tabpanel">
										<div class="myaccount-content">
											<h3>Account Details</h3>
											<div class="account-details-form">
												<form action="#" method="POST">

													<div class="single-input-item mb-3">
														<label for="name" class="required mb-1">
															Name</label>
														<input type="text" name='name' id="p1" placeholder="Name" value="<?php echo $row['name']; ?>" />
													</div>
													<p id="error1">&nbsp;Only alphabets are allowed</p>
													<br>
													<div class="single-input-item mb-3">
														<label for="phone" class="required mb-1">Phone Number</label>
														<input type="text" id="p2" name='phone' placeholder="Phone" value="<?php echo $row['phone']; ?>" />
													</div>
													<p id="error2">&nbsp;Enter a valid number</p>
													<br>
													<p id="error4">&nbsp;Please fill the form correctly.</p><br>
													<div class="single-input-item mb-3">
														<button id="update" class="btn flosun-button secondary-btn theme-color rounded-0" name="update">Update</button>
													</div>
													<br>
												</form>
											</div>
										</div>
									</div> <!-- Single Tab Content End -->
									<!-- Single Tab Content Start -->
									<div class="tab-pane fade" id="password-change" role="tabpanel">
										<div class="myaccount-content">
											<div class="account-details-form">
												<form action="#" method="POST">

													<fieldset>
														<legend>Password change</legend>
														<div class="single-input-item mb-3">
															<label for="current-pwd" class="required mb-1">Current
																Password</label>
															<input type="password" name='password' id="p7" onkeyup="checkpass()" placeholder="Current Password" />
														</div>
														<div id="password-availability-status" class="error"></div>
														<div class="single-input-item mb-3">
															<label for="new-pwd" class="required mb-1">New
																Password</label>
															<input type="password" name='npassword' id="p8" placeholder="New Password" />
														</div>
														<p id="error8">&nbsp;Password should include at-least eight
															characters,uppercase letter,lowercase
															letter,number and special character.</p>

														<div class="single-input-item mb-3">
															<label for="confirm-pwd" class="required mb-1">Confirm
																Password</label>
															<input type="password" id="p9" name='cppassword' placeholder="Confirm Password" />
														</div>
														<p id="error9">&nbsp; Passwords should match.</p><br>
														<p id="error10">&nbsp;Please fill the form correctly.</p><br>

													</fieldset>
													<div class="single-input-item mb-3">
														<button id="confirm" class="btn flosun-button secondary-btn theme-color rounded-0" name="confirm">Save Change</button>
													</div>
												</form>
											</div>
										</div>
									</div> <!-- Single Tab Content End -->
								</div>
							</div> <!-- My Account Tab Content End -->
						</div>
					</div> <!-- My Account Page End -->
				</div>
			</div>
		</div>
	</div>
	<!-- my account wrapper end -->
	 <!--Footer Area Start-->
	 <?php
       require('footer.php');
    ?>
    <!--Footer Area End-->
	<!-- JS
============================================ -->


	<!-- jQuery JS -->
	<script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
	<!-- jQuery Migrate JS -->
	<script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
	<!-- Modernizer JS -->
	<script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


	<!-- Swiper Slider JS -->
	<script src="assets/js/plugins/swiper-bundle.min.js"></script>
	<!-- nice select JS -->
	<script src="assets/js/plugins/nice-select.min.js"></script>
	<!-- Ajaxchimpt js -->
	<script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
	<!-- Jquery Ui js -->
	<script src="assets/js/plugins/jquery-ui.min.js"></script>
	<!-- Jquery Countdown js -->
	<script src="assets/js/plugins/jquery.countdown.min.js"></script>
	<!-- jquery magnific popup js -->
	<script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

	<!-- Main JS -->
	<script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/my-account.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

</html>