<?php
session_start();
$id = $_SESSION['id'];
$pid = $_GET['pid'];
if (isset($_POST['rate'])) {
    $ratingValue = $_POST['rating'];
    
    $query = "SELECT * FROM tbl_rating WHERE flower_id = $pid AND user_id = $id";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        // update the existing rating
        $row = mysqli_fetch_assoc($result);
        $ratingId = $row['review_id'];
        $query1 = "UPDATE ratings SET rating = $ratingValue WHERE review_id = $ratingId";
        mysqli_query($conn, $query1);
      } else {
        // insert a new rating
        $query2 = "INSERT INTO tbl_rating (flower_id, user_id, rating) VALUES ($pid, $id, $ratingValue)";
        mysqli_query($conn, $query2);
      }
    
}
?>
