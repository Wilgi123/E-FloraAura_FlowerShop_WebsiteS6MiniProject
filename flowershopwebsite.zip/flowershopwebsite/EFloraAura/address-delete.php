<?php
        $aid=$_GET['id'];
        session_start();
        $id=$_SESSION['id'];
		$con=mysqli_connect("localhost","root","","flower_shop");
		$query="delete from tbl_address where user_id='$id' and address_id='$aid'";
		$re=mysqli_query($con,$query);
        if($re)
        {
            ?>
                <script>
                    window.location.href = "my-account.php";
                </script>
            <?php
        }
		mysqli_close($con);
	
?>