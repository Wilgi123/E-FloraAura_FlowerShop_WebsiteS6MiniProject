<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$pid = $_GET['pid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$qcheckwish = "select count(*) from tbl_wishlist where flower_id ='$pid' and user_id='$id'";
$wishre = mysqli_query($con, $qcheckwish);
$wishrow = mysqli_fetch_array($wishre);
$qu = "select * from tbl_user where user_id ='$id'";
$reu = mysqli_query($con, $qu);
$ud = mysqli_fetch_array($reu);
$query = "select * from tbl_flowers where flower_id='$pid' and statuses='available'";
$re = mysqli_query($con, $query);
$row = mysqli_fetch_array($re);
$ps = $row['stock'];
$cat = $row['category_id'];
$query1 = "select * from tbl_category where category_id='$cat'";
$re1 = mysqli_query($con, $query1);
$row1 = mysqli_fetch_array($re1);
if (isset($_POST['addcart'])) {
    $qty = $_POST['qty'];
    header("Location: addcart.php?pid=$pid&qty=$qty");
}
if (isset($_POST['addwish'])) {
    header("Location: addwishlist.php?pid=$pid");
}
if (isset($_POST['removewish'])) {
    $querydl = "delete from tbl_wishlist where flower_id='$pid' and user_id='$id'";
    $redl = mysqli_query($con, $querydl);
    header("Location: product-details.php?pid=$pid");
}

if (isset($_POST['rate'])) {
    $rt = $_POST['rating'];
    $rev = $_POST['review'];
    $qrev = "insert into tbl_reviews(user_id,flower_id,rating,review_text) values('$id','$pid','$rt','$rev');";
    $rera = mysqli_query($con, $qrev);
    $qrev2 = "select avg(rating) from tbl_reviews where flower_id='$pid'";
    $rera2 = mysqli_query($con, $qrev2);
    $rate2 = mysqli_fetch_array($rera2);
    $trate = $rate2['avg(rating)'];
    $qrev1 = "update tbl_flowers set rating='$trate' where flower_id='$pid'";
    $rera1 = mysqli_query($con, $qrev1);
    if ($rera) {
        header("Location: product-details.php?pid=$pid");
    }
}
?>

<!doctype html>
<html class="no-js" lang="en">

<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/product-details.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:18 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
    ============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $('.fa-star').click(function () {
        var rating = $(this).data('value');
        var flower_id = <?php echo $flower_id ?>;
        $.ajax({
            url: 'rate.php',
            type: 'POST',
            data: {
                rating: rating,
                flower_id: flower_id
            },
            success: function (response) {
                // handle the response
            }
        });
    });
</script>

<body>



    <!--Header area starts here-->
    <?php
    require('header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Product Details</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>Product Details</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <div class="single-product-main-area">
        <div class="container container-default custom-area">
            <div class="row">
                <div class="col-lg-5 offset-lg-0 col-md-8 offset-md-2 col-custom">
                    <div class="product-details-img">
                        <div class="single-product-img swiper-container gallery-top popup-gallery">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <a class="w-100" href="assets/images/product/<?php echo $row['images']; ?>">
                                        <img class="w-100" src="assets/images/product/<?php echo $row['images']; ?>"
                                            alt="Product">
                                    </a>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-7 col-custom">
                    <div class="product-summery position-relative">
                        <div class="product-head mb-3">
                            <h2 class="product-title">
                                <?php echo $row['flower_name']; ?>
                            </h2>
                        </div>
                        <div class="price-box mb-2">
                            <span class="regular-price">Rs.
                                <?php echo $row['flower_price']; ?>
                            </span>
                        </div>
                        <div class="product-rating mb-3">
                            <p>
                                <?php
                                $u = $row['rating'];
                                $v = (5 - $u);
                                for ($j = 1; $j <= $u; $j++) {
                                    ?>
                                    <i class="fa fa-star"></i>&nbsp;
                                    <?php
                                }
                                for ($j = 1; $j <= $v; $j++) {
                                    ?>
                                    <i class="fa fa-star-o"></i>&nbsp;
                                    <?php
                                }
                                echo "&nbsp;&nbsp;";
                                ?>

                            </p>
                        </div>
                        <div class="sku mb-3">
                            <span>SKU: 12345</span>
                        </div>
                        <p class="desc-content mb-5">
                            <?php echo $row['descriptions']; ?>
                        </p>
                        <div class="quantity-with_btn mb-5">
                            <div class="add-to_cart">
                                <form action="#" method="POST">
                                    <?php
                                    if ($row['stock'] < 1) {
                                        ?>
                                        <div class="quantity">
                                        <h3>Product is currently Out Of Stock</h3><br>
                                        <?php
                                    } else {
                                        if ($ps < 5) {
                                            ?>
                                            <div class="quantity">
                                                <div>
                                                    <input name="qty" value="1" max="<?php echo $ps ?>" min="1"
                                                        style="font-size: 20px;height:20px;padding:20px 0px 20px 20px;border-color: #E72463;"
                                                        type="number">



                                                </div>
                                            
                                                <?php
                                        } else {
                                            ?>
                                                <div class="quantity">
                                                    <div>
                                                        <input name="qty" value="1" max="5" min="1"
                                                            style="font-size: 20px;height:20px;padding:20px 0px 20px 20px;border-color: #E72463;"
                                                            type="number">



                                                    </div>
                                                    <?php
                                        }
                                        ?>
                                                <br>


                                                <button name="addcart"
                                                    class="btn flosun-button secondary-btn theme-color rounded-0"><i
                                                        class="fa fa-shopping-cart"></i>Add to cart</button>
                                                <?php
                                    }
                                    ?>
                                            <!-- <button name="addcart" class="btn flosun-button secondary-btn theme-color rounded-0"><i class="fa fa-shopping-cart"></i>Add to cart</button>-->
                                            <?php
                                            if ($wishrow['count(*)'] == 0) {
                                                ?>
                                                <button name="addwish"
                                                    class="btn flosun-button secondary-btn theme-color rounded-0"><i
                                                        class="fa fa-heart"></i>Add to wishlist</button>
                                                <?php
                                            } else {
                                                ?>
                                                <button name="removewish"
                                                    class="btn flosun-button secondary-btn theme-color rounded-0"><i
                                                        class="fa fa-heart"></i>Remove from wishlist</button>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                </form><br>
                                <?php
                                if ($row['stock'] < 10 && $row['stock'] >= 1) {
                                    ?>
                                    <h4>Only
                                        <?php echo $row['stock'] ?> Copies Left, Order now
                                    </h4>
                                    <?php
                                }
                                ?><br>
                                <p><strong>Category : </strong>
                                    <?php echo $row1['category_name']; ?>
                                </p>
                                <p><strong>Delivery within 1-2 Days</strong>

                                </p>
                            </div>
                        </div>
                        <div class="social-share mb-4">
                            <span>Share :</span>
                            <a href="#"><i class="fa fa-facebook-square facebook-color"></i></a>
                            <a href="#"><i class="fa fa-twitter-square twitter-color"></i></a>
                            <a href="#"><i class="fa fa-linkedin-square linkedin-color"></i></a>
                            <a href="#"><i class="fa fa-pinterest-square pinterest-color"></i></a>
                        </div>
                        <div class="payment">
                            <a href="#"><img class="border" src="assets/images/payment/payment-icon.png"
                                    alt="Payment"></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-no-text">
                <div class="col-lg-12 col-custom">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active text-uppercase" id="home-tab" data-bs-toggle="tab"
                                href="#connect-1" role="tab" aria-selected="true">Description</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-uppercase" id="profile-tab" data-bs-toggle="tab" href="#connect-2"
                                role="tab" aria-selected="false">Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-uppercase" id="contact-tab" data-bs-toggle="tab" href="#connect-3"
                                role="tab" aria-selected="false">Shipping Policy</a>
                        </li>

                    </ul>
                    <div class="tab-content mb-text" id="myTabContent">
                        <div class="tab-pane fade show active" id="connect-1" role="tabpanel"
                            aria-labelledby="home-tab">
                            <div class="desc-content">
                                <p class="mb-3">On the other hand, we denounce with righteous indignation and dislike
                                    men who are so beguiled and demoralized by the charms of pleasure of the moment, so
                                    blinded by desire, that they cannot foresee the pain and trouble that are bound to
                                    ensue; and equal blame belongs to those who fail in their duty through weakness of
                                    will, which is the same as saying through shrinking from toil and pain. These cases
                                    are perfectly simple and easy to distinguish. In a free hour, when our power of
                                    choice is untrammelled and when nothing prevents our being able to do what we like
                                    best, every pleasure is to be welcomed and every pain avoided. But in certain
                                    circumstances and owing to the claims of duty or the obligations of business it will
                                    frequently occur that pleasures have to be repudiated and annoyances accepted. The
                                    wise man therefore always holds in these matters to this principle of selection: he
                                    rejects pleasures to secure other greater pleasures, or else he endures pains to
                                    avoid worse pains.</p>
                                <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum
                                    soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime
                                    placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.
                                    Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe
                                    eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum
                                    rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias
                                    consequatur aut perferendis doloribus asperiores repellat.</p>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="connect-2" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- Start Single Content -->
                            <div class="product_tab_content  border p-3">
                                <div class="review_address_inner">
                                    <!-- Start Single Review -->
                                    <?php
                                    $queryrev = "select * from tbl_reviews where user_id!='$id'";
                                    $rerev = mysqli_query($con, $queryrev);
                                    while ($reviews = mysqli_fetch_array($rerev)) {
                                        $uid = $reviews['user_id'];
                                        $quser1 = "select * from tbl_user where user_id='$uid'";
                                        $reuser1 = mysqli_query($con, $quser1);
                                        $user1 = mysqli_fetch_array($reuser1);

                                        ?>
                                        <div class="pro_review mb-5">


                                            <div class="review_thumb">

                                                <img alt="review images" src="assets/images/review/1.jpg">
                                            </div>

                                            <div class="review_details">

                                                <div class="review_info mb-2">
                                                    <h5>
                                                        <?php echo $user1['name'] ?>
                                                    </h5>

                                                </div>
                                                <p>
                                                    <?php echo $reviews['review_text'] ?>
                                                </p>

                                            </div>


                                        </div>
                                        <?php
                                    }
                                    ?><br>
                                    <!-- End Single Review -->
                                </div>
                                <!-- Start RAting Area -->
                                <div class="rating_wrap">
                                    <h5 class="rating-title-1 font-weight-bold mb-2">Add a review </h5>

                                    <h6 class="rating-title-2 mb-2">Your Rating</h6>
                                    <!--<div class="rating_list mb-4">
                                        <div class="review_info">
                                            <div class="product-rating mb-3">
                                                <span class="star" data-value="1"><i class="fa fa-star-o"></i></span>
                                                <span class="star" data-value="2"><i class="fa fa-star-o"></i></span>
                                                <span class="star" data-value="3"><i class="fa fa-star-o"></i></span>
                                                <span class="star" data-value="4"><i class="fa fa-star-o"></i></span>
                                                <span class="star" data-value="5"><i class="fa fa-star-o"></i></span>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>
                                            </div>

                                        </div>
                                    </div>-->
                                </div>
                                <!-- End RAting Area -->
                                <div class="comments-area comments-reply-area">
                                    <div class="row">
                                        <div class="col-lg-12 col-custom">
                                            <form action="#" method="POST" class="comment-form-area">
                                                <div class="rating_list mb-4">
                                                    <div class="review_info">
                                                        <div class="product-rating mb-3">
                                                            <label>
                                                                <input type="radio" name="rating" value="1" />
                                                                <span class="star" data-value="1">
                                                                    <i class="fa fa-star"></i>
                                                                </span>&nbsp;&nbsp;

                                                                <input type="radio" name="rating" value="2" />
                                                                <span class="star" data-value="2">
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                </span>&nbsp;&nbsp;

                                                                <input type="radio" name="rating" value="3" />
                                                                <span class="star" data-value="3">
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                </span>&nbsp;&nbsp;
                                                                <input type="radio" name="rating" value="4" />
                                                                <span class="star" data-value="4">
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                </span>&nbsp;&nbsp;
                                                                <input type="radio" name="rating" value="5" />
                                                                <span class="star" data-value="5">
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    <i class="fa fa-star"></i>
                                                                    </i>
                                                                </span>
                                                            </label>



                                                            <!--  <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-o"></i>
                                                <i class="fa fa-star-o"></i>-->
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="comment-form-comment mb-3">
                                                    <label>Comment</label>
                                                    <textarea class="comment-notes" name="review" id="review"
                                                        required="required"></textarea>
                                                </div>
                                                <div class="comment-form-submit">
                                                    <button class="btn E-FloraAura-button secondary-btn rounded-0"
                                                        type="submit" name="rate" value="Submit">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Content -->
                        </div>
                        <div class="tab-pane fade" id="connect-3" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="shipping-policy">
                                <h4 class="title-3 mb-4">Shipping policy for our store</h4>
                                <p class="desc-content mb-2">Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
                                    sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat
                                    volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper
                                    suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure
                                    dolor in hendrerit in vulputate</p>
                                <ul class="policy-list mb-2">
                                    <li>1-2 business days (Typically by end of day)</li>
                                    <li><a href="#">30 days money back guaranty</a></li>
                                    <li>24/7 live support</li>
                                    <li>odio dignissim qui blandit praesent</li>
                                    <li>luptatum zzril delenit augue duis dolore</li>
                                    <li>te feugait nulla facilisi.</li>
                                </ul>
                                <p class="desc-content mb-2">Nam liber tempor cum soluta nobis eleifend option congue
                                    nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent
                                    claritatem insitam; est usus legentis in iis qui facit eorum</p>
                                <p class="desc-content mb-2">claritatem. Investigationes demonstraverunt lectores legere
                                    me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur
                                    mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc
                                    putamus parum claram, anteposuerit litterarum formas humanitatis per</p>
                                <p class="desc-content mb-2">seacula quarta decima et quinta decima. Eodem modo typi,
                                    qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <br><br><br><br>
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->

    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="lnr lnr-arrow-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/product-details.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:25 GMT -->

</html>