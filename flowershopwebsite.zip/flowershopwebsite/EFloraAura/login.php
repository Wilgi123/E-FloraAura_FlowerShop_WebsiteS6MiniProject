<?php
session_start();
if (isset($_POST['submit'])) {
    $em = $_POST['email'];
    $ps = $_POST['password'];
    $ps = md5($ps);
    //$hash=password_hash($ps, PASSWORD_DEFAULT);
    //$verify = password_verify($ps, $hash);
    $con = mysqli_connect("localhost", "root", "", "flower_shop");
    $queryad = "select * from tbl_admin where admin_email='$em' and admin_password='$ps'";
    $read = mysqli_query($con, $queryad);
    $rowad = mysqli_fetch_array($read);
    $countad = mysqli_num_rows($read);
    if ($countad > 0) {
        $_SESSION['admin'] = $rowad['admin_id'];
        ?>
        <script>
            alert("welcome to admin panel");
        </script>
        <?php
        header('Location:EFloraAuraAdminPanel/index.php');
    } else {
        $query = "select * from tbl_user where email='$em' and password='$ps' and user_status='active'";
        $re = mysqli_query($con, $query);
        $row = mysqli_fetch_array($re);
        $count = mysqli_num_rows($re);
        if ($count > 0) {
            $_SESSION['id'] = $row['user_id'];
            date_default_timezone_set("Asia/Kolkata");
			$time=date("h:i:a d/m/Y");
            $id=$row['user_id'];
			$qlog="update tbl_user set last_login='$time' where user_id='$id'";
			$relog=mysqli_query($con,$qlog);
			header('Location: index-3.php');
            
        } else {
            $_SESSION['rstatus']="Email and password does not match";
        //header('location:login.php');
            ?>
           <!-- <script>
                alert("Username and password does not match");
                window.location.href = "login.php";
            </script>-->
            <?php
        }
        mysqli_close($con);
    }
}
?>

<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/flosun/flosun/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
    ============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
    #error2,
    #error3,
    #error5 {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

    .password-container {
        width: 100%;
        position: relative;
    }

    input,
    input[type=password] {
        width: 150px;
        height: 20px;
    }

    .fa-eye {
        position: absolute;
        top: 28%;
        right: 4%;
        cursor: pointer;
        color: lightgray;
    }

    #toggle_pwd {
        cursor: pointer;
    }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<body>



    <!--Header area starts here-->
    <?php
    require('index-header.php');
    ?>
    <!--Header area ends here-->
    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Login-Register</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li>Login-Register</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <!-- Login Area Start Here -->
    <div class="login-register-area mt-no-text">
        <div class="container custom-area">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-custom">
                <?php
                    if (isset($_SESSION['status'])) {
                        ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            
                            <?= $_SESSION['status']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php
                        unset($_SESSION['status']);
                    } 
                    if (isset($_SESSION['rstatus'])) {
                        ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            
                            <?= $_SESSION['rstatus']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php
                        unset($_SESSION['status']);
                    } 
                    ?>
                    <div class="login-register-wrapper">
                        <div class="section-content text-center mb-5">
                            <h2 class="title-4 mb-2">Login</h2>
                            <p class="desc-content">Please login using account detail bellow.</p>
                        </div>
                        <form action="#" method="post">
                            <div class="single-input-item mb-3">
                                <input type="email" placeholder="Email" id="p2" name="email" required>
                            </div>

                            <div class="single-input-item mb-3">
                                <input type="password" id="p3" name="password" placeholder="Enter your Password"
                                    required>
                            </div>

                            <div class="single-input-item mb-3">
                                <div class="login-reg-form-meta d-flex align-items-center justify-content-between">
                                    <div class="remember-meta mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="rememberMe">
                                            <label class="custom-control-label" for="rememberMe">Remember Me</label>
                                        </div>
                                    </div>
                                    <a href="forgot_password.php" class="forget-pwd mb-3">Forget Password</a>
                                </div>
                            </div>
                            <div class="single-input-item mb-3">
                                <!-- <input type="submit" name="submit" value="Login" class="btn flosun-button secondary-btn theme-color rounded-0">-->
                                <center>
                                    <button class="btn flosun-button secondary-btn theme-color rounded-0"
                                        name="submit">Login</button>
                                </center>
                            </div>
                            <div class="single-input-item">
                                <center>
                                    <p class="login-register-text">Don't have an account? <a
                                            href="register.php">Register Here</a>.</p>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Login Area End Here -->
    <br>
    <br>
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->
    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/flosun/flosun/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:27 GMT -->

</html>