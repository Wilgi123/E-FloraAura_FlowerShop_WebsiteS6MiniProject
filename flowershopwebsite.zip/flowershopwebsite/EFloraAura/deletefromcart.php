<?php
session_start();
if (!isset($_SESSION['id'])) {
	header('location:./');
}
$id=$_SESSION['id'];
$cid=$_GET['cid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "delete from tbl_cart where cart_id='$cid';";
$re = mysqli_query($con, $query);
if($re){
	
        header('location:cart.php');
    
}
else{
    ?>
		<script>
			alert("Operation failed");
            window.location.href = "cart.php";
		</script>
	<?php
}
?>