<?php

session_start();
if (!isset($_SESSION['id'])) {
    header('location:./');
}
$id = $_SESSION['id'];
$caid=$_GET['caid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query = "select * from tbl_flowers where statuses='available' and category_id='$caid';";
$re = mysqli_query($con, $query);
$qu = "select * from tbl_user where user_id='$id'";
$reu = mysqli_query($con, $qu);
$ud = mysqli_fetch_array($reu);

?>
<!doctype html>
<html class="no-js" lang="zxx">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/shop-fullwidth.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:18 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-FloraAura - Flower Shop HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Linear Icons CSS -->
    <link rel="stylesheet" href="assets/css/vendor/linearicons.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- Jquery ui CSS -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

     <!-- Header Area Start Here -->
     <header class="main-header-area">
        <!-- Main Header Area Start -->
        <div class="main-header header-transparent header-sticky">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-2 col-xl-2 col-md-6 col-6 col-custom">
                        <div class="header-logo d-flex align-items-center">
                            <a href="index.php">
                                <img class="img-full" src="assets/images/logo/logo.png" alt="Header Logo">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 d-none d-lg-flex justify-content-center col-custom">
                        <nav class="main-nav d-none d-lg-flex">
                            <ul class="nav">
                                <li>
                                    <a  href="index-3.php">
                                        <span class="menu-text"> Home</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="shop.php">
                                        <span class="menu-text">Shop</span>
                                        <!--<i class="fa fa-angle-down"></i>-->
                                    </a>
                                    <ul class="dropdown-submenu dropdown-hover">
                                    <li><b><a href="category.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Categories</a></b></li>
										<?php
										$qc="select * from tbl_category where status = 'available'";
										$rec=mysqli_query($con,$qc);
										while($cat=mysqli_fetch_array($rec)){
										?>
										<li><a href="shopcategory.php?caid=<?php echo $cat['category_id'] ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $cat['category_name'] ?></a></li>
										<?php
										}
										?>
                                    </ul>
                                </li>
                                <li>
                                    <a href="blog-grid-fullwidth.php">
                                        <span class="menu-text"> Blog</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="about-us.php">
                                        <span class="menu-text"> About Us</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="contact-us.php">
                                        <span class="menu-text">Contact Us</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-lg-2 col-md-6 col-6 col-custom">
                        <div class="header-right-area main-nav">
                            <ul class="nav">
                                <li class="minicart-wrap">
                                    <a href="cart.php" class="minicart-btn toolbar-btn">
                                        <i class="fa fa-shopping-cart"></i>
                                        <!--<span class="cart-item_count">3</span>-->
                                    </a>
                                </li>
                                <li class="user-wrap">
                                    <a href="#" class="miniuser-btn toolbar-btn"> <i class="fa fa-user"></i></a>
                                    <ul class="dropdown-submenu dropdown-hover">
                                        <li><a href="#"><?php echo $ud['name'] ?></a></li>
                                        <li><a href="my-account.php">My Account</a></li>
                                        <li><a href="my-orders.php">My Orders</a></li>
                                        <li><a href="wishlist.php">My Wishlist</a></li>
                                        <li><a href="logout.php">Logout</a></li>

                                    </ul>
                                </li>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Header Area End -->
    </header>
    <!-- Header Area End Here -->


    <!-- Breadcrumb Area Start Here -->
    <div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Product Category</h3>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End Here -->
    <!-- Shop Main Area Start Here -->
    <div class="row shop_wrapper grid_3">

        <div class="shop-main-area">
            <div class="container container-default custom-area">
                <div class="row flex-row-reverse">
                    <div class="col-12 col-custom widget-mt">
                        <!--shop toolbar start-->
                        <div class="shop_toolbar_wrapper mb-30">
                            <div class="shop_toolbar_btn">
                               <!-- <button data-role="grid_4" type="button" class="active btn-grid-4" title="Grid-4"><i class="fa fa-th"></i></button>
                                <button data-role="grid_3" type="button" class="btn-grid-3" title="Grid-3"> <i class="fa fa-th-large"></i></button>
                                <button data-role="grid_list" type="button" class="btn-list" title="List"><i class="fa fa-th-list"></i></button>-->
                            </div>
                            <div class="shop-select">
                                <form class="d-flex flex-column w-100" action="#">
                                    <div class="form-group">
                                        <select class="form-control nice-select w-100">
                                            <option selected value="1">Alphabetically, A-Z</option>
                                            <option value="2">Sort by popularity</option>
                                            <option value="3">Sort by newness</option>
                                            <option value="4">Sort by price: low to high</option>
                                            <option value="5">Sort by price: high to low</option>
                                            <option value="6">Product Name: Z</option>
                                        </select>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!--shop toolbar end-->
                        <!-- Shop Wrapper Start -->

                        <div class="row shop_wrapper grid_4">
                            <?php
                            while ($row = mysqli_fetch_array($re)) {
                                $caaid = $row['category_id'];
                                $query1 = "select * from tbl_category where category_id='$caaid';";
                                $re1 = mysqli_query($con, $query1);
                                $row1 = mysqli_fetch_array($re1);
                                if ($row1['status'] == 'available') {
                            ?>
                                    <div class="col-lg-3 col-md-6 col-sm-6  col-custom product-area" >
                                        <div class="product-item">
                                            <div class="single-product position-relative mr-0 ml-0">
                                                <div class="product-image">
                                                    <a class="d-block" href="product-details.php?pid=<?php echo $row['flower_id']; ?>">
                                                        <img src="assets/images/product/<?= $row['images']; ?>" alt="" class="product-image-1 w-100" height="270px">
                                                        <img src="assets/images/product/<?= $row['images']; ?>" alt="" class="product-image-2 position-absolute w-100" height="270px">
                                                    </a>

                                                </div>
                                                <div class="product-content">
                                                    <div class="product-title">
                                                        <h4 class="title-2"><a href="product-details.php?pid=<?php echo $row['flower_id']; ?>">
                                                                <?php echo $row['flower_name']; ?>
                                                            </a></h4>
                                                    </div>
                                                    <div class="product-rating">
                                                    <p>
                                                        <?php
                                                        $u = $row['rating'];
                                                        $v = (5 - $u);
                                                        for ($j = 1; $j <= $u; $j++) {
                                                            ?>
                                                             <i class="fa fa-star"></i>&nbsp;
                                                            <?php
                                                        }
                                                        for ($j = 1; $j <= $v; $j++) {
                                                            ?>
                                                             <i class="fa fa-star-o"></i>&nbsp;
                                                            <?php
                                                        }
                                                        echo "&nbsp;&nbsp;";
                                                        ?>
                                                        
                                                    </p>
                                                    </div>
                                                    <div class="price-box">
                                                        <span class="regular-price ">Rs.
                                                            <?php echo $row['flower_price']; ?>
                                                        </span>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                            <?php
                                }
                            }
                            ?>

                        </div>

                        <!-- Shop Wrapper End -->
                        <!-- Bottom Toolbar Start -->
                        <div class="row">
                            <div class="col-sm-12 col-custom">
                                <div class="toolbar-bottom">
                                    <div class="pagination">
                                        <ul>
                                            <li class="current">1</li>
                                            <li><a href="#">2</a></li>
                                            <li><a href="#">3</a></li>
                                            <li class="next"><a href="#">next</a></li>
                                            <li><a href="#">&gt;&gt;</a></li>
                                        </ul>
                                    </div>
                                    <p class="desc-content text-center text-sm-right mb-0">Showing 1 - 12 of 34 result</p>
                                </div>
                            </div>
                        </div>
                        <!-- Bottom Toolbar End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Main Area End Here -->
    <br>
    <br>
    <br>
    <br>
   
    <!--Footer Area Start-->
    <?php
    require('footer.php');
    ?>
    <!--Footer Area End-->



    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="lnr lnr-arrow-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->


    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>


    <!-- Swiper Slider JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <!-- nice select JS -->
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <!-- Ajaxchimpt js -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Ui js -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- Jquery Countdown js -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/shop-fullwidth.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:18 GMT -->

</html>