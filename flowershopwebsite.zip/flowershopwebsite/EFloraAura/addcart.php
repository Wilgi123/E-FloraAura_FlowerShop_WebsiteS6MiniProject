<?php
session_start();
if (!isset($_SESSION['id'])) {
	header('location:./');
}
$id = $_SESSION['id'];
$qty = $_GET['qty'];
$pid = $_GET['pid'];
$con = mysqli_connect("localhost", "root", "", "flower_shop");
$query4 = "select count(cart_id) from tbl_cart where flower_id='$pid' and user_id='$id'";
$re4 = mysqli_query($con, $query4);
$row4 = mysqli_fetch_array($re4);
$query8 = "select stock from tbl_flowers where flower_id='$pid'";
$re8 = mysqli_query($con, $query8);
$row8 = mysqli_fetch_array($re8);
$ps = $row8['stock'];
$count = $row4['count(cart_id)'];
if ($count == 1) {
	$q123 = "select * from tbl_cart where flower_id='$pid' and user_id='$id'";
	$re123 = mysqli_query($con, $q123);
	$rcart = mysqli_fetch_array($re123);
	if (($rcart['cart_qnt'] + $qty) <= 5  && ($rcart['cart_qnt'] + $qty) <= $ps) {
		$query5 = "update tbl_cart set cart_qnt=cart_qnt+'$qty' where flower_id='$pid' and user_id='$id'";
		$re5 = mysqli_query($con, $query5);
		if ($re5) {
			$_SESSION['status'] = "Added to cart successfully";
			header('location:cart.php');
?>
			<!--<script>
					alert("Added to cart successfully");
					window.location.href = "cart.php";
				</script>-->
		<?php
		} else {
		?>
			<script>
				alert("Operation failed");
				window.location.href = "shop.php";
			</script>
		<?php
		}
	} else {
		?>
		<script>
			alert("Can not add any more of this product");
			window.location.href = "shop.php?pid=<?php echo $pid; ?>";
		</script>
		<?php
	}
} elseif ($count == 0) {
	$query = "select * from tbl_flowers where flower_id='$pid' and statuses='available';";
	$re = mysqli_query($con, $query);
	$row = mysqli_fetch_array($re);
	$price = $row['flower_price'];
	$cat = $row['category_id'];
	if ($qty <= $ps) {
		$addq = "insert into tbl_cart(user_id,flower_id,cart_price,cart_qnt) values('$id','$pid','$price','$qty')";
		$readd = mysqli_query($con, $addq); {
			if ($readd) {
				$_SESSION['status'] = "Added to cart successfully";
				header('location:cart.php');
		?>
				<!--<script>
			alert("Added to cart successfully");
            window.location.href = "cart.php";
		</script>-->
			<?php
			} else {
			?>
				<script>
					alert("Operation failed");
					window.location.href = "shop.php";
				</script>
		<?php
			}
		}
	} else {
		?>
		<script>
			alert("Low stock");
			window.location.href = "shop.php";
		</script>
<?php
	}
}

?>
<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/E-FloraAura/E-FloraAura/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 04 Dec 2022 05:03:14 GMT -->

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>E-FloraAura - Flower Shop HTML5 Template</title>
	<meta name="robots" content="noindex, follow" />
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.all.min.js"></script>
</head>

<body>

</body>

</html>